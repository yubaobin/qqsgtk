import { defineStore } from 'pinia'
import { store } from '@/store'

export const useUserStore = defineStore('UserStore', {
    state: () => {
        return {
            // 用户信息
            userInfo: null,
            // 令牌
            token: '',
            // 权限列表
            permissions: []
        }
    },
    getters: {
        // 计算属性：获取用户名
        userName: (state) => state.userInfo?.name || '未登录'
    },
    actions: {
        // 设置用户信息
        setUserInfo (info) {
            this.userInfo = info
        },
        // 登录
        async login (loginForm) {
            const res = await api.login(loginForm)
            this.token = res.data.token
            this.userInfo = res.data.userInfo
            return res
        },
        // 退出登录
        logout () {
            this.token = ''
            this.userInfo = null
            this.permissions = []
        }
    }
})

/**
 * 在没有注册store的地方使用（工具函数、路由守卫等非组件场景）
 * @returns {ReturnType<typeof useUserStore>}
 */
export function useUserStoreHook () {
    return useUserStore(store)
}