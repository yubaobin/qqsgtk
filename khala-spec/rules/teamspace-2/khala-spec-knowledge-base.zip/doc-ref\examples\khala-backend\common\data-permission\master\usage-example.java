package com.eshore.khala.example.datapermission;

import com.eshore.khala.starter.datapermission.core.annotation.DataPermission;
import com.eshore.khala.starter.datapermission.core.rule.DataPermissionRule;
import com.eshore.khala.starter.datapermission.core.rule.org.OrgDataPermissionRule;
import com.eshore.khala.starter.datapermission.core.util.DataPermissionUtils;
import com.eshore.khala.starter.datapermission.core.type.DataPermissionType;

/**
 * 数据权限使用示例
 *
 * <p>展示 Khala 数据权限在实际业务中的典型用法。</p>
 */
@Service
public class OrderService extends ServiceImpl<OrderMapper, Order> {

    /**
     * 查询订单列表（自动应用数据权限）
     *
     * <p>普通用户：只能看到自己创建的订单</p>
     * <p>部门主管：能看到本部门及子部门的所有订单</p>
     * <p>管理员：能看到全部订单</p>
     */
    public List<Order> listOrders() {
        // 无需手动处理数据权限，MyBatis 拦截器自动拼接 SQL 条件
        return baseMapper.selectList(new QueryWrapper<>());
    }

    /**
     * 管理员查看全部数据（禁用数据权限）
     */
    @DataPermission(enabled = false)
    public List<Order> listAllOrdersForAdmin() {
        return baseMapper.selectList(new QueryWrapper<>());
    }

    /**
     * 导出数据（临时忽略数据权限）
     *
     * <p>使用 DataPermissionUtils.executeIgnore 在代码层面动态忽略权限。</p>
     */
    public void exportAllOrders() {
        DataPermissionUtils.executeIgnore(() -> {
            List<Order> allOrders = baseMapper.selectList(new QueryWrapper<>());
            // 执行导出逻辑...
        });
    }

    /**
     * 自定义数据权限规则
     *
     * <p>实现 DataPermissionRule 接口，自定义 SQL 条件拼接逻辑。</p>
     */
    @Component
    public class CustomDataPermissionRule implements DataPermissionRule {

        @Override
        public String getDataPermissionType() {
            return DataPermissionType.ORG.getType();
        }

        @Override
        public boolean defaultRule() {
            return false;
        }

        @Override
        public Set<String> getTableNames() {
            return Set.of("t_order", "t_order_item");
        }

        @Override
        public Expression getExpression(String tableName, Alias tableAlias) {
            // 自定义条件：只查询状态为正常的记录
            return new EqualsTo(
                new Column(tableAlias != null ? tableAlias.getName() + ".status" : "status"),
                new StringValue("1")
            );
        }

        @Override
        public void addUserColumn(Class<?> entityClass) {}

        @Override
        public void addUserColumn(String tableName) {}

        @Override
        public void addUserColumn(Class<?> entityClass, String columnName) {}

        @Override
        public void addUserColumn(String tableName, String columnName) {}
    }
}
