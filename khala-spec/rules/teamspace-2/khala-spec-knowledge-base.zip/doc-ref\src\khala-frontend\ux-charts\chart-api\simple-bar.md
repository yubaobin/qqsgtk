## SimpleBar API

### SimpleBar 属性

| 参数名 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| data | 数据项 | ^[array] 见下表[BarDataItem](#bardataitem) | — |
| config | 配置项 | 见下表[SimpleBarConfig](#simplebarconfig) | — |

### BarDataItem

| 属性名 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| name | 系列名称 | string | — |
| data | 数据项 | ^[Array]`{ name: string, value: string \| number }` | — |
| unit | 单位 | string | — |

#### SimpleBarConfig

| 属性名 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| showLabel | 是否显示标签 | boolean | — |
| barWidth | 柱子宽度 | number | — |
