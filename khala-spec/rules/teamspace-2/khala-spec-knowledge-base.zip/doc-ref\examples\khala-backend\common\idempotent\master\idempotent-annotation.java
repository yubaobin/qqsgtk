package com.eshore.khala.example.idempotent;

import com.eshore.khala.starter.idempotent.annotation.Idempotent;
import org.springframework.web.bind.annotation.*;

/**
 * @Idempotent 幂等注解使用示例
 *
 * <p>在方法上添加 @Idempotent 注解，相同参数的请求在指定时间内只会执行一次</p>
 * <p>实现原理：基于 Redis 的 SETNX 命令，请求到达时尝试设置 Key，设置失败则视为重复请求</p>
 */
@RestController
@RequestMapping("/api/order")
public class IdempotentAnnotationController {

    /**
     * 基本用法：指定业务 Key
     *
     * <p>keys: SpEL 表达式，提取参数值作为幂等 Key 的一部分</p>
     * <p>默认 1 秒内相同参数的请求会被拦截</p>
     */
    @Idempotent(keys = {"#orderId"})
    @PostMapping("/create")
    public String createOrder(@RequestParam Long orderId) {
        // 创建订单逻辑
        return "订单创建成功";
    }

    /**
     * 自定义幂等超时时间
     *
     * <p>time: 幂等有效时间，默认 1</p>
     * <p>unit: 时间单位，默认 SECONDS</p>
     * <p>注意：如果方法执行时间超过 time，请求仍可能进来</p>
     */
    @Idempotent(keys = {"#orderId"}, time = 5, unit = java.util.concurrent.TimeUnit.SECONDS)
    @PostMapping("/submit")
    public String submitOrder(@RequestParam Long orderId) {
        // 提交订单逻辑
        return "订单提交成功";
    }

    /**
     * 自定义锁名称
     *
     * <p>name: 锁的名称前缀，便于区分不同业务</p>
     */
    @Idempotent(name = "payment", keys = {"#paymentId"}, time = 3)
    @PostMapping("/pay")
    public String payOrder(@RequestParam Long paymentId) {
        // 支付逻辑
        return "支付成功";
    }

    /**
     * 多 Key 组合
     *
     * <p>多个参数组合作为幂等 Key，确保业务维度的唯一性</p>
     */
    @Idempotent(keys = {"#userId", "#productId"}, time = 2)
    @PostMapping("/purchase")
    public String purchase(@RequestParam Long userId, @RequestParam Long productId) {
        // 购买逻辑
        return "购买成功";
    }

    /**
     * 不指定 keys 时自动使用所有参数
     *
     * <p>当 keys 为空时，自动将所有方法参数拼接为幂等 Key</p>
     */
    @Idempotent(time = 5)
    @PostMapping("/apply")
    public String apply(@RequestParam String type, @RequestParam Long applicantId) {
        // 申请逻辑
        return "申请成功";
    }
}
