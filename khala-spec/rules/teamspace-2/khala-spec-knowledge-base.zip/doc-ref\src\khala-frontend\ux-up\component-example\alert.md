# Alert 警告
用于页面中展示重要的提示信息。

## Alert的基础用法
页面中的非浮层元素，不会自动消失。

 `ux-alert` 组件提供 5 种类型，由 `type` 属性指定，默认值为 `info`。`primary` 已被添加到 ^(1.1.4)。
```vue
<template>
    <div>
        <ux-alert title="主要提示的文字" type="primary" />
        <ux-alert title="成功提示的文案" type="success" />
        <ux-alert title="消息提示的文案" type="info" />
        <ux-alert title="警告提示的文案" type="warning" />
        <ux-alert title="错误提示的文案" type="error" />
    </div>
</template>
```

## Alert的主题
`ux-alert` 组件提供了两个不同的主题：`light` 和 `dark`。

 通过设置 `effect` 属性来改变主题，默认为 `light`。
```vue
<template>
    <div>
        <ux-alert title="主要提示的文字" type="primary" effect="dark" />
        <ux-alert title="成功提示的文案" type="success" effect="dark" />
        <ux-alert title="消息提示的文案" type="info" effect="dark" />
        <ux-alert title="警告提示的文案" type="warning" effect="dark" />
        <ux-alert title="错误提示的文案" type="error" effect="dark" />
    </div>
</template>
```

## Alert的自定义关闭按钮
你可以自定义关闭按钮为文字或其他符号。

 在 `ux-alert` 组件中，可以设置是否为可关闭状态， 关闭按钮的文本以及关闭时的回调函数。 `closable` 属性决定是否可关闭， 接受一个 `Boolean`，默认为 `false`。 你可以设置 `close-text` 属性来代替右侧的关闭图标， 需要注意的是 `close-text` 必须是一个字符串。 当 Alert 组件被关闭时会触发 `close` 事件。
```vue
<template>
    <div>
        <ux-alert title="不可关闭的 alert" type="success" :closable="false" />
        <ux-alert title="自定义 close-text" type="info" close-text="关闭" />
        <ux-alert title="设置了回调的 alert" type="warning" @close="hello" />
    </div>
</template>

<script setup>
import { UxMessage } from 'ux-up'

const hello = () => {
    UxMessage.warning('设置了回调的')
}
</script>
```

## Alert的使用图标
你可以通过为 `ux-alert` 组件添加图标来提高可读性。

 通过设置 `show-icon` 属性来显示 `ux-alert` 的 `icon`，这能更有效地向用户展示你的显示意图。或者你可以使用 `icon` slot 自定义 icon 内容。
```vue
<template>
    <div>
        <ux-alert title="主要提示的文字" type="primary" show-icon />
        <ux-alert title="成功提示的文案" type="success" show-icon />
        <ux-alert title="消息提示的文案" type="info" show-icon />
        <ux-alert title="警告提示的文案" type="warning" show-icon />
        <ux-alert title="错误提示的文案" type="error" show-icon />
        <ux-alert title="自定义按钮的错误提示的文案" type="error" show-icon>
            <template #icon>
                <Bell />
            </template>
        </ux-alert>
    </div>
</template>

<script setup>
import { Bell } from '@ux-up/icons-vue'
</script>
```

## Alert的文字居中
使用 `center` 属性来让文字水平居中。

```vue
<template>
    <div>
        <ux-alert title="主要提示的文字" type="primary" center show-icon />
        <ux-alert title="成功提示的文案" type="success" center show-icon />
        <ux-alert title="消息提示的文案" type="info" center show-icon />
        <ux-alert title="警告提示的文案" type="warning" center show-icon />
        <ux-alert title="错误提示的文案" type="error" center show-icon />
    </div>
</template>
```

## Alert的文字描述
为 `ux-alert` 组件添加一个更加详细的描述来使用户了解更多信息。

 除了必填的 `title` 属性外，你可以设置 `description` 属性来帮助你更好地介绍，我们称之为辅助性文字。 辅助性文字只能存放文本内容，当内容超出长度限制时会自动换行显示。
```vue
<template>
    <div>
        <ux-alert
            title="文字描述"
            type="success"
            description="这是一句绕口令：黑灰化肥会挥发发灰黑化肥挥发；灰黑化肥会挥发发黑灰化肥发挥。 黑灰化肥会挥发发灰黑化肥黑灰挥发化为灰……" />
    </div>
</template>

```

## Alert的带图标和描述

```vue
<template>
    <div>
        <ux-alert
            title="主要提示的文案"
            type="primary"
            description="文字说明文字说明文字说明文字说明文字说明文字说明"
            show-icon />
        <ux-alert
            title="成功提示的文案"
            type="success"
            description="文字说明文字说明文字说明文字说明文字说明文字说明"
            show-icon />
        <ux-alert
            title="消息提示的文案"
            type="info"
            description="文字说明文字说明文字说明文字说明文字说明文字说明"
            show-icon />
        <ux-alert
            title="警告提示的文案"
            type="warning"
            description="文字说明文字说明文字说明文字说明文字说明文字说明"
            show-icon />
        <ux-alert
            title="错误提示的文案"
            type="error"
            description="文字说明文字说明文字说明文字说明文字说明文字说明"
            show-icon />
    </div>
</template>
```

