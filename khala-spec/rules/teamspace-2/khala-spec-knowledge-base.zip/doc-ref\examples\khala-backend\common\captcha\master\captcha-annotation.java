package com.eshore.khala.example.captcha;

import com.eshore.khala.common.model.CommonResult;
import com.eshore.khala.starter.captcha.core.CaptchaServiceFactory;
import com.eshore.khala.starter.captcha.core.annotation.Captcha;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Captcha 注解与 CaptchaServiceFactory 校验示例
 *
 * <p>Khala 提供两种验证码校验方式：</p>
 * <p>1. @Captcha 注解：声明式自动校验，推荐使用</p>
 * <p>2. CaptchaServiceFactory：编程式手动校验，灵活控制</p>
 */
@RestController
@RequestMapping("/api/captcha/verify")
public class CaptchaAnnotationController {

    @Autowired
    private CaptchaServiceFactory captchaServiceFactory;

    /**
     * 方式一：@Captcha 注解自动校验（推荐）
     *
     * <p>在方法上添加 @Captcha 注解，框架在方法执行前自动校验验证码</p>
     * <p>校验失败抛出异常，由全局异常处理器统一返回错误信息</p>
     * <p>支持图形验证码、滑块验证码、短信验证码、邮箱验证码的自动路由校验</p>
     */
    @Captcha
    @PostMapping("/login")
    public CommonResult<String> loginWithCaptcha(@RequestBody LoginWithCaptchaReq req) {
        // 验证码校验通过后才会执行到这里
        return CommonResult.success("登录成功");
    }

    /**
     * 方式二：CaptchaServiceFactory 手动校验
     *
     * <p>适用于需要自定义校验逻辑或校验后做额外处理的场景</p>
     * <p>根据参数中的 captchaType 自动路由到对应的验证码服务进行校验</p>
     * <p>captchaType 值：</p>
     * <p>- "graph": 图形验证码</p>
     * <p>- "slide": 滑块验证码</p>
     * <p>- "sms": 短信验证码</p>
     * <p>- "email": 邮箱验证码</p>
     */
    @PostMapping("/manual")
    public CommonResult<Boolean> manualVerify(@RequestBody Map<String, String> params) {
        boolean success = captchaServiceFactory.verify(params);
        return CommonResult.success(success);
    }

    /**
     * 登录请求参数（带验证码）
     */
    @Data
    public static class LoginWithCaptchaReq {
        private String username;
        private String password;
        /** 验证码 */
        private String captchaCode;
        /** 验证码标识 */
        private String captchaKey;
        /** 验证码类型（graph/slide/sms/email） */
        private String captchaType;
        /** 设备ID（图形/滑块验证码使用） */
        private String deviceId;
    }
}
