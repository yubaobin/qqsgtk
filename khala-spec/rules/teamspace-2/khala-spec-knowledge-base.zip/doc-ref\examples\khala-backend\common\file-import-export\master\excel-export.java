package com.example.fileimportexport;

import com.alibaba.excel.EasyExcel;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

/**
 * Excel 导出示例
 */
@Tag(name = "Excel 导入导出管理")
@RestController
@RequestMapping("/api/excel")
public class ExcelExportController {

    /**
     * 导出用户列表
     */
    @Operation(summary = "导出用户列表", description = "导出用户列表为 Excel 文件")
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws IOException {
        // 设置响应头
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("用户列表", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        // 查询数据
        List<UserExportExcelVO> data = queryUserList();

        // 写入响应流
        EasyExcel.write(response.getOutputStream(), UserExportExcelVO.class)
                .sheet("用户列表")
                .doWrite(data);
    }

    private List<UserExportExcelVO> queryUserList() {
        // 模拟查询数据
        return List.of();
    }
}
