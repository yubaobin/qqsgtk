package com.example.userdisplay;

import com.eshore.dromara.trans.service.AutoTransable;
import com.eshore.dromara.trans.annotation.AutoTrans;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 自定义翻译扩展示例
 *
 * <p>说明：通过实现 AutoTransable 接口扩展新的翻译类型，</p>
 * <ul>
 *   <li>1. 使用 @AutoTrans 声明翻译命名空间和字段</li>
 *   <li>2. 实现 selectByIds 方法提供批量查询能力</li>
 *   <li>3. 组件会自动注册并拦截对应的 @Trans 注解</li>
 * </ul>
 */

/**
 * 部门翻译服务
 */
@Component
@AutoTrans(namespace = "dept", fields = {"deptName"})
public class DeptTransService implements AutoTransable<DeptModel> {

    private DeptMapper deptMapper;

    @Override
    public List<DeptModel> selectByIds(List ids) {
        return deptMapper.selectBatchIds(ids);
    }
}

/**
 * 地区翻译服务
 */
@Component
@AutoTrans(namespace = "region", fields = {"regionName"})
class RegionTransService implements AutoTransable<RegionModel> {

    private RegionMapper regionMapper;

    @Override
    public List<RegionModel> selectByIds(List ids) {
        return regionMapper.selectBatchIds(ids);
    }
}

/**
 * 使用自定义翻译的 VO
 */
class CustomTransVO {

    private Long id;

    /**
     * 部门 ID 翻译为部门名称
     */
    @com.eshore.dromara.trans.annotation.Trans(
            type = com.eshore.dromara.trans.type.TransType.AUTO_TRANS,
            key = "dept",
            target = DeptModel.class,
            fields = "deptName",
            ref = "deptName"
    )
    private Long deptId;
    private String deptName;

    /**
     * 地区 ID 翻译为地区名称
     */
    @com.eshore.dromara.trans.annotation.Trans(
            type = com.eshore.dromara.trans.type.TransType.AUTO_TRANS,
            key = "region",
            target = RegionModel.class,
            fields = "regionName",
            ref = "regionName"
    )
    private Long regionId;
    private String regionName;

    // getter / setter 省略
}

// 模型与 Mapper（简化）
class DeptModel {
    private Long id;
    private String deptName;
}

class RegionModel {
    private Long id;
    private String regionName;
}

class DeptMapper {
    List<DeptModel> selectBatchIds(List ids) { return null; }
}

class RegionMapper {
    List<RegionModel> selectBatchIds(List ids) { return null; }
}
