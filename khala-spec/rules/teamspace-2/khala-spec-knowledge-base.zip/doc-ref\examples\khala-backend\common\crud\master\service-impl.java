package com.example.crud;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service 层实现示例
 */
@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements SysUserService {

    /**
     * 分页查询用户列表
     */
    @Override
    public IPage<SysUser> pageUsers(UserPageReq req) {
        Page<SysUser> page = new Page<>(req.getPageNum(), req.getPageSize());

        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();
        // 动态条件
        wrapper.like(req.getUsername() != null, SysUser::getUsername, req.getUsername());
        wrapper.eq(req.getStatus() != null, SysUser::getStatus, req.getStatus());
        wrapper.orderByDesc(SysUser::getCreateTime);

        return baseMapper.selectPage(page, wrapper);
    }

    /**
     * 根据用户名查询
     */
    @Override
    public SysUser getByUsername(String username) {
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SysUser::getUsername, username);
        return baseMapper.selectOne(wrapper);
    }

    /**
     * 批量新增
     */
    @Override
    public boolean saveBatchUsers(List<SysUser> users) {
        return saveBatch(users, 500);
    }

    /**
     * 逻辑删除用户
     */
    @Override
    public boolean removeUserById(Long id) {
        return removeById(id);
    }
}
