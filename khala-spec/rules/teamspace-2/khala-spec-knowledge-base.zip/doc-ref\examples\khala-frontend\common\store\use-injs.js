// 使用 useXXHook
import { useUserStoreHook } from '@/store/modules/user'

// 路由守卫中使用
router.beforeEach((to, from, next) => {
  const userStore = useUserStoreHook()
  const token = userStore.token

  if (!token && to.path !== '/login') {
    next('/login')
  } else {
    next()
  }
})
