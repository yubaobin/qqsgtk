package com.example.file;

import com.eshore.khala.common.core.result.CommonResult;
import com.eshore.khala.starter.file.core.service.FileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 文件删除示例
 */
@Tag(name = "文件管理")
@RestController
@RequestMapping("/api/file")
public class FileDeleteController {

    @Autowired
    private FileService fileService;

    /**
     * 根据文件 ID 删除
     */
    @Operation(summary = "删除文件", description = "根据文件 ID 删除文件")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "删除成功"),
            @ApiResponse(responseCode = "404", description = "文件不存在")
    })
    @PostMapping("/delete")
    public CommonResult<Boolean> delete(@RequestBody FileDeleteReqVO reqVO) {
        boolean success = fileService.delete(reqVO.getFileId());
        return CommonResult.success(success);
    }
}

/**
 * 文件删除请求参数示例
 */
class FileDeleteReqVO {

    private String fileId;

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
