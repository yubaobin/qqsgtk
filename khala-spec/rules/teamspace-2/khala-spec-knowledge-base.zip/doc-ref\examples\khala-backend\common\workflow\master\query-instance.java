package com.example.workflow;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshore.khala.common.core.result.CommonResult;
import com.eshore.khala.warm.flow.biz.manager.WorkflowInstanceManager;
import com.eshore.khala.warm.flow.biz.req.ProcessInstancePageReq;
import com.eshore.khala.warm.flow.biz.vo.ProcessInstanceDetailVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 流程实例查询示例
 *
 * <p>说明：使用 WorkflowInstanceManager 查询流程实例，</p>
 * <ul>
 *   <li>1. 待办列表：当前用户需要处理的任务</li>
 *   <li>2. 已办列表：当前用户已处理过的任务</li>
 *   <li>3. 我发起的：当前用户发起的流程实例</li>
 *   <li>4. 流程轨迹：追踪流程执行历史</li>
 * </ul>
 */
@Tag(name = "流程查询")
@RestController
@RequestMapping("/api/workflow/query")
public class QueryInstanceController {

    @Autowired
    private WorkflowInstanceManager workflowInstanceManager;

    /**
     * 查询待办列表
     */
    @Operation(summary = "待办列表")
    @GetMapping("/todo")
    public CommonResult<IPage<ProcessInstanceDetailVO>> todoList(
            @RequestParam(defaultValue = "1") long pageNum,
            @RequestParam(defaultValue = "10") long pageSize) {

        ProcessInstancePageReq req = new ProcessInstancePageReq();
        req.setPageNum(pageNum);
        req.setPageSize(pageSize);

        return workflowInstanceManager.toDoInstancePage(req);
    }

    /**
     * 查询已办列表
     */
    @Operation(summary = "已办列表")
    @GetMapping("/done")
    public CommonResult<IPage<ProcessInstanceDetailVO>> doneList(
            @RequestParam(defaultValue = "1") long pageNum,
            @RequestParam(defaultValue = "10") long pageSize) {

        ProcessInstancePageReq req = new ProcessInstancePageReq();
        req.setPageNum(pageNum);
        req.setPageSize(pageSize);

        return workflowInstanceManager.processedInstancePage(req);
    }

    /**
     * 查询我发起的流程
     */
    @Operation(summary = "我发起的")
    @GetMapping("/my-instance")
    public CommonResult<IPage<ProcessInstanceDetailVO>> myInstance(
            @RequestParam(defaultValue = "1") long pageNum,
            @RequestParam(defaultValue = "10") long pageSize) {

        ProcessInstancePageReq req = new ProcessInstancePageReq();
        req.setPageNum(pageNum);
        req.setPageSize(pageSize);
        // 当前用户 ID 可从上下文中获取
        // req.setStartUserId(currentUserId);

        return workflowInstanceManager.getPage(req);
    }

    /**
     * 查询流程详情
     */
    @Operation(summary = "流程详情")
    @GetMapping("/detail")
    public CommonResult<ProcessInstanceDetailVO> detail(@RequestParam Long instanceId) {
        // 查询流程实例详情及轨迹
        return workflowInstanceManager.getById(instanceId);
    }
}
