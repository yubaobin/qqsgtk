package com.example.fileimportexport;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.util.ListUtils;

import java.util.List;

/**
 * 导入数据校验监听器示例
 */
public class UserImportListener implements ReadListener<UserImportVO> {

    private static final int BATCH_COUNT = 100;

    private final List<UserImportVO> successList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);
    private final List<UserImportVO> failList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);

    @Override
    public void invoke(UserImportVO data, AnalysisContext context) {
        // 数据校验
        if (data.getUsername() == null || data.getUsername().isEmpty()) {
            data.setErrorMsg("用户名不能为空");
            failList.add(data);
            return;
        }
        if (data.getEmail() == null || !data.getEmail().contains("@")) {
            data.setErrorMsg("邮箱格式不正确");
            failList.add(data);
            return;
        }
        successList.add(data);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 所有数据解析完成后的操作
    }

    public List<UserImportVO> getSuccessList() {
        return successList;
    }

    public List<UserImportVO> getFailList() {
        return failList;
    }
}
