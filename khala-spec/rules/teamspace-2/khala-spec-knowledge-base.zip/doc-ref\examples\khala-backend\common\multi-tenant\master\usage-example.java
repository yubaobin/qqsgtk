package com.example.multitenant;

import com.baomidou.dynamic.datasource.toolkit.DynamicDataSourceContextHolder;
import com.eshore.khala.common.core.result.CommonResult;
import com.eshore.khala.starter.tenant.context.TenantContextHolder;
import com.eshore.khala.starter.tenant.core.annotation.TenantIgnore;
import com.eshore.khala.starter.tenant.core.util.TenantUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 多租户使用示例
 *
 * <p>说明：Khala 多租户能力由框架自动装配，业务代码只需关注以下使用点：</p>
 * <ul>
 *   <li>1. 通过 TenantContextHolder 获取当前租户 ID</li>
 *   <li>2. 如需动态切换数据源，使用 DynamicDataSourceContextHolder</li>
 *   <li>3. 实体类中的租户字段由框架自动填充，无需手动处理</li>
 *   <li>4. 通过 @TenantIgnore 注解忽略租户过滤，适用于定时任务、回调等全局数据场景</li>
 *   <li>5. 通过 TenantUtils.execute 在指定租户上下文中执行逻辑，适用于定时任务遍历所有租户等场景</li>
 * </ul>
 */
@Tag(name = "多租户示例")
@RestController
@RequestMapping("/api/tenant")
public class TenantUsageController {

    /**
     * 获取当前租户 ID
     *
     * <p>框架在请求进入时已完成租户解析并写入上下文，业务层直接获取即可。</p>
     */
    @Operation(summary = "获取当前租户 ID")
    @GetMapping("/current-id")
    public CommonResult<Long> getCurrentTenantId() {
        Long tenantId = TenantContextHolder.getTenantId();
        return CommonResult.success(tenantId);
    }


    /**
     * 基于注解忽略租户过滤示例
     *
     * <p>在方法上添加 @TenantIgnore 注解，该方法内的所有数据库操作都不会拼接 tenant_id 条件。</p>
     * <p>适用场景：定时任务、支付/短信回调、管理后台查看所有租户数据等。</p>
     */
    @TenantIgnore
    @Operation(summary = "注解忽略租户过滤")
    @GetMapping("/ignore-by-annotation")
    public CommonResult<String> ignoreByAnnotation() {
        // 该方法内所有 SQL 不会拼接 tenant_id 条件，可查询所有租户的数据
        doGlobalBusiness();
        return CommonResult.success("已通过 @TenantIgnore 注解忽略租户过滤");
    }

    /**
     * 编程式忽略租户过滤示例
     *
     * <p>通过 TenantContextHolder.setIgnore(true) 手动控制忽略范围，</p>
     * <p>适用于需要在方法内部局部忽略租户的场景，务必在 finally 中恢复原状态。</p>
     */
    @Operation(summary = "编程式忽略租户过滤")
    @GetMapping("/ignore-by-code")
    public CommonResult<String> ignoreByCode() {
        Boolean oldIgnore = TenantContextHolder.isIgnore();
        try {
            TenantContextHolder.setIgnore(true);
            // 此处数据库操作不会拼接 tenant_id 条件
            doGlobalBusiness();
            return CommonResult.success("已通过编程式忽略租户过滤");
        } finally {
            // 必须恢复原状态，防止影响后续逻辑
            TenantContextHolder.setIgnore(oldIgnore);
        }
    }

    /**
     * 指定租户执行逻辑示例
     *
     * <p>通过 TenantUtils.execute(tenantId, func) 在指定租户上下文中执行逻辑，</p>
     * <p>方法执行期间租户 ID 会切换为目标租户，执行完毕后自动恢复原租户。</p>
     * <p>适用场景：定时任务遍历所有租户执行业务、系统级操作需要代理指定租户等。</p>
     */
    @Operation(summary = "指定租户执行逻辑")
    @GetMapping("/execute-with-tenant")
    public CommonResult<String> executeWithTenant(@RequestParam Long tenantId) {
        TenantUtils.execute(tenantId, () -> {
            // 此时租户上下文已切换为指定租户，所有数据库操作会拼接该租户的 tenant_id 条件
            doBusiness();
        });
        return CommonResult.success("已以租户 " + tenantId + " 的身份执行逻辑");
    }

    /**
     * 忽略租户执行逻辑示例（TenantUtils 工具类方式）
     *
     * <p>通过 TenantUtils.executeIgnore(func) 忽略租户过滤执行逻辑，</p>
     * <p>与编程式 setIgnore 相比，TenantUtils 封装了异常处理和状态恢复，推荐优先使用。</p>
     */
    @Operation(summary = "忽略租户执行逻辑（工具类方式）")
    @GetMapping("/execute-ignore")
    public CommonResult<String> executeIgnore() {
        TenantUtils.executeIgnore(() -> {
            // 此处数据库操作不会拼接 tenant_id 条件，可查询所有租户的数据
            doGlobalBusiness();
        });
        return CommonResult.success("已通过 TenantUtils.executeIgnore 忽略租户过滤执行逻辑");
    }

    private void doBusiness() {
        // 业务逻辑
    }

    private void doGlobalBusiness() {
        // 全局业务逻辑（跨租户操作）
    }
}
