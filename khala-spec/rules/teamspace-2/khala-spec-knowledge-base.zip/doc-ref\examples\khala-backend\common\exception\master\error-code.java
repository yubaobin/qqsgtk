package com.eshore.khala.example.exception;

import lombok.Getter;

/**
 * 统一错误码枚举
 *
 * <p>错误码规则：A-BB-CCC</p>
 * <ul>
 *   <li>A: 1-系统级错误，2-业务级错误</li>
 *   <li>BB: 模块编号（01-通用，02-用户，03-订单...）</li>
 *   <li>CCC: 具体错误序号</li>
 * </ul>
 */
@Getter
public enum ErrorCode {

    // 系统级错误 1xxxxx
    SUCCESS(200, "操作成功"),
    SYSTEM_ERROR(100001, "系统繁忙，请稍后重试"),
    PARAM_ERROR(100002, "参数错误：%s"),
    NOT_FOUND(100003, "%s [%s] 不存在"),
    UNAUTHORIZED(100004, "未登录或登录已过期"),
    FORBIDDEN(100005, "权限不足：%s"),
    REQUEST_TOO_FREQUENT(100006, "请求过于频繁，请稍后重试"),

    // 用户模块 2xxxxx
    USER_NOT_FOUND(200001, "用户不存在"),
    USER_PASSWORD_ERROR(200002, "用户名或密码错误"),
    USER_DISABLED(200003, "用户已被禁用"),
    USER_EXISTS(200004, "用户已存在"),

    // 文件模块 3xxxxx
    FILE_UPLOAD_ERROR(300001, "文件上传失败：%s"),
    FILE_SIZE_EXCEED(300002, "文件大小超过限制"),
    FILE_TYPE_NOT_SUPPORT(300003, "不支持的文件类型"),

    // 业务通用 4xxxxx
    BUSINESS_ERROR(400001, "业务处理失败：%s"),
    STATUS_NOT_ALLOWED(400002, "当前状态不允许此操作"),
    DATA_CONFLICT(400003, "数据冲突：%s");

    private final Integer code;
    private final String message;

    ErrorCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}
