package com.example.mq;

import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 发送普通消息示例
 */
@Tag(name = "消息队列管理")
@RestController
@RequestMapping("/api/mq")
public class SendMessageController {

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    /**
     * 发送同步消息
     */
    @Operation(summary = "发送同步消息", description = "发送同步消息到指定 topic")
    @PostMapping("/send")
    public CommonResult<String> send(@RequestParam String message) {
        rocketMQTemplate.syncSend("test-topic", message);
        return CommonResult.success("发送成功");
    }

    /**
     * 发送带标签的消息
     */
    @Operation(summary = "发送带标签的消息", description = "发送带 tag 的消息到指定 topic")
    @PostMapping("/send-with-tag")
    public CommonResult<String> sendWithTag(@RequestParam String message, @RequestParam String tag) {
        rocketMQTemplate.syncSend("test-topic:" + tag, message);
        return CommonResult.success("发送成功");
    }

    /**
     * 发送对象消息
     */
    @Operation(summary = "发送对象消息", description = "发送对象消息到指定 topic")
    @PostMapping("/send-object")
    public CommonResult<String> sendObject(@RequestBody UserMessageReqVO reqVO) {
        rocketMQTemplate.syncSend("user-topic",
                MessageBuilder.withPayload(reqVO).build());
        return CommonResult.success("发送成功");
    }

    /**
     * 发送异步消息
     */
    @Operation(summary = "发送异步消息", description = "异步发送消息到指定 topic")
    @PostMapping("/send-async")
    public CommonResult<String> sendAsync(@RequestParam String message) {
        rocketMQTemplate.asyncSend("test-topic", message, new org.apache.rocketmq.client.producer.SendCallback() {
            @Override
            public void onSuccess(org.apache.rocketmq.client.producer.SendResult sendResult) {
                System.out.println("发送成功: " + sendResult.getMsgId());
            }

            @Override
            public void onException(Throwable e) {
                System.out.println("发送失败: " + e.getMessage());
            }
        });
        return CommonResult.success("异步发送中");
    }

    // 消息对象
    public static class UserMessageReqVO {
        private Long userId;
        private String username;
        // getters / setters
    }
}
