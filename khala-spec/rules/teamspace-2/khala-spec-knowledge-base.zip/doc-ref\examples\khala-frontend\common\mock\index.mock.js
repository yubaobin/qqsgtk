// mock/modules/demo/index.mock.js
import { defineMock } from 'vite-plugin-mock-dev-server'
import { resultSuccess, resultError } from '../../_util.js'
import mockList from './json.js'

export default defineMock([
    // GET请求示例
    {
        url: '/api/demo/get',
        method: 'GET',
        delay: 200,
        body: resultSuccess({ list: mockList })
    },

    // POST请求示例（带参数处理）
    {
        url: '/api/demo/page',
        method: 'POST',
        delay: 300,
        body: ({ query, body }) => {
            const { pageNum = 1, pageSize = 10 } = body
            const start = (pageNum - 1) * pageSize
            const end = pageNum * pageSize

            return resultSuccess({
                list: mockList.slice(start, end),
                total: mockList.length,
                pageNum,
                pageSize
            })
        }
    },

    // 错误返回示例
    {
        url: '/api/demo/error',
        method: 'GET',
        delay: 200,
        body: resultError('操作失败', 500)
    }
])