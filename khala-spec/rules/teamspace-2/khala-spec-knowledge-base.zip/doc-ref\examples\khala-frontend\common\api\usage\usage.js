import userApi from '@/api/modules/user/index.js'

let userInfo = {}
function getUserDetail(id) {
    userApi.getUserDetail({ id }).then((data) => {
        userInfo = data
    })
}