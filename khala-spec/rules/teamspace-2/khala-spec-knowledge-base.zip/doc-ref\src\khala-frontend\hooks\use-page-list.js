import { useAppStore } from '@/store/modules/app'
import { cloneDeep } from 'lodash-es'
import { UxMessage, UxMessageBox } from 'ux-up'
import { computed, getCurrentInstance, isRef, onActivated, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'

/**
 * @typedef {object} PageListOption
 * @property {() => Promise<any>} getListApi 请求接口
 * @property {Record<string, any>} query 查询参数
 * @property {boolean} autoLoad 是否自动加载列表数据，默认为 true
 */

/**
 *
 * @param {PageListOption} state
 */
export function usePageListHook (state) {
    const instance = getCurrentInstance()
    const router = useRouter()
    const appStore = useAppStore()
    // 配置请求接口
    const getListApi = state.getListApi ? state.getListApi : () => Promise.resolve()
    const query = isRef(state.query) ? state.query : ref(cloneDeep(state.query))
    const pagination = reactive({
        currentPage: 1,
        pageSize: 10,
        total: 0,
        layout: '->, total, prev, pager, next, jumper'
    })
    const loadingList = ref(false)
    const list = ref([])
    const selectedRows = ref([])
    const showEdit = ref(false)
    const curRow = ref({})

    onActivated(() => {
        getList()
    })

    onMounted(() => {
        if (state.autoLoad !== false) {
            search()
        }
    })

    function onAdd () {
        curRow.value = {}
        showEdit.value = true
    }
    function onEdit (row) {
        curRow.value = row
        showEdit.value = true
    }
    function resetQuery () {
        query.value = cloneDeep(state.query)
        getList(1)
    }
    function getList (page) {
        if (page) {
            pagination.currentPage = page
        }
        loadingList.value = true
        getListApi({
            page: pagination.currentPage,
            size: pagination.pageSize,
            ...query.value
        }).then((data) => {
            list.value = data.records
            pagination.total = data.total
        }).finally(() => {
            loadingList.value = false
        })
    }
    function confirm (text, apiMethod, isBack = false) {
        return UxMessageBox.confirm(text,
            '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                dangerouslyUseHTMLString: true,
                type: 'warning',
                beforeClose: (action, instance, done) => {
                    if (action === 'confirm') {
                        instance.confirmButtonLoading = true
                        apiMethod().then(() => {
                            UxMessage.success('操作成功')
                            if (isBack) {
                                router.back()
                            } else {
                                getList()
                            }
                        }).finally(() => {
                            instance.confirmButtonLoading = false
                            done()
                        })
                    } else {
                        done()
                    }
                }
            })
    }
    function onSelectionChange (val) {
        selectedRows.value = val
    }
    function onSortChange ({ prop, order }) {
        if (!query.value.sorts) {
            query.value.sorts = {}
        }
        query.value.sorts.column = prop
        query.value.sorts.order = order
        getList(1)
    }
    function search (searchQuery) {
        if (searchQuery) {
            query.value = { ...query.value, ...searchQuery }
        }
        getList(1)
    }
    function indexMethod (index) {
        const { pageSize = 10, currentPage: pageNum = 1 } = pagination
        return index + pageSize * (pageNum - 1) + 1
    }
    function toPage (path, query = {}) {
        if (instance && instance.type.name) {
            appStore.setCacheView([instance.type.name])
        }
        router.push({
            path: path,
            query: query
        })
    }

    const isSelected = computed(() => !!selectedRows.value.length)

    return {
        query,
        pagination,
        loadingList,
        list,
        selectedRows,
        showEdit,
        curRow,
        isSelected,
        onAdd,
        onEdit,
        resetQuery,
        getList,
        confirm,
        onSelectionChange,
        onSortChange,
        indexMethod,
        toPage,
        search
    }
}
