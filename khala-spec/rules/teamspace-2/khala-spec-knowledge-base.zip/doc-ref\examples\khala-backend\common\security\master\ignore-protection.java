package com.example.security;

import com.eshore.khala.starter.protection.ignore.IgnoreProtection;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * 忽略安全保护规则示例
 *
 * <p>说明：实现 IgnoreProtection 接口可让指定 URL 跳过安全检查，</p>
 * <ul>
 *   <li>1. 常用于 Swagger 文档、健康检查、静态资源等路径</li>
 *   <li>2. 返回的 URL 列表支持 Ant 风格通配符（如 /swagger-ui/**）</li>
 *   <li>3. 可创建多个实现类，分别管理不同场景的忽略规则</li>
 * </ul>
 */
@Component
public class SwaggerIgnoreProtection implements IgnoreProtection {

    @Override
    public List<String> getIgnoreUrls() {
        return Arrays.asList(
                "/swagger-ui/**",
                "/v3/api-docs/**",
                "/swagger-resources/**",
                "/webjars/**"
        );
    }
}

/**
 * 健康检查和静态资源忽略保护
 */
@Component
class HealthIgnoreProtection implements IgnoreProtection {

    @Override
    public List<String> getIgnoreUrls() {
        return Arrays.asList(
                "/actuator/health",
                "/actuator/info",
                "/favicon.ico",
                "/error"
        );
    }
}
