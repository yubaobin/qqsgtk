package com.example.crud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 用户分页查询请求参数示例
 */
@Schema(description = "用户分页查询请求参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class UserPageReqVO extends PageParam {

    @Schema(description = "用户名（模糊查询）", example = "admin")
    private String username;

    @Schema(description = "状态：0-禁用，1-启用", example = "1")
    private Integer status;
}

/**
 * 创建用户请求参数示例
 */
@Schema(description = "创建用户请求参数")
@Data
class UserCreateReqVO {

    @Schema(description = "用户名", requiredMode = Schema.RequiredMode.REQUIRED, example = "admin")
    private String username;

    @Schema(description = "昵称", example = "管理员")
    private String nickname;

    @Schema(description = "邮箱", example = "admin@example.com")
    private String email;

    @Schema(description = "手机号", example = "13800138000")
    private String mobile;

    @Schema(description = "状态：0-禁用，1-启用", example = "1")
    private Integer status;
}

/**
 * 更新用户请求参数示例
 */
@Schema(description = "更新用户请求参数")
@Data
class UserUpdateReqVO {

    @Schema(description = "用户编号", requiredMode = Schema.RequiredMode.REQUIRED, example = "1")
    private Long id;

    @Schema(description = "昵称", example = "管理员")
    private String nickname;

    @Schema(description = "邮箱", example = "admin@example.com")
    private String email;

    @Schema(description = "手机号", example = "13800138000")
    private String mobile;

    @Schema(description = "状态：0-禁用，1-启用", example = "1")
    private Integer status;
}

/**
 * 删除用户请求参数示例
 */
@Schema(description = "删除用户请求参数")
@Data
class UserDeleteReqVO {

    @Schema(description = "用户编号", requiredMode = Schema.RequiredMode.REQUIRED, example = "1")
    private Long id;
}

/**
 * 批量删除用户请求参数示例
 */
@Schema(description = "批量删除用户请求参数")
@Data
class UserBatchDeleteReqVO {

    @Schema(description = "用户编号列表", requiredMode = Schema.RequiredMode.REQUIRED, example = "[1,2,3]")
    private java.util.List<Long> ids;
}
