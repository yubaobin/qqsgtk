---
name: yx:rules
description: 将编码规则文件安装到项目 AI 工具目录，使 AI 自动遵循后端/前端编码规范
tags: [workflow, rules, setup]
---

Use Skill tool to invoke khala-spec-rules.
