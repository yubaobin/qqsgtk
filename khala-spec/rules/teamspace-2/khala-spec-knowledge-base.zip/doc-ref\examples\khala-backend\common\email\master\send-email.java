package com.eshore.khala.example.email;

import com.eshore.khala.starter.email.EmailManager;
import com.eshore.khala.starter.email.pojo.parameter.SendEmailParameter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 邮件发送示例
 *
 * <p>通过 EmailManager 统一发送邮件，支持模板和自定义内容</p>
 */
@RestController
@RequestMapping("/api/email")
@RequiredArgsConstructor
public class SendEmailController {

    private final EmailManager emailManager;

    /**
     * 发送验证码邮件
     *
     * <p>使用配置文件中定义的 captcha 模板</p>
     * <p>template 对应 yml 中 khala.email.template 下的 key</p>
     */
    @PostMapping("/captcha")
    public String sendCaptcha(@RequestParam String email, @RequestParam String code) {
        SendEmailParameter parameter = new SendEmailParameter();
        parameter.setEmail(email);
        parameter.setTemplate("captcha");
        parameter.setApplyId("captcha-" + email);
        // 模板参数
        Map<String, Object> templateParams = new HashMap<>(4);
        templateParams.put("code", code);
        parameter.setTemplateParams(templateParams);

        emailManager.sendEmail(parameter);
        return "验证码邮件发送成功";
    }

    /**
     * 发送通知邮件
     *
     * <p>使用自定义模板发送通知类邮件</p>
     */
    @PostMapping("/notify")
    public String sendNotify(@RequestParam String email,
                             @RequestParam String template,
                             @RequestBody Map<String, Object> params) {
        SendEmailParameter parameter = new SendEmailParameter();
        parameter.setEmail(email);
        parameter.setTemplate(template);
        parameter.setApplyId("notify-" + System.currentTimeMillis());
        parameter.setTemplateParams(params);

        emailManager.sendEmail(parameter);
        return "通知邮件发送成功";
    }
}
