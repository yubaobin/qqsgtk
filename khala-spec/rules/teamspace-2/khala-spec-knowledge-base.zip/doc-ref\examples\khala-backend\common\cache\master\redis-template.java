package com.eshore.khala.example.cache;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * RedisTemplate 基础操作示例
 *
 * <p>直接使用 RedisTemplate 进行缓存的增删改查</p>
 */
@Service
public class RedisTemplateService {

    private final StringRedisTemplate stringRedisTemplate;
    private final RedisTemplate<String, Object> redisTemplate;

    public RedisTemplateService(StringRedisTemplate stringRedisTemplate,
                                RedisTemplate<String, Object> redisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
        this.redisTemplate = redisTemplate;
    }

    /**
     * 字符串操作
     */
    public void stringOps() {
        // 设置值
        stringRedisTemplate.opsForValue().set("key", "value");
        // 设置值并指定过期时间
        stringRedisTemplate.opsForValue().set("key", "value", 30, TimeUnit.MINUTES);
        // 获取值
        String value = stringRedisTemplate.opsForValue().get("key");
        // 删除键
        stringRedisTemplate.delete("key");
    }

    /**
     * Hash 操作
     */
    public void hashOps() {
        String key = "user:1";
        // 设置字段值
        stringRedisTemplate.opsForHash().put(key, "name", "张三");
        stringRedisTemplate.opsForHash().put(key, "age", "25");
        // 获取字段值
        Object name = stringRedisTemplate.opsForHash().get(key, "name");
        // 删除字段
        stringRedisTemplate.opsForHash().delete(key, "age");
    }

    /**
     * List 操作
     */
    public void listOps() {
        String key = "list:key";
        // 左侧插入
        stringRedisTemplate.opsForList().leftPush(key, "item1");
        // 右侧弹出
        String item = stringRedisTemplate.opsForList().rightPop(key);
    }

    /**
     * Set 操作
     */
    public void setOps() {
        String key = "set:key";
        // 添加成员
        stringRedisTemplate.opsForSet().add(key, "member1", "member2");
        // 判断成员是否存在
        Boolean isMember = stringRedisTemplate.opsForSet().isMember(key, "member1");
    }

    /**
     * 对象缓存（使用 JSON 序列化）
     */
    public void objectOps() {
        // redisTemplate 配置 JSON 序列化后可存储对象
        redisTemplate.opsForValue().set("obj:key", new Object());
    }
}
