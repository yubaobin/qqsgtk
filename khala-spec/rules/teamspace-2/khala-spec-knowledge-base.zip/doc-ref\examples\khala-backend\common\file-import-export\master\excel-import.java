package com.example.fileimportexport;

import com.alibaba.excel.EasyExcel;
import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * Excel 导入示例
 */
@Tag(name = "Excel 导入导出管理")
@RestController
@RequestMapping("/api/excel")
public class ExcelImportController {

    /**
     * 导入用户数据
     */
    @Operation(summary = "导入用户数据", description = "从 Excel 文件导入用户数据")
    @PostMapping("/import")
    public CommonResult<String> importUsers(@RequestParam("file") MultipartFile file) throws IOException {
        UserImportListener listener = new UserImportListener();
        EasyExcel.read(file.getInputStream(), UserImportExcelVO.class, listener)
                .sheet()
                .doRead();

        List<UserImportExcelVO> successList = listener.getSuccessList();
        List<UserImportExcelVO> failList = listener.getFailList();

        return CommonResult.success("导入成功 " + successList.size() + " 条，失败 " + failList.size() + " 条");
    }
}
