export default [
    {
        id: 1,
        name: '测试数据1',
        status: 1,
        createTime: '2024-01-01 10:00:00'
    },
    {
        id: 2,
        name: '测试数据2',
        status: 0,
        createTime: '2024-01-02 11:00:00'
    }
]