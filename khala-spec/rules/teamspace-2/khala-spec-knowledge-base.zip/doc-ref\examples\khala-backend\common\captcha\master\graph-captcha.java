package com.eshore.khala.example.captcha;

import com.eshore.khala.common.model.CommonResult;
import com.eshore.khala.starter.captcha.core.graph.IGraphCaptchaService;
import com.eshore.khala.starter.captcha.core.graph.vo.GraphCaptchaVO;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 图形验证码示例
 *
 * <p>通过 IGraphCaptchaService 生成和校验图形验证码（GIF/PNG）</p>
 * <p>验证码存储在 Redis 中，自动管理过期和重试次数</p>
 */
@RestController
@RequestMapping("/api/captcha/graph")
@RequiredArgsConstructor
public class GraphCaptchaController {

    private final IGraphCaptchaService graphCaptchaService;

    /**
     * 生成图形验证码（返回 Base64）
     *
     * <p>返回 GraphCaptchaVO，包含 captchaKey 和 base64Img</p>
     * <p>前端使用 captchaKey 标识本次验证码，base64Img 展示图片</p>
     */
    @GetMapping("/generate")
    public CommonResult<GraphCaptchaVO> generate(@RequestParam(required = false) String captchaKey) {
        return graphCaptchaService.generate(captchaKey);
    }

    /**
     * 生成图形验证码（直接输出图片流）
     *
     * <p>通过 HttpServletResponse 直接输出图片流</p>
     * <p>captchaKey 通过响应头或其他方式返回给前端</p>
     */
    @GetMapping("/image")
    public void generateImage(@RequestParam String captchaKey,
                              HttpServletResponse response) {
        graphCaptchaService.generate(captchaKey, response);
    }
}
