package com.example.fileimportexport;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.metadata.property.ExcelContentProperty;

/**
 * 字典转换器示例：状态码转中文
 */
public class StatusConverter implements Converter<Integer> {

    @Override
    public Class<?> supportJavaTypeKey() {
        return Integer.class;
    }

    @Override
    public WriteCellData<?> convertToExcelData(Integer value, ExcelContentProperty contentProperty,
                                                GlobalConfiguration globalConfiguration) {
        String text = switch (value) {
            case 0 -> "禁用";
            case 1 -> "启用";
            default -> "未知";
        };
        return new WriteCellData<>(text);
    }

    @Override
    public Integer convertToJavaData(ReadCellData<?> cellData, ExcelContentProperty contentProperty,
                                      GlobalConfiguration globalConfiguration) {
        String text = cellData.getStringValue();
        return switch (text) {
            case "禁用" -> 0;
            case "启用" -> 1;
            default -> null;
        };
    }
}
