# quick-requirement 执行模式拆分设计

- **日期**：2026-08-26
- **作者**：AI Agent（与用户协作）
- **状态**：设计已确认，待实现
- **影响范围**：`commands/quick-requirement.md`、`skills/quick-requirement/SKILL.md`、`skills/quick-requirement/scripts/references.example.yaml`

## 背景与目标

`/yx:quick-requirement`（下称 quick-requirement）当前实现是一条 5 步流程：解析关键词 → 拉参考素材 → 调用 `/yx:require` 生成需求规格 → 等用户在 `/yx:require` 步骤 8 审批通过 → 调用 `/yx:prototype` 生成高保真原型。

调用方反馈：实际打单中"快速打单"诉求占比更高，T3 + T4 的需求澄清与审批交互会让流程变慢；同时 AI Agent 在 5 步中频繁打印 todo 状态也会刷屏。

**目标**：把当前的 5 步流程定义为 `normal` 模式（保留可访问），新增 `quick` 模式作为**默认**模式，跳过需求规格生成（T3）与用户审批（T4），直接进入高保真原型生成（T5），并大幅收敛输出与交互。

**重要行为变更**：`/yx:quick-requirement 关键词`（不带任何 flag）当前会跑完整 5 步；改造后默认只跑 3 步。原行为需要显式传 `--normal` 才能触发。

## 模式机制

### 模式状态

`mode` 取值：`quick` | `normal`，初始为 `quick`，命中即锁定，本次执行不再变更。

### 步骤 0A：执行模式识别

`mode` 在**本次执行的第一次输入**时按以下顺序判断并锁定，整个执行周期不再重判（即使后续用户继续输入追问/补充信息，也不重置 `mode`）。

判断顺序（命中即停止）：

1. 含 `--normal` → `mode = normal`
2. 含 `--quick` → `mode = quick`
3. 两者都不含 → `mode = quick`（默认）

锁定后向用户输出一行触发提示（**仅首次**）：

| mode | 触发提示 |
|------|---------|
| `quick` | `[quick-requirement] mode = quick — 跳过需求确认环节，直接生成高保真原型。` |
| `normal` | `[quick-requirement] mode = normal — 依次执行需求规格生成、用户审批、高保真原型。` |

冲突处理：
- 同时含 `--quick` 和 `--normal` → 以 `normal` 为准（更严格的流程优先），提示：「--quick 与 --normal 同时出现，按 normal 处理。」

### 调用语法（flag 必须在关键词之前）

```
/yx:quick-requirement 关键词 [#id]...                 # 默认 = quick
/yx:quick-requirement --quick 关键词 [#id]...          # 显式 quick
/yx:quick-requirement --normal 关键词 [#id]...         # 显式 normal
```

边界处理：

- flag 出现在关键词之后 → 视为「位置错误」，提示用户把 flag 移到关键词前；如未修正则忽略该 flag，按剩余输入判定 mode

## 双套 Todo 与 Output

### Normal Todo（5 项，保留现有流程）

| # | 待办 | 类型 | 入口 |
|---|------|------|------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | 用户调用 |
| T2 | 拉取并解压参考素材 | 自动 / 可能阻塞 | `download-refs.sh` |
| T3 | 调用 `/yx:require` 生成需求规格 | AI 子指令 | `khala-spec-require` skill |
| T4 | 用户在 `/yx:require` 步骤 8 审批通过 | 用户介入 | AskUserQuestion |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | `khala-spec-prototype` skill |

披露规约（沿用现有）：
- 执行前：打印完整 5 项 todo 表，每行带状态 emoji
- 执行中：每完成一项立刻更新对应行状态；同一时刻仅 1 项 ⏳
- 阻塞时：状态置 ⛔ 并向用户说明原因
- 完成后：在 Output 完成提示中再补一段「待办清单终态」

### Quick Todo（3 项，跳过 T3/T4）

| # | 待办 | 类型 | 入口 |
|---|------|------|------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | 用户调用 |
| T2 | 拉取并解压参考素材 | 自动 / 可能阻塞 | `download-refs.sh` |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | `khala-spec-prototype` skill |

披露规约（极致精简）：
- 执行前：仅打印一行触发提示 + 3 项 todo 表格（可选，可仅打印触发提示）
- 执行中：**不**逐项刷新状态、不打印中间日志
- 阻塞时：状态置 ⛔ 并向用户说明原因（仅 T2 可能阻塞）
- 完成后：仅输出一行汇总（见 Quick Output）

### Normal Output（保留现有）

```
[quick-requirement] done
- reference materials: khala-spec/rd/references/<关键词>/
- requirements spec:   khala-spec/rd/requirements/changes/vX.X.X/vX.X.X-<domain>.md
- high-fi prototype:   khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html

待办清单终态：
- ✅ T1 解析关键词与 #id 列表
- ✅ T2 拉取并解压参考素材（<N> 个案例）
- ✅ T3 调用 /yx:require 生成需求规格
- ✅ T4 用户在 yx:require 步骤 8 审批通过
- ✅ T5 调用 /yx:prototype 生成高保真原型
```

### Quick Output（极致精简）

```
[quick-requirement] done (quick mode)
- references:  khala-spec/rd/references/<关键词>/ (<N> 个案例)
- prototype:   khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html
```

不打印中间状态变更、不打印 todo 终态表、不打印需求规格相关路径（因为没产出）。

## Common Mistakes 增补

| 现象 | 原因 |
|------|------|
| 默认看不到 `/yx:require` 步骤 8 的用户审批交互 | 当前为 quick 模式（默认）；需要审批交互请显式传 `--normal` |
| 期望产出需求规格文档但 quick 模式下没有 | quick 模式刻意跳过；改用 `--normal` 或直接调用 `/yx:require` |
| flag 写在关键词之后被忽略 | `--quick` / `--normal` 必须在关键词之前；位置错误则提示并忽略该 flag |

## 需要改的文件

| 文件 | 改动 |
|------|------|
| `commands/quick-requirement.md` | ① frontmatter `description` 增加「默认 quick 模式，支持 `--normal`」② 新增「执行模式」段落 ③ 「执行待办概览」拆成 Normal/Quick 两套 |
| `skills/quick-requirement/SKILL.md` | ① frontmatter `description` 增加模式说明 ② 在 `Overview` 后插入 `步骤 0A 执行模式识别` 段 ③ `Execution Todo` 拆成 Normal Todo + Quick Todo 两套 ④ `Output` 拆成 Normal Output + Quick Output 两套 ⑤ `Parameters` 表新增 `--quick` / `--normal` 行 ⑥ `Common Mistakes` 增补 3 条 |
| `skills/quick-requirement/scripts/references.example.yaml` | 顶部注释增加一行：「本命令支持 `--normal` / `--quick` 两种执行模式，详见 skill 文档」 |
| `skills/quick-requirement/scripts/download-refs.sh` | **不改**（两种模式都跑它） |

## 不在本次范围内

- `/yx:require` 与 `/yx:prototype` skill 内部不变
- `references.yaml` 配置 schema 不变
- 不新增 `--dry-run` 等其他 flag
- 不调整 bootstrap-app 编排器对 quick-requirement 的引用方式（保持原样）

## 验收

- [ ] `/yx:quick-requirement 关键词` 默认进入 quick 模式，跳过 T3/T4，仅产出参考素材与原型
- [ ] `/yx:quick-requirement --normal 关键词` 进入 normal 模式，完整跑 5 步
- [ ] `/yx:quick-requirement --quick 关键词` 显式 quick，行为与默认 quick 一致
- [ ] flag 在关键词之后被识别为位置错误并提示
- [ ] `--quick` + `--normal` 同时出现时按 normal 处理
- [ ] normal 模式 Output 含 todo 终态表；quick 模式 Output 仅 3 行
- [ ] quick 模式执行中不打印 todo 状态变更
- [ ] `download-refs.sh` 两种模式都执行
