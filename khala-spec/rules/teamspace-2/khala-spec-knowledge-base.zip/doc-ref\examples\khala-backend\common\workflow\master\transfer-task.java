package com.example.workflow;

import com.eshore.khala.warm.flow.biz.manager.WorkflowTaskManager;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 任务转办、委派、加签减签示例
 *
 * <p>说明：WorkflowTaskManager 支持多种任务操作，</p>
 * <ul>
 *   <li>1. 转办：将任务转交给他人处理，自己不再处理</li>
 *   <li>2. 委派：将任务委派给他人处理，处理完成后回到自己</li>
 *   <li>3. 加签：增加审批人</li>
 *   <li>4. 减签：减少审批人</li>
 * </ul>
 */
@Tag(name = "任务操作")
@RestController
@RequestMapping("/api/workflow/task/operation")
public class TransferTaskController {

    @Autowired
    private WorkflowTaskManager workflowTaskManager;

    /**
     * 转办任务
     *
     * <p>将当前任务转交给 assigneeUserId 处理，原处理人不再参与</p>
     */
    @Operation(summary = "转办任务")
    @PostMapping("/transfer")
    public boolean transferTask(@RequestBody TransferTaskReq req) {
        return workflowTaskManager.transferTask(req.getTaskId(), req.getAssigneeUserId());
    }

    /**
     * 委派任务
     *
     * <p>将任务委派给 assigneeUserId 处理，处理完成后回到原处理人</p>
     */
    @Operation(summary = "委派任务")
    @PostMapping("/depute")
    public boolean deputeTask(@RequestBody TransferTaskReq req) {
        return workflowTaskManager.deputeTask(req.getTaskId(), req.getAssigneeUserId());
    }

    /**
     * 加签
     *
     * <p>在当前节点增加审批人</p>
     */
    @Operation(summary = "加签")
    @PostMapping("/add-sign")
    public boolean addSignTask(@RequestBody SignTaskReq req) {
        return workflowTaskManager.addSignTask(req.getTaskId(), req.getUserIds());
    }

    /**
     * 减签
     *
     * <p>从当前节点移除审批人</p>
     */
    @Operation(summary = "减签")
    @PostMapping("/reduce-sign")
    public boolean reduceSignTask(@RequestBody SignTaskReq req) {
        return workflowTaskManager.reduceSignTask(req.getTaskId(), req.getUserIds());
    }

    /**
     * 撤销流程
     */
    @Operation(summary = "撤销流程")
    @PostMapping("/revoke")
    public boolean revokeTask(@RequestBody TaskIdReq req) {
        return workflowTaskManager.revokeTask(req.getTaskId());
    }

    /**
     * 终止流程
     */
    @Operation(summary = "终止流程")
    @PostMapping("/terminate")
    public boolean terminateTask(@RequestBody TaskIdReq req) {
        return workflowTaskManager.terminateTask(req.getTaskId());
    }
}

/**
 * 转办/委派请求
 */
class TransferTaskReq {
    private Long taskId;
    private Long assigneeUserId;
    // getter / setter 省略
}

/**
 * 加签/减签请求
 */
class SignTaskReq {
    private Long taskId;
    private java.util.List<Long> userIds;
    // getter / setter 省略
}

/**
 * 任务 ID 请求
 */
class TaskIdReq {
    private Long taskId;
    // getter / setter 省略
}
