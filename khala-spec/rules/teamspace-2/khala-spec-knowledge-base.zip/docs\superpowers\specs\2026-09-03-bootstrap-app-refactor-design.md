<!-- khala-spec:path-scope: kb-internal -->
# bootstrap-app 重构设计文档

> 日期：2026-09-03 ｜ 状态：设计稿（待用户 review） ｜ 作者：AI Agent
> 配套约束：`execution-conventions.md`、`execution-plan.md`、CLAUDE.md「修改前的强制约定」
> 受影响仓库：`khala-spec-knowledge-base`（本仓）+ 下游 `@eshore/khala-spec`（同步）

---

## 1. 背景与目标

### 1.1 现状问题

当前 `khala-spec-bootstrap-app`（6503 行）是一条**9 阶段流水线**：

```
0 参数解析 → 1 require → 2 prototype → 3 design → 4 generate → 5 propose → 6 apply → 7 test → 8 deploy → 9 archive
```

最近 7 条 commit 全是"加约束 / 防偷懒 / 防重建"型加固（典型：
`feat:增加约束防止自建/重建 脚手架`、`feat:增加约束防止ai偷懒，只完成一项task就直接进入下一步`、`feat:添加关于khala的强约束`）。
**问题**：
- 流水线叙述冗长（SKILL.md 1060 行 + references 3062 行）
- 强约束散落在多文件，AI 难以一致执行
- 真实使用场景中 `prototype` / `design-archive` / `require-archive` 阶段产出很少用
- 「从 0 搭建全栈应用」语义在 Khala 已有成熟脚手架的前提下已不准确

### 1.2 重构目标

1. **职责单一化**：`bootstrap-app` 不再是"全流程编排器"，而是**业务代码生成器**——
   在运行环境已存在可运行的 Khala 基础项目的前提下，根据用户输入生成业务代码。
2. **三模式分档**：按需求复杂度分三档，避免一刀切：
   - **简单模式**（默认）：直接写代码
   - **中等模式**：写提案 + 任务清单 → 改代码
   - **终极模式**：写需求 → 提案 → 任务 → 改代码
3. **删除冗余设计文档**：原 require / prototype / design 阶段产物（requirements/*.md / prototype/*.html / design-overview.md / architecture.md 等）**默认不生成**，仅在中等/终极模式按需生成最小化文档。
4. **保留 Khala 复用约束**：上次新增的"禁止以「复杂」为由删除 Khala 模块"约束保留并加固。
5. **状态机简化**：状态机从"0-9 阶段计数"改为"模式驱动"，状态文件 schema 调整。

---

## 2. 新架构

### 2.1 前置条件（hard precondition）

> **运行环境中必须已存在可运行的 Khala 基础项目**。
> 含：Khala 父 pom + `admin-biz` + `log-biz` + `khala-commons` starter 子模块 + `SuperController/Service/Mapper` 基类可继承 + 前端 Vue3 + UX-UP 组件源码目录（`khala-spec/doc-ref/src/khala-frontend/ux-up/`）。
> 状态文件 `khala-spec/.workflow-state` 必须含 `"baseProjectReady": true` 字段。

若不满足：
- AI Agent 引导用户跑 `khala-spec generate --non-interactive <关键词>` 生成基础项目
- 或要求用户显式传 `--assume-base-project` 跳过校验（不推荐）

### 2.2 三模式工作流

| 模式 | 触发 | 工作流 | 中间产物 | 下游 skill 调用 |
|------|------|--------|----------|----------------|
| **quick**（默认） | 不传 `--mode` 或显式 `--mode quick` | 用户输入 → AI Agent 直接用 Edit/Write 工具改代码 | 无 | **不调用任何下游 skill**；AI Agent 自己就是执行者（直接 `Edit` / `Write` / `Bash`） |
| **standard** | `--mode standard` | 用户输入 → 写 proposal + tasks → 改代码 | `khala-spec/changes/<关键词>/{proposal.md, tasks.md}` | `/yx:propose <关键词>` → `/yx:apply <关键词>` |
| **strict** | `--mode strict` | 用户输入 → 写 requirement → proposal → tasks → 改代码 | `khala-spec/rd/requirements/changes/<v>/<v>-<domain>.md` + `khala-spec/changes/<关键词>/{proposal.md, design.md, tasks.md}` | `/yx:require <关键词>` → `/yx:propose <关键词>` → `/yx:apply <关键词>` |

> **三种模式都不写**：prototype（HTML 原型）、design-overview.md、architecture.md、4+1 视图图、deploy 产物、archive 产物。  
> 如需这些产物（典型：客户演示要 HTML 原型），用户显式调用对应 `/yx:*` skill。

### 2.3 输出

| 模式 | 最终交付 |
|------|----------|
| **quick** | `backend/` + `frontend/` 业务代码变更（AI Agent 直接 Edit/Write）；`khala-spec/.phase-summaries/bootstrap-<ts>.md` 决策快照；不调任何下游 skill |
| **standard** | quick 的产物 + `khala-spec/changes/<关键词>/{proposal.md, tasks.md}` |
| **strict** | standard 的产物 + `khala-spec/rd/requirements/changes/<v>/<v>-<domain>.md` |

**注意**：**所有模式都不产出可运行镜像**（`deploy/Dockerfile` / `deploy/k8s/*.yaml` 不再属于 bootstrap-app 职责）。如需部署，用户显式调用 `/yx:deploy 应用部署`。

---

## 3. 删除 / 保留 / 改造清单

### 3.1 删除（不再属于 bootstrap-app 职责）

| 项 | 位置 | 处置 |
|----|------|------|
| `Khala 参考代码来源约束（2026-09 加固）` doc-ref 段 | commands/bootstrap-app.md | 保留（doc-ref 引用是核心，仍需） |
| 9 阶段流水线叙述 | SKILL.md / stage-checkpoints.md / flow-overview.md | 删除 |
| `## State Persistence` 详细 schema | SKILL.md | 压缩到 SKILL.md，详情放到 references/state-machine.md |
| `## Loop Strategy` 9 阶段子循环 | SKILL.md | 删除 |
| `## Anti-Drift Hard Gates` | SKILL.md | 压缩为「模式门禁」段 |
| `## Auto vs Semi-Auto` | SKILL.md | 删除（不再分 auto/semi-auto） |
| `## Examples Mode` | SKILL.md | 删除（examples 模式不再属于 bootstrap-app） |
| `## Scaffold Conventions` | SKILL.md | 删除（脚手架生成由 `/yx:generate` 独立负责） |
| `## Redis 约定细则` 6 子章节 | SKILL.md | 删除（嵌入式 Redis 约束迁入 `/yx:generate` SKILL） |
| `## AI Rules 注入片段` | SKILL.md | 删除（AI Rules 由 `/yx:generate` / `/yx:apply` 自己维护） |
| `## 生成后门禁校验` 脚本 | SKILL.md | 删除（门禁迁入 `stage-state.cjs verify-mode`） |
| `## Common Confusion` | SKILL.md | 删除（不再解释 `/yx:*` 是 AI Agent 命令，与新职责无关） |
| `references/stage-checkpoints.md`（983 行） | references/ | 删除（9 阶段叙述） |
| `references/flow-overview.md`（685 行） | references/ | 删除（端到端流程图） |
| `references/rollback-strategy.md`（297 行） | references/ | 删除（9 阶段回退矩阵） |
| `references/examples-mode.md`（389 行） | references/ | 删除（有 `#id` 模式不再属于 bootstrap-app） |
| `references/embedded-redis-guide.md`（442 行） | references/ | **删除**（基础项目已就绪，嵌入式 Redis 使用细节由基础项目自带（脚手架生成时已固化），bootstrap-app 不再承担其规则推动职责；改代码涉及 Redis 时由 doc-ref 提供 Khala Redis 模块用法即可） |
| `references/starter-config-guide.md`（266 行） | references/ | 迁入 `skills/khala-spec-generate/references/` |
| `references/state-machine.md`（268 行） | references/ | 改写为「模式驱动的状态机 schema」 |

### 3.2 保留

| 项 | 位置 | 说明 |
|----|------|------|
| Khala 模块复用约束（禁止以「复杂」为由删除重建） | SKILL.md | 上次新增约束（白名单 / 黑名单 / AI 自检协议）保留 |
| doc-ref 引用规范 | SKILL.md / commands/ | 核心约束保留（防 AI 凭记忆臆造） |
| 三模式参数与触发 | commands/bootstrap-app.md | 新增 |
| `khala-spec/.workflow-state` 状态文件 | stage-state.cjs | 保留但 schema 调整 |
| `.phase-summaries/` 决策快照机制 | stage-state.cjs | 保留（每个模式退出前必写） |

### 3.3 改造

| 项 | 改造 |
|----|------|
| `commands/bootstrap-app.md` | 从 264 行压到 ~80 行：极简包装 + 三模式参数表 + doc-ref / Khala 复用约束引用 |
| `skills/khala-spec-bootstrap-app/SKILL.md` | 从 1060 行压到 ~350 行：定位重写（业务代码生成器）+ 三模式工作流 + Khala 复用约束 + Common Mistakes |
| `skills/khala-spec-bootstrap-app/scripts/stage-state.cjs` | 从 187 行压到 ~120 行：去掉 0-9 阶段计数，改为 `mode` 字段 + 模式内子步骤；新增 `verify-mode` 子命令 |
| `scripts/lib/cmds.js`（569 行） | 大幅瘦身：删除 13 个 cmd* 中与 9 阶段相关的（cmdSetStage / cmdBumpRetry 等），保留 mode 必要操作 |
| `scripts/lib/verify.js`（677 行） | 删除 9 阶段 verify-stage，重写为 `verify-mode <mode>` 内容门禁 |
| `scripts/lib/whitelist.js`（64 行） | 删除（阶段 4 命令白名单不再属于 bootstrap-app） |
| `scripts/lib/constants.js`（120 行） | 改造：删 VALID_STAGES 0-9，新增 MODES = ["quick", "standard", "strict"] |
| `scripts/lib/args.js`（38 行） | 改造：删 `--from` / `--max-retries` / `--skip` 等，加 `--mode` |

---

## 4. 状态机新形态

### 4.1 schema

```json
{
  "skill": "khala-spec-bootstrap-app",
  "version": "2.0.0",
  "keyword": "<关键词>",
  "mode": "quick | standard | strict",
  "baseProjectReady": true,
  "currentStep": "apply | propose | require | done",
  "steps": {
    "require": "pending | in_progress | done | skipped",
    "propose": "pending | in_progress | done | skipped",
    "apply":   "pending | in_progress | done"
  },
  "stepRetries": { "apply": 0 },
  "artifacts": {
    "requirement": "khala-spec/rd/requirements/changes/<v>/<v>-<domain>.md",
    "proposal":    "khala-spec/changes/<关键词>/proposal.md",
    "design":      "khala-spec/changes/<关键词>/design.md",
    "tasks":       "khala-spec/changes/<关键词>/tasks.md",
    "summary":     "khala-spec/.phase-summaries/bootstrap-<ts>.md"
  },
  "startedAt": "<iso>",
  "lastUpdate": "<iso>"
}
```

### 4.2 步骤状态机

```
                    ┌─── quick 模式：不调任何下游 skill，AI Agent 直接改代码
                    │      （进度记为 apply 步，但 apply 步是 AI 自己动作的代称）
                    │
mode = quick   ─────┴→  apply: pending → in_progress → done
                            │       （实际是 AI Agent 直接 Edit/Write/Bash）
                            ↓
                          done ──→ summary → clear

mode = standard ──→  propose: pending → in_progress → done
                          │
                          ↓
                       apply: pending → in_progress → done
                                              │
                                              ↓
                                           done ──→ summary → clear

mode = strict ──→  require: pending → in_progress → done
                      │
                      ↓
                  propose: pending → in_progress → done
                                      │
                                      ↓
                                   apply: pending → in_progress → done
                                                          │
                                                          ↓
                                                       done ──→ summary → clear
```

### 4.3 子命令（精简）

| 子命令 | 用途 | 示例 |
|--------|------|------|
| `init <keyword> --mode <quick\|standard\|strict>` | 初始化状态文件 + 校验 baseProjectReady | `node stage-state.cjs init "算力集市小程序" --mode quick` |
| `mark-step <step>` | 标记某步骤 in_progress → done | `node stage-state.cjs mark-step propose` |
| `bump-retry <step>` | 步骤重试 +1；超 maxRetries 退出码 2 | `node stage-state.cjs bump-retry apply` |
| `verify-mode` | 校验当前模式所有步骤已完成 + 必要产物存在 | `node stage-state.cjs verify-mode` |
| `mark-failed <step> <reason>` | 标记步骤失败 | `node stage-state.cjs mark-failed apply "controller 缺 SuperController 继承"` |
| `summary` | 打印人类可读进度 | `node stage-state.cjs summary` |
| `clear` | 清空状态文件 | `node stage-state.cjs clear` |
| `path` | 打印状态文件路径 | `node stage-state.cjs path` |
| `help` | 帮助 | `node stage-state.cjs help` |

**退出码**：
- `0` 成功
- `1` 校验不通过 / baseProjectReady 缺失
- `2` bump-retry 超限
- `3` 模式未知

---

## 5. Khala 复用约束（保留并加固）

上次新增的「⚠️ 优先复用 Khala 已提供功能模块（禁止以「复杂」为由删除重建）」约束**完整保留**并做如下加固：

### 5.1 升级点

1. **作用域扩展**：从"阶段 4-6"改为"全 9 步骤流水线（实际是三模式的所有步骤）"
2. **新增：与三模式协同**：
   - quick 模式：apply 阶段仍受 Khala 复用约束保护（不得删除 Khala starter）
   - standard / strict 模式：propose / require 阶段也受 Khala 复用约束保护（不得在 proposal 中写"删除 admin-biz"等违规决策）
3. **新增：Khala 父 pom + starter 子模块完整性校验**（在 `verify-mode` 中）：

```bash
# 后端 Khala 完整性（任何模式下都必过）
grep -q "<parent>.*com.eshore.khala" backend/pom.xml || exit 1
grep -q "<artifactId>admin-biz</artifactId>" backend/pom.xml || exit 1
grep -q "<artifactId>log-biz</artifactId>" backend/pom.xml || exit 1

# 前端 UX-UP 完整性
test -d khala-spec/doc-ref/src/khala-frontend/ux-up || exit 1
```

---

## 6. AI Rules 注入（按模式分档）

| 模式 | 注入给下游 skill 的 AI Rules | AI Agent 自身约束 |
|------|------------------------------|-------------------|
| **quick** | **不调任何下游 skill** | 仅 AI Agent 自身守 Khala 复用约束（不删 Khala starter、不替换 UX-UP） |
| **standard** | `propose.strict-khala-reuse` + `propose.require-docref-analysis` + `apply.strict-khala-reuse` + `apply.no-skip-task` | AI Agent 自身也守 Khala 复用约束 |
| **strict** | `require.strict-khala-reuse` + `propose.strict-khala-reuse` + `propose.require-docref-analysis` + `apply.strict-khala-reuse` + `apply.no-skip-task` | AI Agent 自身也守 Khala 复用约束 |

每条 AI Rules 的具体内容在 SKILL.md 中定义。

---

## 7. 验证方案

### 7.1 设计验证（实施前）

- [ ] 用户 review 本设计文档
- [ ] `git diff` 检查所有改动文件范围
- [ ] 三模式 demo 各跑一次（dry-run）：quick / standard / strict

### 7.2 实施验证（实施后）

- [ ] `node stage-state.cjs init "test" --mode quick`：状态文件含 `mode: "quick"`
- [ ] `node stage-state.cjs init "test" --mode standard`：状态文件含 `mode: "standard"`
- [ ] `node stage-state.cjs init "test" --mode strict`：状态文件含 `mode: "strict"`
- [ ] `node stage-state.cjs init "test" --mode unknown`：退出码 3
- [ ] `node stage-state.cjs verify-mode`：baseProjectReady=false 时退出码 1
- [ ] `node stage-state.cjs help`：打印新帮助
- [ ] `node stage-state.cjs summary`：打印新格式
- [ ] `git diff --stat`：总行数从 6503 降到 ~1500 行

### 7.3 集成验证

- [ ] 在临时项目跑 `node bin/khala-spec.js init --debug` 验证新 SKILL.md 在 `.claude/skills/khala-spec-bootstrap-app/SKILL.md` 与 `.opencode/skills/khala-spec-bootstrap-app/SKILL.md` 均能正常加载
- [ ] 三模式 demo：**quick 模式跑通**（`/yx:bootstrap-app test --mode quick` —— AI Agent 直接改代码，**不调 `/yx:apply`**，写决策快照）
- [ ] 三模式 demo：standard 模式跑通（proposal + tasks 落盘 + apply 调通）
- [ ] 三模式 demo：strict 模式跑通（requirement + proposal + tasks 落盘 + apply 调通）

---

## 8. 风险与依赖

| 风险 | 影响 | 应对 |
|------|------|------|
| 用户已有 9 阶段思维定势 | 升级后短期内混乱 | 在 SKILL.md / commands/ 顶部加 "BREAKING CHANGE" 提示；openspec-migration-log.md 详细记录 |
| 下游 `@eshore/khala-spec` 仓库未同步 | CLI 发布的版本与 KB 不一致 | 用户手工同步；待同步项在 openspec-migration-log.md 明示 |
| Khala 父 pom 校验过严 | 用户用 Khala 7.x 之前版本时校验失败 | `--skip-khala-parent-check` 绕过（不推荐） |
| `references/embedded-redis-guide.md` 迁入 generate 时路径错位 | 链接断裂 | （**已取消迁移**：文件改为删除） |

---

## 9. 实施步骤

按以下顺序逐步实施，每步完成后验证再进入下一步：

1. **写设计文档（本文档）** + 用户 review
2. **改写 commands/bootstrap-app.md**（极简包装 + 三模式参数表 + 引用 SKILL）
3. **改写 skills/khala-spec-bootstrap-app/SKILL.md**（350 行：定位 + 三模式 + Khala 复用约束 + Common Mistakes）
4. **改写 scripts/stage-state.cjs + lib/**（模式驱动：删除 9 阶段相关，新增 mode 操作）
5. **删除 / 迁移 references/**（删除 9 阶段相关；迁出 embedded-redis-guide / starter-config-guide）
6. **更新 openspec-migration-log.md**（本次重构登记）
7. **更新 execution-plan.md §4**（新增一条「已修复 2026-09」记录本次重构）
8. **执行 §7 验证清单**

---

## 10. 待用户 review 事项

- [x] **quick 模式不调 `/yx:apply`**，AI Agent 直接 Edit/Write 改代码（已根据用户 2026-09-03 反馈确认）
- [ ] 三模式的边界是否准确？（quick 不写任何文档、standard 写 proposal+tasks、strict 写 requirement+proposal+tasks）
- [ ] 三模式都不写 prototype / design-overview / architecture / deploy 产物，是否符合预期？
- [ ] 状态文件 schema 调整是否接受？
- [x] **`references/embedded-redis-guide.md` 一并删除**（基础项目已就绪，使用细节自带；已根据用户 2026-09-03 二次反馈再修正）
- [ ] 删除 `references/stage-checkpoints.md` / `flow-overview.md` / `rollback-strategy.md` / `examples-mode.md` / `embedded-redis-guide.md`（共 5 个），是否接受？

---

*本设计文档配套 execution-conventions.md 的规约；规约条目修订须同步更新 execution-plan.md 与 CLAUDE.md 强制约定。*
