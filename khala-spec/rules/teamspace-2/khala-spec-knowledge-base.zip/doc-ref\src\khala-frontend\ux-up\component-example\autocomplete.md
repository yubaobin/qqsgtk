
## ---
title: Autocomplete 自动补全输入框
description: 根据输入内容提供对应的输入建议。
lang: zh-CN
---
## 基础用法
根据输入内容提供对应的输入建议

 `autocomplete` 是一个可带输入建议的输入框组件，`fetch-suggestions` 属性是返回建议输入的方法。 在此示例中， `querySearch(queryString, cb)` 方法通过 `cb(data)` 给 Autocomplete 组件返回建议。
```vue
<template>
    <div>
        <div>
            <div>激活即列出输入建议</div>
            <ux-autocomplete
                v-model="state1"
                :fetch-suggestions="querySearch"
                clearable
               
                placeholder="请输入内容"
                @select="handleSelect" />
        </div>
        <div>
            <div>输入后匹配输入建议</div>
            <ux-autocomplete
                v-model="state2"
                :fetch-suggestions="querySearch"
                :trigger-on-focus="false"
                clearable
               
                placeholder="请输入内容"
                @select="handleSelect" />
        </div>
    </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const state1 = ref('')
const state2 = ref('')

const restaurants = ref([])
const querySearch = (queryString, cb) => {
    const results = queryString ? restaurants.value.filter(createFilter(queryString)) : restaurants.value
    // 调用 callback 返回建议列表的数据
    cb(results)
}
const createFilter = (queryString) => {
    return (restaurant) => {
        return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
    }
}
const loadAll = () => {
    return [
        { value: '组件总览' },
        { value: '基础组件' },
        { value: '布局容器' },
        { value: '色彩' },
        { value: '边框' },
        { value: '字体' },
        { value: '图标' },
        { value: '按钮' },
        { value: '文字链接' },
        { value: '表单组件' },
        { value: '级联选择器' },
        { value: '多选框' },
        { value: '颜色选择器' },
        { value: '日期选择器' },
        { value: '日期时间选择器' },
        { value: '表单' },
        { value: '输入框' },
        { value: '计数器' },
        { value: '单选框' },
        { value: '评分' },
        { value: '选择器' },
        { value: '滑块' },
        { value: '开关' },
        { value: '时间选择器' },
        { value: '穿梭框' },
        { value: '上传' }
    ]
}

const handleSelect = (item) => {
    console.log(item)
}

onMounted(() => {
    restaurants.value = loadAll()
})
</script>

```

## 自定义模板
可自定义输入建议的显示

 使用 `scoped slot` 自定义输入建议的模板。该 `scope` 的参数为 `item`，表示当前输入建议对象。
```vue
<template>
    <ux-autocomplete
        v-model="state"
       
        :fetch-suggestions="querySearch"
        popper-class="my-autocomplete"
        placeholder="请输入内容"
        @select="handleSelect">
        <template #suffix>
            <ux-svg-icon icon-name="ux-icon-Edit" />
        </template>
        <template #default="{ item }">
            <div>{{ item.value }}</div>
            <span>{{ item.link }}</span>
        </template>
    </ux-autocomplete>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const state = ref('')
const links = ref([])

const querySearch = (queryString, cb) => {
    const results = queryString ? links.value.filter(createFilter(queryString)) : links.value
    // call callback function to return suggestion objects
    cb(results)
}
const createFilter = (queryString) => {
    return (restaurant) => {
        return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
    }
}
const loadAll = () => {
    return [
        { value: '组件总览' },
        { value: '基础组件' },
        { value: '布局容器' },
        { value: '色彩' },
        { value: '边框' },
        { value: '字体' },
        { value: '图标' },
        { value: '按钮' },
        { value: '文字链接' },
        { value: '表单组件' },
        { value: '级联选择器' },
        { value: '多选框' },
        { value: '颜色选择器' },
        { value: '日期选择器' },
        { value: '日期时间选择器' },
        { value: '表单' },
        { value: '输入框' },
        { value: '计数器' },
        { value: '单选框' },
        { value: '评分' },
        { value: '选择器' },
        { value: '滑块' },
        { value: '开关' },
        { value: '时间选择器' },
        { value: '穿梭框' },
        { value: '上传' }
    ]
}
const handleSelect = (item) => {
    console.log(item)
}

const handleIconClick = (ev) => {
    console.log(ev)
}

onMounted(() => {
    links.value = loadAll()
})
</script>

```

## 远程搜索
从服务端搜索数据。

```vue
<template>
    <ux-autocomplete
        v-model="state"
       
        :fetch-suggestions="querySearchAsync"
        placeholder="请输入内容"
        @select="handleSelect" />
</template>

<script setup>
import { onMounted, ref } from 'vue'

const state = ref('')

const links = ref([])

const loadAll = () => {
    return [
        { value: '组件总览' },
        { value: '基础组件' },
        { value: '布局容器' },
        { value: '色彩' },
        { value: '边框' },
        { value: '字体' },
        { value: '图标' },
        { value: '按钮' },
        { value: '文字链接' },
        { value: '表单组件' },
        { value: '级联选择器' },
        { value: '多选框' },
        { value: '颜色选择器' },
        { value: '日期选择器' },
        { value: '日期时间选择器' },
        { value: '表单' },
        { value: '输入框' },
        { value: '计数器' },
        { value: '单选框' },
        { value: '评分' },
        { value: '选择器' },
        { value: '滑块' },
        { value: '开关' },
        { value: '时间选择器' },
        { value: '穿梭框' },
        { value: '上传' }
    ]
}

let timeout
const querySearchAsync = (queryString, cb) => {
    const results = queryString ? links.value.filter(createFilter(queryString)) : links.value

    clearTimeout(timeout)
    timeout = setTimeout(() => {
        cb(results)
    }, 3000 * Math.random())
}
const createFilter = (queryString) => {
    return (restaurant) => {
        return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
    }
}

const handleSelect = (item) => {
    console.log(item)
}

onMounted(() => {
    links.value = loadAll()
})
</script>

```

## 自定义加载
 修改加载区域内容
```vue
<template>
    <div>
        <div>
            <div>加载图标1</div>
            <ux-autocomplete
                v-model="state"
               
                :fetch-suggestions="querySearchAsync"
                placeholder="请输入内容"
                @select="handleSelect">
                <template #loading>
                                        </ux-icon>
                </template>
            </ux-autocomplete>
        </div>
    </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const state = ref('')

const links = ref([])

const loadAll = () => {
    return [
        { value: '组件总览' },
        { value: '基础组件' },
        { value: '布局容器' },
        { value: '色彩' },
        { value: '边框' },
        { value: '字体' },
        { value: '图标' },
        { value: '按钮' },
        { value: '文字链接' },
        { value: '表单组件' },
        { value: '级联选择器' },
        { value: '多选框' },
        { value: '颜色选择器' },
        { value: '日期选择器' },
        { value: '日期时间选择器' },
        { value: '表单' },
        { value: '输入框' },
        { value: '计数器' },
        { value: '单选框' },
        { value: '评分' },
        { value: '选择器' },
        { value: '滑块' },
        { value: '开关' },
        { value: '时间选择器' },
        { value: '穿梭框' },
        { value: '上传' }
    ]
}

let timeout
const querySearchAsync = (queryString, cb) => {
    const results = queryString ? links.value.filter(createFilter(queryString)) : links.value

    clearTimeout(timeout)
    timeout = setTimeout(() => {
        cb(results)
    }, 5000 * Math.random())
}
const createFilter = (queryString) => {
    return (restaurant) => {
        return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
    }
}

const handleSelect = (item) => {
    console.log(item)
}

onMounted(() => {
    links.value = loadAll()
})
</script>
```

## 自定义头部与底部 ^(1.1.6)
你可以通过插槽来自定义下拉菜单的头部和底部。

```vue
<template>
    <div>
        <div>
            <div>自定义头部</div>
            <ux-autocomplete
                v-model="headerSlotState"
               
                :fetch-suggestions="querySearchAsync"
                placeholder="请输入内容"
                @select="handleSelect">
                <template #header>头部内容</template>
            </ux-autocomplete>
        </div>
        <div>
            <div>自定义底部</div>
            <ux-autocomplete
                ref="footerAutocompleteRef"
                v-model="footerSlotstate"
               
                :fetch-suggestions="querySearchAsync"
                placeholder="请输入内容"
                @select="handleSelect">
                <template #footer>
                    <ux-button link size="small" @click="handleClear">清空</ux-button>
                </template>
            </ux-autocomplete>
        </div>
    </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const headerSlotState = ref('')
const footerSlotstate = ref('')

const links = ref([])
const loadAll = () => {
    return [
        { value: '组件总览' },
        { value: '基础组件' },
        { value: '布局容器' },
        { value: '色彩' },
        { value: '边框' },
        { value: '字体' },
        { value: '图标' },
        { value: '按钮' },
        { value: '文字链接' },
        { value: '表单组件' },
        { value: '级联选择器' },
        { value: '多选框' },
        { value: '颜色选择器' },
        { value: '日期选择器' },
        { value: '日期时间选择器' },
        { value: '表单' },
        { value: '输入框' },
        { value: '计数器' },
        { value: '单选框' },
        { value: '评分' },
        { value: '选择器' },
        { value: '滑块' },
        { value: '开关' },
        { value: '时间选择器' },
        { value: '穿梭框' },
        { value: '上传' }
    ]
}
let timeout
const querySearchAsync = (queryString, cb) => {
    const results = queryString ? links.value.filter(createFilter(queryString)) : links.value
    clearTimeout(timeout)
    timeout = setTimeout(() => {
        cb(results)
    }, 3000 * Math.random())
}
const createFilter = (queryString) => {
    return (restaurant) => {
        return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
    }
}
const handleSelect = (item) => {
    console.log(item)
}
onMounted(() => {
    links.value = loadAll()
})
const footerAutocompleteRef = ref()
const handleClear = () => {
    footerSlotstate.value = ''
    footerAutocompleteRef.value.getData()
}
</script>

<style>
.demo {
    display: flex;
}
.demo > div {
    flex: 1;
    text-align: center;
}
.demo > div > .el-autocomplete {
    width: 50%;
}
.demo > div:not(:last-child) {
    border-right: 1px solid var(--ux-border-color);
}
</style>

```

