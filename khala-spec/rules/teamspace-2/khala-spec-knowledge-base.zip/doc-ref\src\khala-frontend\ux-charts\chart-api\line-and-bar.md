## LineAndBar API

### LineAndBar 属性

| 参数名 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| dataList | 数据项数组（可混合 bar 和 line 类型） | ^[Array]见下表[LineAndBarDataItem](#lineandbardataitem) | — |
| config | 配置项 | 见下表[LineAndBarConfig](#lineandbarconfig) | — |

### LineAndBarDataItem

| 属性名 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| name | 系列名称 | ^[string] | — |
| type | 图表类型 | ^[string]`'bar' \| 'line'` | — |
| data | 数据项 | ^[Array]`{ name: string, value: string \| number }` | — |
| unit | 单位 | ^[string] | — |

#### LineAndBarConfig

| 属性名 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| showLegend | 是否显示图例 | ^[boolean] | true |
| legendPosition | 图例位置 | ^[object] | {} |
| legendWidth | 图例宽度 | ^[number] | — |
| legendHeight | 图例高度 | ^[number] | — |
| gridPosition | 网格位置 | ^[object] | {} |
| unit | 单位 | ^[Array]`string` | [] |
| smooth | 是否平滑曲线 | ^[boolean] | — |
| showSymbol | 是否显示标记 | ^[boolean] | true |
| symbol | 标记图形 | ^[any] | — |
| symbolSize | 标记大小 | ^[number] | — |
| barWidth | 柱子宽度 | ^[number] | — |
| showYLabel | 是否显示Y轴标签 | ^[boolean] | true |
| yLineBorder | Y轴线边框 | ^[boolean] | false |
| axisLabel | 坐标轴标签 | ^[Array]`string` | [] |
| showXLabel | 是否显示X轴标签 | ^[boolean] | true |
| xAxisMargin | X轴边距 | ^[number] | 8 |
| xLabelRotate | X轴标签旋转角度 | ^[number] | 0 |
| mainColor | 主色 | ^[Array]`string` | commonConfig.mainColor |
| tooltipFormatter | 提示框格式化 | ^[Function]`(params: any) => string` | — |
| silent | 是否静默 | ^[boolean] | false |
| legendFormatter | 图例格式化 | ^[Function]`(name: string) => string` | — |
| yLabelFormatter | Y轴标签格式化 | ^[Function]`(value: any) => string` | — |
| xLabelFormatter | X轴标签格式化 | ^[Function]`(value: any) => string` | — |
