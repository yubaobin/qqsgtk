---
name: yx:bootstrap-app
description: 在已有可运行的 Khala 基础项目上生成业务代码（quick 默认直接改 / standard 写 proposal+tasks 再改 / strict 写 requirement+proposal+tasks 再改）
tags: [workflow, khala, generator]
---

使用 `khala-spec-bootstrap-app` skill，在**已存在的可运行 Khala 基础项目**上按模式生成业务代码。

> **底层逻辑（2026-09 重构）**：运行环境中必须已存在可运行的 Khala 基础项目（Khala 父 pom + `admin-biz` + `log-biz` + `khala-commons` starter + `SuperController`/`Service`/`Mapper` 基类 + 前端 Vue3 + UX-UP 组件源码）。**本指令不生成脚手架、不写 prototype、不写 architecture、不写 deploy 产物、不写 archive。**

---

## 三模式（按复杂度递进）

| 模式 | 触发 | 工作流 | 中间产物 | 调下游 skill |
|------|------|--------|----------|--------------|
| **quick**（默认） | 不传 `--mode` 或显式 `--mode quick` | AI Agent 直接用 Edit/Write 工具改代码 | 无 | **不调任何下游 skill** |
| **standard** | `--mode standard` | AI 写 proposal + tasks → 按 tasks 改代码 | `khala-spec/changes/<关键词>/{proposal.md, tasks.md}` | `/yx:propose` → `/yx:apply` |
| **strict** | `--mode strict` | AI 写 requirement → proposal → tasks → 按 tasks 改代码 | + `khala-spec/rd/requirements/changes/<v>/<v>-<domain>.md` | `/yx:require` → `/yx:propose` → `/yx:apply` |

---

## 命令入口

```bash
/yx:bootstrap-app <关键词> [--mode quick|standard|strict] [--assume-base-project]
```

| 参数 | 必填 | 说明 |
|------|------|------|
| `<关键词>` | 是 | 中文；用作代码模块名前缀、产物路径 |
| `--mode <quick\|standard\|strict>` | 否 | 默认 `quick` |
| `--assume-base-project` | 否 | 跳过 Khala 基础项目存在性校验（不推荐，仅在脚手架已就绪但快速推进时使用） |

合法示例：

```bash
/yx:bootstrap-app 算力集市小程序                          # 默认 quick：AI 直接改代码
/yx:bootstrap-app 内部报销小工具 --mode standard          # standard：写 proposal+tasks 后改代码
/yx:bootstrap-app 算力集市小程序 --mode strict            # strict：写 requirement+proposal+tasks 后改代码
```

---

## Khala 模块复用强约束（任何模式都必遵守）

> ⚠️ 禁止以「项目复杂 / token 预算 / 代码不够好 / 我理解错了」等借口删除 Khala 已提供源码：

- **后端**：保留 `backend/pom.xml` 中所有 `com.eshore.khala:*` 依赖（admin-biz / log-biz / khala-commons 40+ starter）；业务 Controller/Service/Mapper **必须**继承 Khala `SuperController`/`SuperService`/`SuperMapper` 基类；禁止替换为 Spring Boot 原生 `BaseController`/`IService`/`BaseMapper`
- **前端**：保留 `khala-spec/doc-ref/src/khala-frontend/ux-up/` 下的 UX-UP 组件源码；业务页面表格/表单/对话框/树/选择器等场景 **必须**用 `<ux-table>`/`<ux-form>`/`<ux-dialog>`/`<ux-tree>`/`<ux-select>` 等 UX-UP 组件；禁止用 `el-table`/`el-form`/`element-plus`/`ant-design-vue` 等第三方组件库替换

完整约束、白名单/黑名单、AI 自检协议、反例 thinking 案例见
[`khala-spec-bootstrap-app` SKILL §⚠️ Khala 模块复用约束](../skills/khala-spec-bootstrap-app/SKILL.md)。

---

## doc-ref 引用规范（防 AI 凭训练记忆臆造）

Khala 框架代码片段（后端 starter / Super* 基类 / KhalaProperties / 前端 UX-UP 组件 Props/Events）**必须**先查 `khala-spec/doc-ref/src/khala-{backend,frontend}/`，禁止凭训练记忆臆造。doc-ref + wiki 都查不到时，AI Agent 必须显式标注「未核对，凭通用模式推导」在 `.phase-summaries/<mode>-summary.md`。

详见 [`khala-spec-bootstrap-app` SKILL §doc-ref 引用规范](../skills/khala-spec-bootstrap-app/SKILL.md)。

---

## 详细文档

完整三模式工作流、AI 自检协议、状态机 schema、Common Mistakes 见
[`khala-spec-bootstrap-app` skill](../skills/khala-spec-bootstrap-app/SKILL.md)。
