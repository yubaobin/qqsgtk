package com.eshore.khala.example.sentinel;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * Sentinel 限流降级示例
 *
 * <p>使用 @SentinelResource 注解定义资源并配置限流降级处理</p>
 * <p>Khala 已内置限流统一响应：Web 返回 429 + CommonResult，WebFlux 返回 429 + CommonResult</p>
 */
@Slf4j
@RestController
@RequestMapping("/api/sentinel")
public class SentinelFlowController {

    /**
     * 基本限流
     *
     * <p>value: 资源名称，在 Sentinel Dashboard 中配置规则</p>
     * <p>blockHandler: 限流时的处理方法</p>
     */
    @GetMapping("/query")
    @SentinelResource(value = "query", blockHandler = "queryBlockHandler")
    public String query(@RequestParam String id) {
        return "查询结果: " + id;
    }

    /**
     * 限流处理方法
     *
     * <p>方法签名需与原方法一致，最后增加 BlockException 参数</p>
     */
    public String queryBlockHandler(String id, BlockException e) {
        log.warn("请求被限流: id={}", id);
        return "系统繁忙，请稍后重试";
    }

    /**
     * 限流 + 降级
     *
     * <p>blockHandler: 限流处理</p>
     * <p>fallback: 业务异常时的降级处理</p>
     */
    @GetMapping("/detail")
    @SentinelResource(value = "detail",
            blockHandler = "detailBlockHandler",
            fallback = "detailFallback")
    public String detail(@RequestParam String id) {
        // 模拟业务异常
        if ("error".equals(id)) {
            throw new RuntimeException("业务异常");
        }
        return "详情: " + id;
    }

    public String detailBlockHandler(String id, BlockException e) {
        return "请求被限流，请稍后重试";
    }

    public String detailFallback(String id, Throwable t) {
        log.error("业务异常降级: id={}", id, t);
        return "服务暂时不可用，请稍后重试";
    }

    /**
     * 默认限流处理
     *
     * <p>不指定 blockHandler 时，Khala 会统一返回 429 状态码 + CommonResult 错误信息</p>
     * <p>Web MVC: 返回 HTTP 429 + {"code": xxx, "msg": "xxx"}</p>
     * <p>WebFlux: 返回 HTTP 429 + {"code": xxx, "msg": "xxx"}</p>
     */
    @GetMapping("/list")
    public String list() {
        return "列表数据";
    }
}
