---
name: yx:design
description: 根据需求规格完成概要设计，产出模块划分、技术约束和质量等级标注（架构师角色）
tags: [workflow, yx-sdd, architecture]
---

## 执行角色
架构师

## 执行粒度
每次概要设计时执行一次（项目级或版本级）

## 前置条件
- 需求规格目录已确认（需求规格说明书存在于 `khala-spec/rd/requirements/`目录）
- 原型设计如有则一并输入（`khala-spec/prototype/` 目录）

## 核心目标
根据需求规格（和原型）完成总体架构设计。**只做概要设计，不做过细设计。** 核心是回答三个问题：
1. 系统分几个模块？
2. 模块间如何交互？
3. 用什么技术栈？

详细设计交给每个模块的 `/yx:propose` 阶段。

---

使用 `/khala-spec-design` skill 执行概要设计工作流。
