/**
 * 校验
 */
// 身份证
export const checkIdNum = (rule, value, callback) => {
    let pass = true
    const city = {
        11: '北京',
        12: '天津',
        13: '河北',
        14: '山西',
        15: '内蒙古',
        21: '辽宁',
        22: '吉林',
        23: '黑龙江',
        31: '上海',
        32: '江苏',
        33: '浙江',
        34: '安徽',
        35: '福建',
        36: '江西',
        37: '山东',
        41: '河南',
        42: '湖北',
        43: '湖南',
        44: '广东',
        45: '广西',
        46: '海南',
        50: '重庆',
        51: '四川',
        52: '贵州',
        53: '云南',
        54: '西藏',
        61: '陕西',
        62: '甘肃',
        63: '青海',
        64: '宁夏',
        65: '新疆',
        71: '台湾',
        81: '香港',
        82: '澳门',
        91: '国外'
    }
    if (!value || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(value)) {
        callback(new Error('身份证号格式错误'))
        pass = false
    } else if (!city[value.substr(0, 2)]) {
        callback(new Error('地址编码错误'))
        pass = false
    } else {
        if (value.length === 18) {
            const valueAry = value.split('')
            const factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
            const parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2]
            let sum = 0
            let ai = 0
            let wi = 0
            for (let i = 0; i < 17; i++) {
                ai = valueAry[i]
                wi = factor[i]
                sum += ai * wi
            }
            if (`${parity[sum % 11]}` !== valueAry[17]) {
                callback(new Error('校验位错误'))
                pass = false
            }
        }
    }
    if (pass) {
        callback()
    }
}

// 电话号码
export const checkPhone = (rule, value, callback) => {
    const phoneReg = /^1[3|4|5|7|8][0-9]{9}$/

    if (!value) {
        return callback(new Error('电话号码不能为空'))
    } else if (phoneReg.test(value)) {
        callback()
    } else {
        callback(new Error('请输入正确电话号码'))
    }
}

// 邮箱
export const checkEmail = (rule, value, callback) => {
    const emailReg = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

    if (!value) {
        return callback(new Error('邮箱不能为空'))
    } else if (emailReg.test(value)) {
        callback()
    } else {
        callback(new Error('请输入正确的邮箱地址'))
    }
}

// 宽松手机校验：1开头的11位数字（更好的向前兼容）
export const isPhone = (phone) => {
    const phoneReg = /^1\d{10}$/
    return phoneReg.test(phone)
}

export const checkCode = (rule, value, callback) => {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(value)) {
        callback(new Error('请输入只包含大小写字母、数字、特殊符号 _ 、 - 的字符'))
    } else {
        callback()
    }
}
export const checkDay = (rule, value, callback) => {
    if (value < 0) {
        callback(new Error('请输入正确的天数'))
    } else {
        callback()
    }
}
export const checkUnsignedInt = (rule, value, callback) => {
    if (isNaN(parseInt(value)) || value < 0) {
        callback(new Error('请输入正确的数量'))
    } else if (value > 100000) {
        callback(new Error('请输入 1-100000 的数量'))
    } else {
        callback()
    }
}
