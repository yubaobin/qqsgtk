/**
 * 封装请求
 */
import axios from 'axios'
import qs from 'qs'
import { UxMessage } from 'ux-up'
import config from '@/config'
import { getToken } from './token'
import { processSignature, buildQueryString } from './signature'
import { processEncryption, processDecryption } from './crypto'
import { useUserStoreHook } from '@/store/modules/user'
import * as ParseStreamUtils from './parse-stream'
import { omit } from 'lodash-es'

let instance = axios.create({
    baseURL: config.apiPath,
    method: 'post',
    timeout: 20000,
    // 发送 Cookie
    withCredentials: true,
    headers: {
        Accept: '*',
        'Content-Type': 'application/json',
        'x-app-header': config.app
    },
    paramsSerializer: {
        serialize: buildQueryString
    }
})
// 拦截请求
instance.interceptors.request.use(
    (req) => {
        const userStore = useUserStoreHook()
        const tenantId = userStore.curTenant?.id

        if (tenantId) {
            req.headers['x-tenant-header'] = tenantId
        }
        if (req.token !== false && !req.headers['Authorization']) {
            const token = getToken()
            if (token && token !== 'undefined') {
                req.headers['Authorization'] = 'Bearer ' + getToken()
            }
        }

        processSignature(req, config)
        processEncryption(req, config)

        return req
    },
    (err) => {
        UxMessage({ message: err, type: 'error' })
        return Promise.reject(err)
    }
)
// 拦截返回
instance.interceptors.response.use(
    (res) => {
        if (res.headers['content-type'] && !res.headers['content-type'].includes('application/json')) {
            return res
        }

        processDecryption(res)

        if (res.data.code === 1001 || res.data.code === 1000) {
            // 第三方登录成功后未绑定账号的情况
            return res.data.data
        }
        if (res.data.code === 1101) { // 加密配置过期，重新获取加密配置
            UxMessage.error(res.data.message || '加密配置过期')
            setTimeout(() => {
                window.location.reload()
            }, 3000)
        }
        if (res.data.code !== 0) {
            UxMessage.error(res.data.message || '接口错误')
            return Promise.reject(res.data.message || '接口错误')
        }
        // 待把res.data.data改为res.data后同时改view页面，涉及很多个页面
        return res.data.data
    },
    (error) => {
        let errorMsg = error.message
        if (error.response.data) {
            if (error.response.data instanceof Blob) {
                errorMsg = '文件导出失败！'
            } else {
                errorMsg = error.response.data.message || error.response.data.error
            }
        }
        if (error.response) {
            const userStore = useUserStoreHook()
            switch (error.response.status) {
                case 401:
                    // 返回 401 清除token信息并跳转到登录页面
                    if (error.config && error.config.ignore401) {
                        UxMessage.error('请登录')
                        return Promise.reject(errorMsg)
                    }
                    userStore.clearUserInfo()
                    // 如果状态码为 401，则延迟 3 秒后重新加载页面
                    setTimeout(() => {
                        window.location.reload()
                    }, 3000)
                    break
                case 403:
                    break
                case 500:
                    break
                default:
                    break
            }
        }
        UxMessage.error(errorMsg)
        return Promise.reject(errorMsg)
    }
)
export const get = (serviceId, url, params, config = {}) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.get(reqUrl, { params: params, ...config })
}
export const get1 = (serviceId, url, params, responseType) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.get(reqUrl, { params: params, responseType: responseType })
}
export const post = (serviceId, url, params, config = {}) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.post(reqUrl, params, config)
}
export const post1 = (serviceId, url, params, headers) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.post(reqUrl, params, headers)
}
export const put = (serviceId, url, params) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.put(reqUrl, params)
}
export const del = (serviceId, url, params) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.delete(reqUrl, params)
}
export const upload = (serviceId, url, params, config = {}) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.post(reqUrl, params, {
        headers: {
            'Content-type': 'multipart/form-data',
            'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://trusted.cdn.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'; frame-ancestors 'none';",
            'X-XSS-Protection': '1; mode=block',
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'Referrer-Policy': 'strict-origin-when-cross-origin'
        },
        ...config
    })
}
export const download = (serviceId, url, params) => {
    const reqUrl = jointUrl(serviceId, url)
    return instance.get(reqUrl, { params: params, responseType: 'blob' })
}

export const streamPost = async (serviceId, url, params, config = {}) => {
    const reqUrl = jointUrl(serviceId, url)
    const controller = config.controller
    const _config = omit(config, ['controller'])
    const response = await instance.post(reqUrl, params, {
        responseType: 'stream',
        adapter: 'fetch',
        timeout: null,
        signal: controller ? controller.signal : undefined,
        ..._config
    })
    const reader = response.data
        .pipeThrough(new TextDecoderStream())
        .pipeThrough(ParseStreamUtils.splitStream('\n'))
        .getReader()
    return reader
}

export { instance }

export const fetch = instance

export default async (url = '', params = {}, option = {}) => {
    if (!url) {
        return Promise.reject('params url not exist!')
    }
    let method = option.method || 'post'
    // 默认所有接口需要token
    let token = option.token || true
    // 默认所有接口需要签名
    let signature = option.signature || true
    let encryption = option.encryption || true
    switch (method) {
        case 'get':
            return instance.get(url, {
                params: params,
                headers: option.headers || {},
                token: token,
                signature: signature,
                encryption: encryption
            })
        case 'upload':
            return instance.post(url, params, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
        case 'getDownload':
            return instance.get(url, {
                params: params,
                responseType: 'blob'
            })
        case 'download':
            return instance.post(url, params, {
                responseType: 'blob'
            })
        case 'postForm':
            return instance.post(url, qs.stringify(params), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                token: token,
                signature: signature,
                encryption: encryption,
                responseType: option.responseType
            })
        case 'postQuery':
            return instance.post(url, null, Object.assign(option, { params }))
        case 'post':
            return instance.post(url, params, {
                headers: option.headers || {},
                token: token,
                signature: signature,
                encryption: encryption,
                responseType: option.responseType
            })
        case 'put':
            return instance.put(url, params, {
                headers: option.headers || {},
                token: token,
                encryption: encryption,
                signature: signature
            })
        case 'patch':
            return instance.patch(url, params, {
                headers: option.headers || {},
                token: token,
                encryption: encryption,
                signature: signature
            })
        case 'delete':
            return instance.delete(url, {
                params: params,
                token: token,
                encryption: encryption,
                signature: signature
            })
        default:
            return Promise.reject(`unknown request method '${method}'`)
    }
}

export const jointUrl = (serviceId, url) => {
    if (config.model === 'STANDALONE') {
        return url
    }
    return serviceId + url
}
