package com.example.crud;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller 层示例
 */
@Tag(name = "用户管理")
@RestController
@RequestMapping("/api/user")
public class SysUserController {

    @Autowired
    private SysUserService sysUserService;

    /**
     * 查询用户列表（分页）
     */
    @Operation(summary = "查询用户列表", description = "分页查询用户列表")
    @GetMapping("/list")
    public CommonResult<IPage<SysUserRespVO>> list(UserPageReqVO req) {
        return CommonResult.success(sysUserService.pageUsers(req));
    }

    /**
     * 查询用户详情
     */
    @Operation(summary = "查询用户详情", description = "根据 ID 查询用户详情")
    @GetMapping("/get")
    public CommonResult<SysUserRespVO> getById(@RequestParam Long id) {
        return CommonResult.success(sysUserService.getUserById(id));
    }

    /**
     * 创建用户
     */
    @Operation(summary = "创建用户", description = "创建新用户，用户名不可重复")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "创建成功"),
            @ApiResponse(responseCode = "400", description = "参数校验失败"),
            @ApiResponse(responseCode = "409", description = "用户名已存在")
    })
    @PostMapping("/create")
    public CommonResult<Long> create(@RequestBody UserCreateReqVO reqVO) {
        return CommonResult.success(sysUserService.createUser(reqVO));
    }

    /**
     * 更新用户
     */
    @Operation(summary = "更新用户", description = "全量或部分更新用户信息")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "更新成功"),
            @ApiResponse(responseCode = "400", description = "参数校验失败"),
            @ApiResponse(responseCode = "404", description = "用户不存在")
    })
    @PostMapping("/update")
    public CommonResult<Boolean> update(@RequestBody UserUpdateReqVO reqVO) {
        return CommonResult.success(sysUserService.updateUser(reqVO));
    }

    /**
     * 删除用户（逻辑删除）
     */
    @Operation(summary = "删除用户", description = "根据 ID 删除用户")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "删除成功"),
            @ApiResponse(responseCode = "404", description = "用户不存在")
    })
    @PostMapping("/delete")
    public CommonResult<Boolean> delete(@RequestBody UserDeleteReqVO reqVO) {
        return CommonResult.success(sysUserService.removeUserById(reqVO.getId()));
    }

    /**
     * 批量删除用户
     */
    @Operation(summary = "批量删除用户", description = "根据 ID 列表批量删除用户")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "删除成功"),
            @ApiResponse(responseCode = "400", description = "参数校验失败")
    })
    @PostMapping("/delete-batch")
    public CommonResult<Boolean> deleteBatch(@RequestBody UserBatchDeleteReqVO reqVO) {
        return CommonResult.success(sysUserService.removeByIds(reqVO.getIds()));
    }
}
