package com.eshore.khala.example.captcha;

import com.eshore.khala.common.model.CommonResult;
import com.eshore.khala.starter.captcha.core.code.provider.CodeCaptchaManager;
import com.eshore.khala.starter.captcha.core.code.vo.CaptchaVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 短信/邮箱验证码示例
 *
 * <p>通过 CodeCaptchaManager 统一发送和校验短信/邮箱验证码</p>
 * <p>验证码自动生成、存储到 Redis、过期管理</p>
 */
@RestController
@RequestMapping("/api/captcha/code")
@RequiredArgsConstructor
public class CodeCaptchaController {

    private final CodeCaptchaManager codeCaptchaManager;

    // ==================== 发送验证码 ====================

    /**
     * 发送短信验证码
     *
     * <p>参数说明：</p>
     * <p>- type: 验证码类型，"sms" 短信 / "email" 邮箱</p>
     * <p>- clientId: 应用标识，默认 "khala"</p>
     * <p>- template: 模板名称，对应短信/邮件配置中的 template key，如 "login"、"register"</p>
     * <p>- target: 接收目标（手机号/邮箱地址）</p>
     */
    @PostMapping("/send-sms")
    public CommonResult<CaptchaVO> sendSmsCode(@RequestParam String mobile) {
        return codeCaptchaManager.send("sms", "khala", "login", mobile);
    }

    /**
     * 发送注册短信验证码（使用 register 模板）
     */
    @PostMapping("/send-sms-register")
    public CommonResult<CaptchaVO> sendRegisterSmsCode(@RequestParam String mobile) {
        return codeCaptchaManager.send("sms", "khala", "register", mobile);
    }

    /**
     * 发送邮箱验证码
     */
    @PostMapping("/send-email")
    public CommonResult<CaptchaVO> sendEmailCode(@RequestParam String email) {
        return codeCaptchaManager.send("email", "khala", "login", email);
    }

    // ==================== 校验验证码 ====================

    /**
     * 短信/邮箱验证码校验流程
     *
     * <p>验证码校验支持两种方式：</p>
     *
     * <p>方式一：@Captcha 注解自动校验（推荐）</p>
     * <p>在需要校验的接口方法上添加 @Captcha 注解，框架自动校验请求中的验证码参数</p>
     * <p>详见 captcha-annotation.java</p>
     *
     * <p>方式二：CaptchaServiceFactory 手动校验</p>
     * <p>调用 captchaServiceFactory.verify(params) 手动校验</p>
     * <p>params 中需包含 captchaType、目标地址和验证码</p>
     *
     * <p>校验参数结构：</p>
     * <pre>
     * {
     *   "captchaType": "sms",      // 或 "email"
     *   "target": "13800138000",    // 手机号或邮箱
     *   "code": "123456"           // 用户输入的验证码
     * }
     * </pre>
     */
}
