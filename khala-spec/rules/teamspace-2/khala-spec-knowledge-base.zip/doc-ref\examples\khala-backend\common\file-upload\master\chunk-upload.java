package com.example.fileupload;

import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * 分片上传示例
 */
@Tag(name = "文件上传管理")
@RestController
@RequestMapping("/api/upload")
public class ChunkUploadController {

    /**
     * 上传分片
     */
    @Operation(summary = "上传分片", description = "上传文件分片")
    @PostMapping("/chunk")
    public CommonResult<String> uploadChunk(
            @RequestParam("file") MultipartFile file,
            @RequestParam("chunkNumber") int chunkNumber,
            @RequestParam("chunkSize") long chunkSize,
            @RequestParam("currentChunkSize") long currentChunkSize,
            @RequestParam("totalSize") long totalSize,
            @RequestParam("identifier") String identifier,
            @RequestParam("filename") String filename,
            @RequestParam("totalChunks") int totalChunks) {

        // 保存分片到临时目录
        // mergeChunks(identifier, totalChunks, filename);

        return CommonResult.success("分片上传成功");
    }

    /**
     * 合并分片
     */
    @Operation(summary = "合并分片", description = "合并所有分片文件")
    @PostMapping("/merge")
    public CommonResult<String> mergeChunks(@RequestParam String identifier,
                                            @RequestParam int totalChunks,
                                            @RequestParam String filename) {
        // 合并所有分片文件
        return CommonResult.success("文件合并成功");
    }
}
