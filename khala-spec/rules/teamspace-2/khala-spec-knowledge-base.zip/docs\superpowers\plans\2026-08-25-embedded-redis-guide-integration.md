# embedded-redis 指南整合进 bootstrap-app Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把嵌入式 Redis 使用指南（10 节）通用化整合进 `khala-spec-bootstrap-app` skill，让 AI Agent 在阶段 4 脚手架生成 + 阶段 6-8 启动/排错环节能快速定位 Redis 相关问题。

**Architecture:** 新增独立 reference 文档 `references/embedded-redis-guide.md` 放完整 10 节通用化内容；主 SKILL.md 与 stage-checkpoints.md 通过摘要 + 跳转链接引用，避免主文档臃肿；阶段 4 启动验证脚本增加 `[bootstrap]` 日志断言，把"Redis 是否真的就绪"变成可机器判定的强门禁。

**Tech Stack:** Markdown / KB 资产（无代码）— AI Agent 指令文档体系。

---

## File Structure

| 文件 | 操作 | 责任 |
|---|---|---|
| `skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md` | **新建** | 完整 10 节嵌入式 Redis 通用化指南 |
| `skills/khala-spec-bootstrap-app/SKILL.md` | **修改** | §Scaffold Conventions 表格第 3 行 + AI Rules 注入片段；§Common Mistakes 表格追加 1 行 |
| `skills/khala-spec-bootstrap-app/references/stage-checkpoints.md` | **修改** | 阶段 4 启动验证脚本末尾追加 `[bootstrap]` 日志断言；失败回退表格"后端启动超时"行加 reference 链接 |

---

## Task 1: 新增 `references/embedded-redis-guide.md`（10 节通用化）

**Files:**
- Create: `skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md`

**通用化约定**（写文件时必须遵守）：
- `DemoApplication` → `*Application` 主启动类
- `khala.redis.password` → `spring.data.redis.password`（Spring Boot 通用命名）
- "captcha starter" → "某些 Spring Boot starter（如验证码、限流等）"
- 端口/密码等参数标注"推荐默认值，与 application*.yml 严格对齐；按项目调整"
- 跨平台命令：Windows `netstat -ano | findstr <port>` + `taskkill /pid <PID> /f`；macOS/Linux `lsof -i :<port>` + `kill -9 <PID>`

- [ ] **Step 1：写文件 10 节内容**

完整写入以下内容到 `skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md`：

````markdown
<!-- khala-spec:path-scope: user-project -->

# 嵌入式 Redis 使用指南（embedded-redis）

> 本文件是 `khala-spec-bootstrap-app` 的可独立引用 reference。阶段 4 脚手架生成的代码必须遵守本文规约；阶段 4 启动验证、阶段 6-8 启动/排错环节遇到 Redis 相关问题时**优先查阅本文 §7 故障排查清单**。

---

## 1. 概述

本项目通过 embedded-redis 在 JVM 内启动 `redis-server` 子进程，免去本地 debug 时对外部 Redis 的依赖。`application-dev.yml` 把 Redis 连接指向 `127.0.0.1:<REDIS_PORT>` / `<REDIS_PASSWORD>`，与嵌入式实例配套。

---

## 2. 关键参数（与 application*.yml 严格对齐）

| 项 | 推荐默认值 | 说明 |
|---|---|---|
| 端口 | `16379` | 避免与系统 `6379` 冲突 |
| 密码 | `bootstrap123` | 与 Spring 配置一致 |
| bind | `127.0.0.1` | 仅本机可连，不暴露到局域网 |
| 最大内存 | `128M` | 嵌入式开发足够 |
| 启用 profile | `dev` / `local` / `test` | 生产 profile 默认不启用 |

> **任何一项调整必须同步改 application*.yml 和 `EmbeddedRedisConfig` 中的常量。**

---

## 3. 启动时序（架构约束，最重要）

主启动类 `*Application.main()` 第一行必须调用：

```java
public static void main(String[] args) throws UnknownHostException {
    EmbeddedRedisConfig.ensureRunningForDev();      // ← 必须在 SpringApplication.run() 之前
    SpringApplication.run(*Application.class, args);
}
```

**为什么必须在 main 而不是 `@PostConstruct` / `@Configuration`**：实测过某些 Spring Boot starter（如验证码、限流等）会在 Spring 上下文早期抢连 Redis，**若嵌入式 Redis 还没起来会直接抛 `BeanCreationException` 导致整个应用无法启动**。`main()` 中显式调用确保 Redis 进程早于任何 bean 创建。

---

## 4. 修改禁忌

| 操作 | 是否允许 | 后果 |
|---|---|---|
| 移除 `main()` 里那行调用 | ❌ | 重现"连接被拒"问题 |
| 把 `ensureRunningForDev()` 改回 `@PostConstruct` / `@Configuration` | ❌ | 回到 starter 抢先连接的老问题 |
| 加 `@Import(EmbeddedRedisConfig.class)` | ❌ | 会双启动，可能并发绑端口失败 |
| 加 `-Dembedded.redis.skip=true` | ✅ | 一键跳过，调试外部 Redis 时用 |
| 改端口 / 密码 | ⚠️ 必须同步改 yml | 否则连不上 |
| 移除 `@Profile` 限定改成 prod 也启用 | ❌ | prod 启动会绑 16379 与真实 Redis 抢端口 |

---

## 5. 一键跳过开关

```bash
# JVM 参数
-Dembedded.redis.skip=true

# 或环境变量
EMBEDDED_REDIS_SKIP=true
```

适用场景：本地想连外网 Redis / 调试 Redis 客户端本身 / 验证 Redis 集群配置。

---

## 6. 关闭与清理

- **自动**：JVM shutdown hook 监听退出事件（`Runtime.getRuntime().addShutdownHook` 已注册），IDE 停 debug 时自动停 redis-server
- **手动**：调用 `EmbeddedRedisConfig.shutdown()`
- **强制清理**（进程没退干净时）：
  - Windows：`netstat -ano | findstr <port>` → `taskkill /pid <PID> /f`
  - macOS / Linux：`lsof -i :<port>` → `kill -9 <PID>`

---

## 7. 故障排查清单（按现象分类）

| 现象 | 原因 | 处理 |
|---|---|---|
| 启动报 `BindException: Address already in use` | 端口被别的进程占 | 按 §6 强制清理占用进程 |
| 启动报 `Could not find redis-server executable` | 首次运行未解压二进制 | 检查 `~/.embedded-redis/` 是否可写；首次会自动解压 |
| Spring 报 `Connection refused` 但有 `[bootstrap]` 日志 | `[bootstrap]` 启动嵌入式 Redis 之后 Redis start() 中途抛异常 | 看 `[bootstrap] 启动失败` 日志 |
| Spring 报 `Connection refused` 且完全无 `[bootstrap]` 日志 | `ensureRunningForDev()` 没在 `main()` 第一行执行 | 检查 `*Application.main()` |
| Spring 报 `ERR Client sent AUTH, but no password is set` | 端口被别的无密码 Redis 占 | 按 §6 杀进程 |
| 某些 starter（验证码/限流等）报 `BeanCreationException` | 嵌入式 Redis 还没起来 starter 就抢连 | 确认 `main()` 调用顺序（§3） |
| JDK 17 `InaccessibleObjectException` 模块限制 | 缺 `--add-opens` | 在 IDE 启动配置的 VM Options 加：<br>`--add-opens java.base/java.lang=ALL-UNNAMED`<br>`--add-opens java.base/java.nio=ALL-UNNAMED`<br>`--add-opens java.base/sun.nio.ch=ALL-UNNAMED` |

---

## 8. 依赖

```xml
<dependency>
    <groupId>com.github.codemonstur</groupId>
    <artifactId>embedded-redis</artifactId>
    <version>1.4.3</version>
</dependency>
```

该 fork（codemonstur/embedded-redis）已修过 JDK 17 兼容问题。**不要回退到 `it.ozimov:embedded-redis`**（最后一个版本 0.7.3 不兼容 JDK 17）。

---

## 9. 未来扩展指引

要替换实现时只需改 `EmbeddedRedisConfig.ensureRunningForDev()` 的内部，调用方（main）不变：

- 换 testcontainers-redis：内部改 `GenericContainer` 启动；profile/跳过开关保持
- 换本地 Redis：保留 main 调用 + 一律返回；跳过开关改名 `redis.skip`
- 关闭嵌入式 Redis：保留 main 调用 + 加 `-Dembedded.redis.skip=true` 作为默认

---

## 10. 快速验证脚本

每次改 `EmbeddedRedisConfig` 后，跑一遍：

```bash
# 1. 编译
mvn -DskipTests=true clean compile

# 2. 字节码确认 main 顺序
javap -c -p -cp target/classes <主启动类全限定名> | grep -A 8 "public static void main"
# 期望：第 0 行是 invokestatic EmbeddedRedisConfig.ensureRunningForDev

# 3. debug 启动后 grep 启动日志
grep -E "\[bootstrap\]|Started <主启动类短名>" env.log
# 期望：[bootstrap] 启动嵌入式 Redis 进程（端口 16379）
#       [bootstrap] 嵌入式 Redis 已就绪：127.0.0.1:16379（password 已设置）
#       Started <主启动类短名> in X.XXX seconds
```
````

- [ ] **Step 2：校验文件落地**

Run: `ls -la skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md && wc -l skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md`
Expected: 文件存在；行数约 130-150 行（10 节 + 表格 + 列表）

- [ ] **Step 3：通用化校验（禁止业务特定痕迹遗留）**

Run:
```bash
grep -nE "DemoApplication|khala\.redis|captcha starter" skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md || echo "PASS: 无业务特定痕迹"
```
Expected: `PASS: 无业务特定痕迹`（grep 无匹配则 echo 触发）

- [ ] **Step 4：跨平台命令校验**

Run:
```bash
grep -nE "netstat -ano|lsof -i" skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md
```
Expected: 至少 2 行匹配（Windows netstat + macOS/Linux lsof 都有）

- [ ] **Step 5：commit**

按本仓库约定（CLAUDE.md 第 5 条）：**只 `add` 不 `commit`**——KB 文档类修改可正常 `add`，但代码/脚本类文件不 commit。本任务为 Markdown 文档，可正常 commit；执行：

```bash
git add skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md
git commit -m "feat(bootstrap-app): 新增嵌入式 Redis 使用指南 reference

- 10 节通用化内容：概述/参数/启动时序/修改禁忌/跳过开关/关闭清理/故障排查/依赖/扩展/验证脚本
- 通用化业务特定痕迹：DemoApplication → *Application；captcha starter → starter；khala.redis.* → spring.data.redis.*
- 跨平台命令：Windows netstat/taskkill + macOS/Linux lsof/kill
- 与 application*.yml 严格对齐的默认参数表
- 阶段 4 启动验证 + 阶段 6-8 排错的独立 reference"
```

---

## Task 2: 修改 `SKILL.md` §Scaffold Conventions 表格第 3 行（Redis 列）

**Files:**
- Modify: `skills/khala-spec-bootstrap-app/SKILL.md:299-301`（"三条硬约定"表格第 3 行）

- [ ] **Step 1：定位原行**

Run: `grep -n "embedded-redis\|Redis 内存版" skills/khala-spec-bootstrap-app/SKILL.md | head -10`
Expected: 命中 §Scaffold Conventions 表格第 3 行（约 line 299-301）

- [ ] **Step 2：替换表格第 3 行**

定位原行（精确匹配）：
```
| 3 | **Redis** | embedded-redis 内存版 | Maven 依赖 `it.ozimov:embedded-redis`（或 `com.github.codemonstur:embedded-redis`）；`@Bean` 注册本地 `redis-server` 子进程，端口随机 | `redis.clients:lettuce/jedis` 指向 `localhost:6379` 真实 Redis；`docker run -d redis` |
```

替换为：
```
| 3 | **Redis** | embedded-redis 内存版（固定端口 16379） | Maven 依赖锁定 `com.github.codemonstur:embedded-redis:1.4.3`（JDK 17 兼容；不要回退 it.ozimov）；固定端口 16379 + 密码 bootstrap123 + bind 127.0.0.1 + maxmemory 128M；主启动类 `main()` 第一行调 `EmbeddedRedisConfig.ensureRunningForDev()`（**必须在 `SpringApplication.run()` 之前**）；profile 白名单 dev/local/test；跳过开关 `-Dembedded.redis.skip=true`；详细规约见 [references/embedded-redis-guide.md](references/embedded-redis-guide.md) | `@Bean` 端口随机；`@PostConstruct` 启动；`@Import` 注册；prod profile 启用；引入 it.ozimov:embedded-redis（不兼容 JDK 17） |
```

- [ ] **Step 3：校验替换**

Run: `grep -n "embedded-redis 内存版" skills/khala-spec-bootstrap-app/SKILL.md`
Expected: 命中 1 行，且包含 "fixed port 16379 / bootstrap123" 等新描述

- [ ] **Step 4：commit**

```bash
git add skills/khala-spec-bootstrap-app/SKILL.md
git commit -m "feat(bootstrap-app): §Scaffold Conventions Redis 列重写

- 端口由'随机'改为'固定 16379'
- 依赖锁定 codemonstur:1.4.3（注明禁回退 it.ozimov）
- 明确 main() 调用时序约束
- 链接至 references/embedded-redis-guide.md"
```

---

## Task 3: 修改 `SKILL.md` §Scaffold Conventions AI Rules 注入片段（`scaffold.redis`）

**Files:**
- Modify: `skills/khala-spec-bootstrap-app/SKILL.md:320-323`（AI Rules 注入片段 `scaffold.redis`）

- [ ] **Step 1：定位原片段**

Run: `grep -n "id: scaffold.redis" skills/khala-spec-bootstrap-app/SKILL.md`
Expected: 命中 1 行（约 line 319-323）

- [ ] **Step 2：替换 AI Rules 片段**

定位原内容（精确匹配）：
```
  - id: scaffold.redis
    type: must
    text: "Redis 使用内存版（embedded-redis 依赖）。
           不依赖任何外部 Redis 实例。
           不写入 redis.clients:jedis/lettuce 的真实连接配置。
           通过 @Bean 注册一个嵌入式 redis-server，端口随机，应用启动即生效。"
```

替换为：
```
  - id: scaffold.redis
    type: must
    text: "Redis 使用内存版 embedded-redis（依赖锁定 com.github.codemonstur:embedded-redis:1.4.3；不要回退 it.ozimov:embedded-redis，因不兼容 JDK 17）。
           不依赖任何外部 Redis 实例。
           不写入 redis.clients:jedis/lettuce 的真实连接配置。
           通过主启动类 main() 第一行调用 EmbeddedRedisConfig.ensureRunningForDev() 启动嵌入式 redis-server 子进程
           （固定端口 16379 / 密码 bootstrap123 / bind 127.0.0.1 / maxmemory 128M，
            profile 白名单 dev/local/test，加 -Dembedded.redis.skip=true 跳过），
           **必须在 SpringApplication.run() 之前**调用（否则早期抢连 starter 会抛 BeanCreationException）。
           完整规约见 references/embedded-redis-guide.md。"
```

- [ ] **Step 3：校验**

Run: `grep -n "确保在 SpringApplication.run" skills/khala-spec-bootstrap-app/SKILL.md`
Expected: 命中 1 行（替换后的新描述）

- [ ] **Step 4：commit**

```bash
git add skills/khala-spec-bootstrap-app/SKILL.md
git commit -m "feat(bootstrap-app): AI Rules scaffold.redis 补全约束

- 锁定依赖版本（codemonstur:1.4.3）
- 强调 main() 调用时序（避免 starter 抢先连接）
- 标注 profile 白名单与跳过开关
- 指向 references/embedded-redis-guide.md"
```

---

## Task 4: 修改 `SKILL.md` §Common Mistakes 表格追加 Redis 排错行

**Files:**
- Modify: `skills/khala-spec-bootstrap-app/SKILL.md:619-620`（在 Common Mistakes 表格末尾追加 1 行）

- [ ] **Step 1：定位表格末尾行**

Run: `grep -n "auto 模式下 AI Agent 主动停止" skills/khala-spec-bootstrap-app/SKILL.md`
Expected: 命中 1 行（Common Mistakes 表格最后一行）

- [ ] **Step 2：在表格末尾追加 1 行**

定位原表格最后 1 行（精确匹配）：
```
| **auto 模式下 AI Agent 主动停止并输出"恢复命令 `/yx:bootstrap-app ... --from N`"要求切换会话** | AI Agent 基于主观判断（"上下文快用完了"、"阶段耗时太长"、"防后续阶段决策偏移"）自作主张停下来；违反 §"Auto vs Semi-Auto → AI Agent 主动停止禁令" | ① SKILL 已加主动停止禁令；② 让 AI Agent 继续往下跑直到 §13 摘要机制真正派上用场，或平台层 LLM 触发真实压缩（这是不可预判的底层事件，无需 AI 主动检测）；③ 若 AI Agent 不听劝重复触发，把这条要求加入 prompt 顶部规则或联系维护者 |
```

在表格**末尾**（在该行 `|` 后换行）追加：
```
| 后端启动报 `Connection refused` / `BindException: Address already in use` / `ERR Client sent AUTH, but no password is set` / `InaccessibleObjectException` (JDK 17 模块限制) | 嵌入式 Redis 启动失败 / 被抢占 / 配置不一致 | `grep -E "\[bootstrap\]" /tmp/backend.log` 区分 4 类：[启动失败 / 已就绪 / 跳过 / 无日志]；详见 [references/embedded-redis-guide.md §7 故障排查清单](references/embedded-redis-guide.md#7-故障排查清单) |
```

- [ ] **Step 3：校验表格行数 +1**

Run:
```bash
old=$(git show HEAD:skills/khala-spec-bootstrap-app/SKILL.md | grep -c "^| " | head -1)
new=$(grep -c "^| " skills/khala-spec-bootstrap-app/SKILL.md | head -1)
echo "old=$old new=$new"
```
Expected: `new = old + 1`（表格多 1 行）

- [ ] **Step 4：commit**

```bash
git add skills/khala-spec-bootstrap-app/SKILL.md
git commit -m "feat(bootstrap-app): §Common Mistakes 补充 Redis 排错表

- 新增 1 行：连接被拒 / BindException / AUTH 错误 / JDK 17 模块限制 → 嵌入式 Redis 问题
- 排错入口：grep [bootstrap] 日志 + 指向 embedded-redis-guide.md §7"
```

---

## Task 5: 修改 `stage-checkpoints.md` §阶段 4 启动验证脚本（追加 [bootstrap] 日志断言）

**Files:**
- Modify: `skills/khala-spec-bootstrap-app/references/stage-checkpoints.md:392`（启动验证脚本末尾 `echo "[bootstrap] 阶段 4 端到端 smoke 全部通过"` 之前插入）

- [ ] **Step 1：定位插入位置**

Run: `grep -n "echo \"\[bootstrap\] 阶段 4 端到端 smoke 全部通过\"" skills/khala-spec-bootstrap-app/references/stage-checkpoints.md`
Expected: 命中 1 行（约 line 415）

- [ ] **Step 2：在该行之前插入 [bootstrap] 日志断言**

定位原行（精确匹配）：
```
echo "[bootstrap] 阶段 4 端到端 smoke 全部通过"
```

替换为：
```
echo "--- 嵌入式 Redis 启动断言（[bootstrap] 日志）---"
if grep -q "\[bootstrap\] 嵌入式 Redis 已就绪" /tmp/backend.log; then
    echo "[bootstrap] 嵌入式 Redis 启动 ✓"
elif grep -q "\[bootstrap\] 当前 profile 不在" /tmp/backend.log; then
    echo "[bootstrap] 嵌入式 Redis 已跳过（profile 不在白名单，符合预期）"
elif grep -q "\[bootstrap\] 检测到 -Dembedded.redis.skip=true" /tmp/backend.log; then
    echo "[bootstrap] 嵌入式 Redis 已跳过（-Dembedded.redis.skip=true 生效，符合预期）"
else
    echo "[bootstrap] ❌ 未检测到 [bootstrap] 日志，Redis 未启动也未跳过 —— 详见 references/embedded-redis-guide.md §7"
    grep -E "embedded|redis|Redis" /tmp/backend.log | head -20
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    exit 1
fi

echo "[bootstrap] 阶段 4 端到端 smoke 全部通过"
```

- [ ] **Step 3：校验插入位置与 4 类分支齐全**

Run:
```bash
grep -nE "嵌入式 Redis 已就绪|当前 profile 不在|检测到 -Dembedded.redis\.skip|未检测到 \[bootstrap\]" skills/khala-spec-bootstrap-app/references/stage-checkpoints.md
```
Expected: 4 行匹配（4 类分支全覆盖）

- [ ] **Step 4：commit**

```bash
git add skills/khala-spec-bootstrap-app/references/stage-checkpoints.md
git commit -m "feat(bootstrap-app): 阶段 4 启动验证增加 [bootstrap] 日志断言

- 4 类分支：已就绪 / profile 跳过 / 显式跳过 / 未检测（fail）
- 把'Redis 是否真的就绪'从日志诊断升级为强门禁
- 失败时指向 references/embedded-redis-guide.md §7"
```

---

## Task 6: 修改 `stage-checkpoints.md` §阶段 4 失败回退表格（"后端启动超时"行补充 reference）

**Files:**
- Modify: `skills/khala-spec-bootstrap-app/references/stage-checkpoints.md:412`（失败回退表格"后端启动超时"行）

- [ ] **Step 1：定位失败回退表格的"后端启动超时"行**

Run: `grep -n "后端启动超时" skills/khala-spec-bootstrap-app/references/stage-checkpoints.md`
Expected: 命中 1 行（约 line 412）

- [ ] **Step 2：补充 reference 链接**

定位原行（精确匹配）：
```
| 后端启动超时 | 看 `/tmp/backend.log` | 修 application.yml 端口冲突 / Redis 端口 / Bean 循环依赖 | 启动 + 健康端点 |
```

替换为：
```
| 后端启动超时 | 看 `/tmp/backend.log`；`grep -E "\[bootstrap\]"` 区分 Redis / 其他原因 | 修 application.yml 端口冲突 / Bean 循环依赖 / Redis 启动失败（详见 [references/embedded-redis-guide.md §7](references/embedded-redis-guide.md#7-故障排查清单)） | 启动 + 健康端点 + [bootstrap] 断言 |
```

- [ ] **Step 3：校验**

Run: `grep -n "embedded-redis-guide.md" skills/khala-spec-bootstrap-app/references/stage-checkpoints.md`
Expected: 命中 ≥2 行（Task 5 插入的脚本注释 + 本步的表格行）

- [ ] **Step 4：commit**

```bash
git add skills/khala-spec-bootstrap-app/references/stage-checkpoints.md
git commit -m "feat(bootstrap-app): 阶段 4 失败回退表补充 Redis 排错入口

- 后端启动超时行：grep [bootstrap] 区分 Redis / 其他
- re-verify 项加入 [bootstrap] 断言
- 指向 references/embedded-redis-guide.md §7"
```

---

## Task 7: 整体校验（确保 5 个修改点全部就位 + 链接互通 + 无残留）

**Files:**
- Read: `skills/khala-spec-bootstrap-app/SKILL.md`、`skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md`、`skills/khala-spec-bootstrap-app/references/stage-checkpoints.md`

- [ ] **Step 1：交叉链接校验**

Run:
```bash
echo "=== embedded-redis-guide.md 反向引用 ==="
grep -nE "embedded-redis-guide\.md|SKILL\.md" skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md || echo "PASS: reference 内无自引用"

echo "=== SKILL.md → reference 链接 ==="
grep -nE "embedded-redis-guide\.md" skills/khala-spec-bootstrap-app/SKILL.md

echo "=== stage-checkpoints.md → reference 链接 ==="
grep -nE "embedded-redis-guide\.md" skills/khala-spec-bootstrap-app/references/stage-checkpoints.md
```
Expected:
- reference 内 PASS（无自引用）
- SKILL.md 命中 ≥3 行（表格 + AI Rules + Common Mistakes）
- stage-checkpoints.md 命中 ≥2 行（脚本注释 + 失败回退表）

- [ ] **Step 2：业务特定痕迹全检**

Run:
```bash
echo "=== 业务特定名词残留扫描 ==="
grep -rnE "DemoApplication|captcha starter|khala\.redis" \
  skills/khala-spec-bootstrap-app/SKILL.md \
  skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md \
  skills/khala-spec-bootstrap-app/references/stage-checkpoints.md \
  || echo "PASS: 无业务特定痕迹残留"
```
Expected: `PASS`（grep 无匹配则 echo 触发）

- [ ] **Step 3：4 类 [bootstrap] 日志分支校验**

Run:
```bash
grep -cE "嵌入式 Redis 已就绪|当前 profile 不在|检测到 -Dembedded.redis\.skip|未检测到 \[bootstrap\]" \
  skills/khala-spec-bootstrap-app/references/stage-checkpoints.md
```
Expected: `4`（4 类分支全覆盖）

- [ ] **Step 4：commit 状态校验**

Run:
```bash
git log --oneline -7
```
Expected: 看到本计划 6 次新 commit（Task 1-6 各 1 次；含 feat: 新增 reference / §Scaffold Conventions 重写 / AI Rules 补全 / §Common Mistakes / 阶段 4 断言 / 失败回退表）

- [ ] **Step 5：产出总结**

输出最终报告：
- 新增文件：`skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md`（行数）
- 修改文件：`SKILL.md`（3 处编辑：表格 / AI Rules / Common Mistakes）；`stage-checkpoints.md`（2 处编辑：启动断言 / 失败回退表）
- 6 次 commit 列表
- 跳转链接互通校验结果
- 业务痕迹残留校验结果

不 commit（无文件变更）。如发现校验失败，按对应 Task 回退修复。

---

## Self-Review

**1. Spec coverage**（设计稿 4 个修改点 → 任务映射）：

| 设计稿修改点 | 任务 |
|---|---|
| §1 新增 references/embedded-redis-guide.md（10 节通用化） | T1 |
| §2 重写 SKILL.md §Scaffold Conventions（表格 + AI Rules） | T2 + T3 |
| §3 补充 SKILL.md §Common Mistakes | T4 |
| §4 增强 stage-checkpoints.md §阶段 4（断言 + 失败回退） | T5 + T6 |
| 整体校验 | T7 |

全部覆盖 ✅。

**2. Placeholder scan**：

- ✅ 无 TBD / TODO / "implement later"
- ✅ 无"appropriate error handling" / "fill in details"
- ✅ 每个 Step 含完整可执行内容（命令、代码、期望输出）
- ✅ 文件路径全部具体（`skills/khala-spec-bootstrap-app/references/embedded-redis-guide.md` 等）
- ✅ 通用化术语已明确（DemoApplication → `*Application`、captcha starter → "某些 starter"）

**3. Type consistency**：

- 文档中所有 `EmbeddedRedisConfig.ensureRunningForDev()` 调用一致
- 所有 `[bootstrap]` 日志关键词引用一致（与原配置源码匹配）
- 端口 `16379` / 密码 `bootstrap123` 在所有文档中一致
- reference 文件中的章节引用锚点（`embedded-redis-guide.md#7-故障排查清单`）与 GitHub 风格锚点生成规则一致（中文转拼音不可用，但 Markdown 渲染器一般会处理）

无一致性问题 ✅。

---

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-08-25-embedded-redis-guide-integration.md`. Two execution options:

1. **Subagent-Driven (recommended)** - I dispatch a fresh subagent per task, review between tasks, fast iteration
2. **Inline Execution** - Execute tasks in this session using executing-plans, batch execution with checkpoints

**Which approach?**