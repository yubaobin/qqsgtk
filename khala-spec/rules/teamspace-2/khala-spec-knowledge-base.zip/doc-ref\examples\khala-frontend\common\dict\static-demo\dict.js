import { enumApprovalType } from './enum.js'
// 审批类型字典
export const approvalTypeOptions = [
    { label: '人工审批', value: enumApprovalType.MANUAL },
    { label: '自动通过', value: enumApprovalType.AUTO_PASS },
    { label: '自动拒绝', value: enumApprovalType.AUTO_REJECT }
]