## Watermark
在页面上添加文本或图片等水印信息。
- [组件api](component-api/watermark.md)
- [组件样式](component-class/watermark.css)
- [组件示例](component-example/watermark.md)
- [组件类型定义源码](component-type/watermark.d.ts)
## Upload
通过点击或者拖拽上传文件。
- [组件api](component-api/upload.md)
- [组件样式](component-class/upload.css)
- [组件示例](component-example/upload.md)
- [组件类型定义源码](component-type/upload.d.ts)
## Tree
用清晰的层级结构展示信息，可展开或折叠。
- [组件api](component-api/tree.md)
- [组件样式](component-class/tree.css)
- [组件示例](component-example/tree.md)
- [组件类型定义源码](component-type/tree.d.ts)
## TreeV2
可加载数据量大的数据。
- [组件api](component-api/tree-v2.md)
- [组件样式](component-class/tree-v2.css)
- [组件示例](component-example/tree-v2.md)
- [组件类型定义源码](component-type/tree-v2.d.ts)
## TreeSelect
含有下拉菜单的树形选择器，结合了 ux-tree 和 ux-select 两个组件的功能。
- [组件api](component-api/tree-select.md)
- [组件样式](component-class/tree-select.css)
- [组件示例](component-example/tree-select.md)
- [组件类型定义源码](component-type/tree-select.d.ts)
## Transfer
双栏穿梭选择框。
- [组件api](component-api/transfer.md)
- [组件样式](component-class/transfer.css)
- [组件示例](component-example/transfer.md)
- [组件类型定义源码](component-type/transfer.d.ts)
## Tour
用于分步引导用户了解产品功能的气泡组件。 用来引导用户并介绍产品。
- [组件api](component-api/tour.md)
- [组件样式](component-class/tour.css)
- [组件示例](component-example/tour.md)
- [组件类型定义源码](component-type/tour.d.ts)
## Tooltip
常用于展示鼠标 hover 时的提示信息。
- [组件api](component-api/tooltip.md)
- [组件样式](component-class/tooltip.css)
- [组件示例](component-example/tooltip.md)
- [组件类型定义源码](component-type/tooltip.d.ts)
## TooltipV2
更精简的 tooltip。
- [组件api](component-api/tooltip-v2.md)
- [组件样式](component-class/tooltip-v2.css)
- [组件示例](component-example/tooltip-v2.md)
- [组件类型定义源码](component-type/tooltip-v2.d.ts)
## Timeline
可视化地呈现时间流信息。
- [组件api](component-api/timeline.md)
- [组件样式](component-class/timeline.css)
- [组件示例](component-example/timeline.md)
- [组件类型定义源码](component-type/timeline.d.ts)
## TimeSelect
用于选择或输入日期，可用时间范围是 00
- [组件api](component-api/time-select.md)
- [组件样式](component-class/time-select.css)
- [组件示例](component-example/time-select.md)
- [组件类型定义源码](component-type/time-select.d.ts)
## TimePicker
用于选择或输入日期。
- [组件api](component-api/time-picker.md)
- [组件样式](component-class/time-picker.css)
- [组件示例](component-example/time-picker.md)
- [组件类型定义源码](component-type/time-picker.d.ts)
## Text
文本的常见操作。
- [组件api](component-api/text.md)
- [组件样式](component-class/text.css)
- [组件示例](component-example/text.md)
- [组件类型定义源码](component-type/text.d.ts)
## Tag
用于标记和选择。
- [组件api](component-api/tag.md)
- [组件样式](component-class/tag.css)
- [组件示例](component-example/tag.md)
- [组件类型定义源码](component-type/tag.d.ts)
## Tabs
分隔内容上有关联但属于不同类别的数据集合。
- [组件api](component-api/tabs.md)
- [组件样式](component-class/tabs.css)
- [组件示例](component-example/tabs.md)
- [组件类型定义源码](component-type/tabs.d.ts)
## Table
用于展示多条结构类似的数据， 可对数据进行排序、筛选、对比或其他自定义操作。
- [组件api](component-api/table.md)
- [组件样式](component-class/table.css)
- [组件示例](component-example/table.md)
- [组件类型定义源码](component-type/table.d.ts)
## TableV2
可超过 1000 条数据记录的表格。
- [组件api](component-api/table-v2.md)
- [组件样式](component-class/table-v2.css)
- [组件示例](component-example/table-v2.md)
- [组件类型定义源码](component-type/table-v2.d.ts)
## Switch
表示两种相互对立的状态间的切换，多用于触发「开/关」。
- [组件api](component-api/switch.md)
- [组件样式](component-class/switch.css)
- [组件示例](component-example/switch.md)
- [组件类型定义源码](component-type/switch.d.ts)
## Steps
引导用户按照流程完成任务的分步导航条， 可根据实际应用场景设定步骤，步骤不得少于 2 步。
- [组件api](component-api/steps.md)
- [组件样式](component-class/steps.css)
- [组件示例](component-example/steps.md)
- [组件类型定义源码](component-type/steps.d.ts)
## Statistic
显示统计数据。
- [组件api](component-api/statistic.md)
- [组件样式](component-class/statistic.css)
- [组件示例](component-example/statistic.md)
- [组件类型定义源码](component-type/statistic.d.ts)
## Splitter
可将区域水平或垂直分隔，并可自由拖动以调整各个区域的大小。
- [组件api](component-api/splitter.md)
- [组件样式](component-class/splitter.css)
- [组件示例](component-example/splitter.md)
- [组件类型定义源码](component-type/splitter.d.ts)
## Space
间隔。
- [组件api](component-api/space.md)
- [组件样式](component-class/space.css)
- [组件示例](component-example/space.md)
- [组件类型定义源码](component-type/space.d.ts)
## Slider
通过拖动滑块在一个固定区间内进行选择。
- [组件api](component-api/slider.md)
- [组件样式](component-class/slider.css)
- [组件示例](component-example/slider.md)
- [组件类型定义源码](component-type/slider.d.ts)
## Skeleton
在需要等待加载内容的位置设置一个骨架屏，某些场景下比 Loading 的视觉效果更好。
- [组件api](component-api/skeleton.md)
- [组件样式](component-class/skeleton.css)
- [组件示例](component-example/skeleton.md)
- [组件类型定义源码](component-type/skeleton.d.ts)
## Select
当选项过多时，使用下拉菜单展示并选择内容。
- [组件api](component-api/select.md)
- [组件样式](component-class/select.css)
- [组件示例](component-example/select.md)
- [组件类型定义源码](component-type/select.d.ts)
## SelectV2
单个选择器可加载数万行数据。
- [组件api](component-api/select-v2.md)
- [组件样式](component-class/select-v2.css)
- [组件示例](component-example/select-v2.md)
- [组件类型定义源码](component-type/select-v2.d.ts)
## Segmented
用于展示多个选项并允许用户选择其中单个选项。
- [组件api](component-api/segmented.md)
- [组件样式](component-class/segmented.css)
- [组件示例](component-example/segmented.md)
- [组件类型定义源码](component-type/segmented.d.ts)
## Scrollbar
用于替换浏览器原生滚动条。
- [组件api](component-api/scrollbar.md)
- [组件样式](component-class/scrollbar.css)
- [组件示例](component-example/scrollbar.md)
- [组件类型定义源码](component-type/scrollbar.d.ts)
## Result
用于对用户的操作结果或者异常状态做反馈。
- [组件api](component-api/result.md)
- [组件样式](component-class/result.css)
- [组件示例](component-example/result.md)
- [组件类型定义源码](component-type/result.d.ts)
## Rate
用于评分。
- [组件api](component-api/rate.md)
- [组件样式](component-class/rate.css)
- [组件示例](component-example/rate.md)
- [组件类型定义源码](component-type/rate.d.ts)
## Radio
在一组备选项中进行单选。
- [组件api](component-api/radio.md)
- [组件样式](component-class/radio.css)
- [组件示例](component-example/radio.md)
- [组件类型定义源码](component-type/radio.d.ts)
## Progress
用于展示操作进度，告知用户当前状态和预期。
- [组件api](component-api/progress.md)
- [组件样式](component-class/progress.css)
- [组件示例](component-example/progress.md)
- [组件类型定义源码](component-type/progress.d.ts)
## Popover
悬浮出现在页面角落，显示全局的通知提醒消息。
- [组件api](component-api/popover.md)
- [组件样式](component-class/popover.css)
- [组件示例](component-example/popover.md)
- [组件类型定义源码](component-type/popover.d.ts)
## Popconfirm
点击元素，弹出气泡确认框。
- [组件api](component-api/popconfirm.md)
- [组件样式](component-class/popconfirm.css)
- [组件示例](component-example/popconfirm.md)
- [组件类型定义源码](component-type/popconfirm.d.ts)
## Pagination
当数据量过多时，使用分页分解数据。
- [组件api](component-api/pagination.md)
- [组件样式](component-class/pagination.css)
- [组件示例](component-example/pagination.md)
- [组件类型定义源码](component-type/pagination.d.ts)
## PageHeader
如果页面的路径比较简单，推荐使用页头组件而非面包屑组件。
- [组件api](component-api/page-header.md)
- [组件样式](component-class/page-header.css)
- [组件示例](component-example/page-header.md)
- [组件类型定义源码](component-type/page-header.d.ts)
## Notification
悬浮出现在页面角落，显示全局的通知提醒消息。
- [组件api](component-api/notification.md)
- [组件样式](component-class/notification.css)
- [组件示例](component-example/notification.md)
- [组件类型定义源码](component-type/notification.d.ts)
## Message
常用于主动操作后的反馈提示。 与 `ux-notification` 的区别是后者更多用于系统级通知的被动提醒。
- [组件api](component-api/message.md)
- [组件样式](component-class/message.css)
- [组件示例](component-example/message.md)
- [组件类型定义源码](component-type/message.d.ts)
## MessageBox
模拟系统的消息提示框而实现的一套模态对话框组件，用于消息提示、确认消息和提交内容。
- [组件api](component-api/message-box.md)
- [组件样式](component-class/message-box.css)
- [组件示例](component-example/message-box.md)
- [组件类型定义源码](component-type/message-box.d.ts)
## Menu
为网站提供导航功能的菜单。
- [组件api](component-api/menu.md)
- [组件样式](component-class/menu.css)
- [组件示例](component-example/menu.md)
- [组件类型定义源码](component-type/menu.d.ts)
## Mention
用于在输入中提及某人或某事。
- [组件api](component-api/mention.md)
- [组件样式](component-class/mention.css)
- [组件示例](component-example/mention.md)
- [组件类型定义源码](component-type/mention.d.ts)
## Loading
加载数据时显示动效。
- [组件api](component-api/loading.md)
- [组件样式](component-class/loading.css)
- [组件示例](component-example/loading.md)
- [组件类型定义源码](component-type/loading.d.ts)
## Link
文字超链接。
- [组件api](component-api/link.md)
- [组件样式](component-class/link.css)
- [组件示例](component-example/link.md)
- [组件类型定义源码](component-type/link.d.ts)
## Layout
通过基础的 24 分栏，迅速简便地创建布局。
- [组件api](component-api/layout.md)
- [组件样式](component-class/layout.css)
- [组件示例](component-example/layout.md)
- [组件类型定义源码](component-type/layout.d.ts)
## Input
通过鼠标或键盘输入字符。
- [组件api](component-api/input.md)
- [组件样式](component-class/input.css)
- [组件示例](component-example/input.md)
- [组件类型定义源码](component-type/input.d.ts)
## InputTag
允许用户添加内容作为标签。
- [组件api](component-api/input-tag.md)
- [组件样式](component-class/input-tag.css)
- [组件示例](component-example/input-tag.md)
- [组件类型定义源码](component-type/input-tag.d.ts)
## InputNumber
仅允许输入标准的数字值，可定义范围。
- [组件api](component-api/input-number.md)
- [组件样式](component-class/input-number.css)
- [组件示例](component-example/input-number.md)
- [组件类型定义源码](component-type/input-number.d.ts)
## InfiniteScroll
滚动至底部时，加载更多数据。
- [组件api](component-api/infinite-scroll.md)
- [组件样式](component-class/infinite-scroll.css)
- [组件示例](component-example/infinite-scroll.md)
- [组件类型定义源码](component-type/infinite-scroll.d.ts)
## Image
图片容器，在保留所有原生 img 的特性下，支持懒加载，自定义占位、加载失败等。
- [组件api](component-api/image.md)
- [组件样式](component-class/image.css)
- [组件示例](component-example/image.md)
- [组件类型定义源码](component-type/image.d.ts)
## Icon
提供了一套常用的图标集合。
- [组件api](component-api/icon.md)
- [组件样式](component-class/icon.css)
- [组件示例](component-example/icon.md)
- [组件类型定义源码](component-type/icon.d.ts)
## Form
表单包含 输入框, 单选框, 下拉选择, 多选框 等用户输入的组件。 使用表单，您可以收集、验证和提交数据。
- [组件api](component-api/form.md)
- [组件样式](component-class/form.css)
- [组件示例](component-example/form.md)
- [组件类型定义源码](component-type/form.d.ts)
## Font
字体是构建界面设计的最基本构成元素之一，合理的字体应用可以提升用户的阅读体验及效率。
- [组件api](component-api/font.md)
- [组件样式](component-class/font.css)
- [组件示例](component-example/font.md)
- [组件类型定义源码](component-type/font.d.ts)
## Empty
空状态时的占位提示。
- [组件api](component-api/empty.md)
- [组件样式](component-class/empty.css)
- [组件示例](component-example/empty.md)
- [组件类型定义源码](component-type/empty.d.ts)
## Dropdown
将动作或菜单折叠到下拉菜单中。
- [组件api](component-api/dropdown.md)
- [组件样式](component-class/dropdown.css)
- [组件示例](component-example/dropdown.md)
- [组件类型定义源码](component-type/dropdown.d.ts)
## Drawer
有些时候, ux-dialog 组件并不满足我们的需求, 比如你的表单很长, 亦或是你需要临时展示一些文档, ux-drawer 拥有和 ux-dialog 几乎相同的 API, 在 UI 上带来不一样的体验.
- [组件api](component-api/drawer.md)
- [组件样式](component-class/drawer.css)
- [组件示例](component-example/drawer.md)
- [组件类型定义源码](component-type/drawer.d.ts)
## Divider
区隔内容的分割线。
- [组件api](component-api/divider.md)
- [组件样式](component-class/divider.css)
- [组件示例](component-example/divider.md)
- [组件类型定义源码](component-type/divider.d.ts)
## Dialog
在保留当前页面状态的情况下，告知用户并承载相关操作。
- [组件api](component-api/dialog.md)
- [组件样式](component-class/dialog.css)
- [组件示例](component-example/dialog.md)
- [组件类型定义源码](component-type/dialog.d.ts)
## Descriptions
列表形式展示多个字段。
- [组件api](component-api/descriptions.md)
- [组件样式](component-class/descriptions.css)
- [组件示例](component-example/descriptions.md)
- [组件类型定义源码](component-type/descriptions.d.ts)
## DateTimePicker
在同一个选择器里选择日期和时间。
- [组件api](component-api/datetime-picker.md)
- [组件样式](component-class/datetime-picker.css)
- [组件示例](component-example/datetime-picker.md)
- [组件类型定义源码](component-type/datetime-picker.d.ts)
## DatePicker
用于选择或输入日期。
- [组件api](component-api/date-picker.md)
- [组件样式](component-class/date-picker.css)
- [组件示例](component-example/date-picker.md)
- [组件类型定义源码](component-type/date-picker.d.ts)
## DatePickerPanel
DatePickerPanel是DatePicker的核心组件
- [组件api](component-api/date-picker-panel.md)
- [组件样式](component-class/date-picker-panel.css)
- [组件示例](component-example/date-picker-panel.md)
- [组件类型定义源码](component-type/date-picker-panel.d.ts)
## Container
用于布局的容器组件，方便快速搭建页面的基本结构。
- [组件api](component-api/container.md)
- [组件样式](component-class/container.css)
- [组件示例](component-example/container.md)
- [组件类型定义源码](component-type/container.d.ts)
## Color
全局样式。颜色是构建界面的视觉元素之一，合理和谐的颜色搭配能提高界面的可用性，提升用户体验和感知。
- [组件api](component-api/color.md)
- [组件样式](component-class/color.css)
- [组件示例](component-example/color.md)
- [组件类型定义源码](component-type/color.d.ts)
## ColorPicker
用于颜色选择，支持多种格式。
- [组件api](component-api/color-picker.md)
- [组件样式](component-class/color-picker.css)
- [组件示例](component-example/color-picker.md)
- [组件类型定义源码](component-type/color-picker.d.ts)
## ColorPickerPanel
ColorPickerPanel是ColorPicker的核心组件
- [组件api](component-api/color-picker-panel.md)
- [组件样式](component-class/color-picker-panel.css)
- [组件示例](component-example/color-picker-panel.md)
- [组件类型定义源码](component-type/color-picker-panel.d.ts)
## Collapse
通过折叠面板收纳内容区域
- [组件api](component-api/collapse.md)
- [组件样式](component-class/collapse.css)
- [组件示例](component-example/collapse.md)
- [组件类型定义源码](component-type/collapse.d.ts)
## Checkbox
在一组备选项中进行多选。
- [组件api](component-api/checkbox.md)
- [组件样式](component-class/checkbox.css)
- [组件示例](component-example/checkbox.md)
- [组件类型定义源码](component-type/checkbox.d.ts)
## Cascader
当一个数据集合有清晰的层级结构时，可通过级联选择器逐级查看并选择。
- [组件api](component-api/cascader.md)
- [组件样式](component-class/cascader.css)
- [组件示例](component-example/cascader.md)
- [组件类型定义源码](component-type/cascader.d.ts)
## Carousel
在有限空间内，循环播放同一类型的图片、文字等内容。
- [组件api](component-api/carousel.md)
- [组件样式](component-class/carousel.css)
- [组件示例](component-example/carousel.md)
- [组件类型定义源码](component-type/carousel.d.ts)
## Card
将信息聚合在卡片容器中展示。
- [组件api](component-api/card.md)
- [组件样式](component-class/card.css)
- [组件示例](component-example/card.md)
- [组件类型定义源码](component-type/card.d.ts)
## Calendar
显示日期。
- [组件api](component-api/calendar.md)
- [组件样式](component-class/calendar.css)
- [组件示例](component-example/calendar.md)
- [组件类型定义源码](component-type/calendar.d.ts)
## Button
常用的操作按钮。
- [组件api](component-api/button.md)
- [组件样式](component-class/button.css)
- [组件示例](component-example/button.md)
- [组件类型定义源码](component-type/button.d.ts)
## Breadcrumb
显示当前页面的路径，快速返回之前的任意页面。
- [组件api](component-api/breadcrumb.md)
- [组件样式](component-class/breadcrumb.css)
- [组件示例](component-example/breadcrumb.md)
- [组件类型定义源码](component-type/breadcrumb.d.ts)
## Border
我们对边框进行统一规范，可用于按钮、卡片、弹窗等组件里。
- [组件api](component-api/border.md)
- [组件样式](component-class/border.css)
- [组件示例](component-example/border.md)
- [组件类型定义源码](component-type/border.d.ts)
## Badge
按钮和图标上的数字或状态标记。
- [组件api](component-api/badge.md)
- [组件样式](component-class/badge.css)
- [组件示例](component-example/badge.md)
- [组件类型定义源码](component-type/badge.d.ts)
## Backtop
返回页面顶部的操作按钮。
- [组件api](component-api/backtop.md)
- [组件样式](component-class/backtop.css)
- [组件示例](component-example/backtop.md)
- [组件类型定义源码](component-type/backtop.d.ts)
## Avatar
用来代表人物或对象，支持使用图片、图标或者文字作为头像。
- [组件api](component-api/avatar.md)
- [组件样式](component-class/avatar.css)
- [组件示例](component-example/avatar.md)
- [组件类型定义源码](component-type/avatar.d.ts)
## Anchor
通过锚点，可以很快找到当前页面上信息内容的位置。
- [组件api](component-api/anchor.md)
- [组件样式](component-class/anchor.css)
- [组件示例](component-example/anchor.md)
- [组件类型定义源码](component-type/anchor.d.ts)
## Alert
用于页面中展示重要的提示信息。
- [组件api](component-api/alert.md)
- [组件样式](component-class/alert.css)
- [组件示例](component-example/alert.md)
- [组件类型定义源码](component-type/alert.d.ts)
## Affix
将页面元素固定在特定可视区域。
- [组件api](component-api/affix.md)
- [组件样式](component-class/affix.css)
- [组件示例](component-example/affix.md)
- [组件类型定义源码](component-type/affix.d.ts)
