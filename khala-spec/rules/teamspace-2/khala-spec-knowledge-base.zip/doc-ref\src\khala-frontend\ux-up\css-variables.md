# CSS Variables Reference

**Total Variables**: 123

---

## Variables List

### Bg

| Variable | Application |
|----------|-------------|
| `--ux-bg-color` | `getCssVar('bg', 'color')` |
| `--ux-bg-color-overlay` | `getCssVar('bg', 'color-overlay')` |
| `--ux-bg-color-page` | `getCssVar('bg', 'color-page')` |

### Border

| Variable | Application |
|----------|-------------|
| `--ux-border` | `getCssVar('border', '')` |
| `--ux-border-color` | `getCssVar('border', 'color')` |
| `--ux-border-color-dark` | `getCssVar('border', 'color-dark')` |
| `--ux-border-color-darker` | `getCssVar('border', 'color-darker')` |
| `--ux-border-color-extra-light` | `getCssVar('border', 'color-extra-light')` |
| `--ux-border-color-hover` | `getCssVar('border', 'color-hover')` |
| `--ux-border-color-light` | `getCssVar('border', 'color-light')` |
| `--ux-border-color-lighter` | `getCssVar('border', 'color-lighter')` |
| `--ux-border-radius-base` | `getCssVar('border', 'radius-base')` |
| `--ux-border-radius-circle` | `getCssVar('border', 'radius-circle')` |
| `--ux-border-radius-round` | `getCssVar('border', 'radius-round')` |
| `--ux-border-radius-small` | `getCssVar('border', 'radius-small')` |
| `--ux-border-style` | `getCssVar('border', 'style')` |
| `--ux-border-width` | `getCssVar('border', 'width')` |

### Box

| Variable | Application |
|----------|-------------|
| `--ux-box-shadow` | `getCssVar('box', 'shadow')` |
| `--ux-box-shadow-dark` | `getCssVar('box', 'shadow-dark')` |
| `--ux-box-shadow-light` | `getCssVar('box', 'shadow-light')` |
| `--ux-box-shadow-lighter` | `getCssVar('box', 'shadow-lighter')` |

### Color

| Variable | Application |
|----------|-------------|
| `--ux-color-black` | `getCssVar('color', 'black')` |
| `--ux-color-danger` | `getCssVar('color', 'danger')` |
| `--ux-color-danger-dark-2` | `getCssVar('color', 'danger-dark-2')` |
| `--ux-color-danger-light-3` | `getCssVar('color', 'danger-light-3')` |
| `--ux-color-danger-light-5` | `getCssVar('color', 'danger-light-5')` |
| `--ux-color-danger-light-7` | `getCssVar('color', 'danger-light-7')` |
| `--ux-color-danger-light-8` | `getCssVar('color', 'danger-light-8')` |
| `--ux-color-danger-light-9` | `getCssVar('color', 'danger-light-9')` |
| `--ux-color-danger-rgb` | `getCssVar('color', 'danger-rgb')` |
| `--ux-color-error` | `getCssVar('color', 'error')` |
| `--ux-color-error-dark-2` | `getCssVar('color', 'error-dark-2')` |
| `--ux-color-error-light-3` | `getCssVar('color', 'error-light-3')` |
| `--ux-color-error-light-5` | `getCssVar('color', 'error-light-5')` |
| `--ux-color-error-light-7` | `getCssVar('color', 'error-light-7')` |
| `--ux-color-error-light-8` | `getCssVar('color', 'error-light-8')` |
| `--ux-color-error-light-9` | `getCssVar('color', 'error-light-9')` |
| `--ux-color-error-rgb` | `getCssVar('color', 'error-rgb')` |
| `--ux-color-info` | `getCssVar('color', 'info')` |
| `--ux-color-info-dark-2` | `getCssVar('color', 'info-dark-2')` |
| `--ux-color-info-light-3` | `getCssVar('color', 'info-light-3')` |
| `--ux-color-info-light-5` | `getCssVar('color', 'info-light-5')` |
| `--ux-color-info-light-7` | `getCssVar('color', 'info-light-7')` |
| `--ux-color-info-light-8` | `getCssVar('color', 'info-light-8')` |
| `--ux-color-info-light-9` | `getCssVar('color', 'info-light-9')` |
| `--ux-color-info-rgb` | `getCssVar('color', 'info-rgb')` |
| `--ux-color-primary` | `getCssVar('color', 'primary')` |
| `--ux-color-primary-dark-2` | `getCssVar('color', 'primary-dark-2')` |
| `--ux-color-primary-light-3` | `getCssVar('color', 'primary-light-3')` |
| `--ux-color-primary-light-5` | `getCssVar('color', 'primary-light-5')` |
| `--ux-color-primary-light-7` | `getCssVar('color', 'primary-light-7')` |
| `--ux-color-primary-light-8` | `getCssVar('color', 'primary-light-8')` |
| `--ux-color-primary-light-9` | `getCssVar('color', 'primary-light-9')` |
| `--ux-color-primary-rgb` | `getCssVar('color', 'primary-rgb')` |
| `--ux-color-success` | `getCssVar('color', 'success')` |
| `--ux-color-success-dark-2` | `getCssVar('color', 'success-dark-2')` |
| `--ux-color-success-light-3` | `getCssVar('color', 'success-light-3')` |
| `--ux-color-success-light-5` | `getCssVar('color', 'success-light-5')` |
| `--ux-color-success-light-7` | `getCssVar('color', 'success-light-7')` |
| `--ux-color-success-light-8` | `getCssVar('color', 'success-light-8')` |
| `--ux-color-success-light-9` | `getCssVar('color', 'success-light-9')` |
| `--ux-color-success-rgb` | `getCssVar('color', 'success-rgb')` |
| `--ux-color-warning` | `getCssVar('color', 'warning')` |
| `--ux-color-warning-dark-2` | `getCssVar('color', 'warning-dark-2')` |
| `--ux-color-warning-light-3` | `getCssVar('color', 'warning-light-3')` |
| `--ux-color-warning-light-5` | `getCssVar('color', 'warning-light-5')` |
| `--ux-color-warning-light-7` | `getCssVar('color', 'warning-light-7')` |
| `--ux-color-warning-light-8` | `getCssVar('color', 'warning-light-8')` |
| `--ux-color-warning-light-9` | `getCssVar('color', 'warning-light-9')` |
| `--ux-color-warning-rgb` | `getCssVar('color', 'warning-rgb')` |
| `--ux-color-white` | `getCssVar('color', 'white')` |

### Component

| Variable | Application |
|----------|-------------|
| `--ux-component-size` | `getCssVar('component', 'size')` |
| `--ux-component-size-large` | `getCssVar('component', 'size-large')` |
| `--ux-component-size-mini` | `getCssVar('component', 'size-mini')` |
| `--ux-component-size-small` | `getCssVar('component', 'size-small')` |

### Disabled

| Variable | Application |
|----------|-------------|
| `--ux-disabled-bg-color` | `getCssVar('disabled', 'bg-color')` |
| `--ux-disabled-border-color` | `getCssVar('disabled', 'border-color')` |
| `--ux-disabled-text-color` | `getCssVar('disabled', 'text-color')` |

### Fill

| Variable | Application |
|----------|-------------|
| `--ux-fill-color` | `getCssVar('fill', 'color')` |
| `--ux-fill-color-blank` | `getCssVar('fill', 'color-blank')` |
| `--ux-fill-color-dark` | `getCssVar('fill', 'color-dark')` |
| `--ux-fill-color-darker` | `getCssVar('fill', 'color-darker')` |
| `--ux-fill-color-extra-light` | `getCssVar('fill', 'color-extra-light')` |
| `--ux-fill-color-light` | `getCssVar('fill', 'color-light')` |
| `--ux-fill-color-lighter` | `getCssVar('fill', 'color-lighter')` |

### Font

| Variable | Application |
|----------|-------------|
| `--ux-font-family` | `getCssVar('font', 'family')` |
| `--ux-font-line-height-primary` | `getCssVar('font', 'line-height-primary')` |
| `--ux-font-size-base` | `getCssVar('font', 'size-base')` |
| `--ux-font-size-extra-large` | `getCssVar('font', 'size-extra-large')` |
| `--ux-font-size-extra-small` | `getCssVar('font', 'size-extra-small')` |
| `--ux-font-size-large` | `getCssVar('font', 'size-large')` |
| `--ux-font-size-medium` | `getCssVar('font', 'size-medium')` |
| `--ux-font-size-small` | `getCssVar('font', 'size-small')` |
| `--ux-font-weight-primary` | `getCssVar('font', 'weight-primary')` |

### Index

| Variable | Application |
|----------|-------------|
| `--ux-index-normal` | `getCssVar('index', 'normal')` |
| `--ux-index-popper` | `getCssVar('index', 'popper')` |
| `--ux-index-top` | `getCssVar('index', 'top')` |

### Mask

| Variable | Application |
|----------|-------------|
| `--ux-mask-color` | `getCssVar('mask', 'color')` |
| `--ux-mask-color-extra-light` | `getCssVar('mask', 'color-extra-light')` |

### Overlay

| Variable | Application |
|----------|-------------|
| `--ux-overlay-color` | `getCssVar('overlay', 'color')` |
| `--ux-overlay-color-light` | `getCssVar('overlay', 'color-light')` |
| `--ux-overlay-color-lighter` | `getCssVar('overlay', 'color-lighter')` |

### Sys

| Variable | Application |
|----------|-------------|
| `--ux-sys-space-base` | `getCssVar('sys', 'space-base')` |
| `--ux-sys-space-extra-large` | `getCssVar('sys', 'space-extra-large')` |
| `--ux-sys-space-large` | `getCssVar('sys', 'space-large')` |
| `--ux-sys-space-medium` | `getCssVar('sys', 'space-medium')` |
| `--ux-sys-space-small` | `getCssVar('sys', 'space-small')` |

### Text

| Variable | Application |
|----------|-------------|
| `--ux-text-color-disabled` | `getCssVar('text', 'color-disabled')` |
| `--ux-text-color-placeholder` | `getCssVar('text', 'color-placeholder')` |
| `--ux-text-color-primary` | `getCssVar('text', 'color-primary')` |
| `--ux-text-color-regular` | `getCssVar('text', 'color-regular')` |
| `--ux-text-color-secondary` | `getCssVar('text', 'color-secondary')` |

### Transition

| Variable | Application |
|----------|-------------|
| `--ux-transition-all` | `getCssVar('transition', 'all')` |
| `--ux-transition-border` | `getCssVar('transition', 'border')` |
| `--ux-transition-box-shadow` | `getCssVar('transition', 'box-shadow')` |
| `--ux-transition-color` | `getCssVar('transition', 'color')` |
| `--ux-transition-duration` | `getCssVar('transition', 'duration')` |
| `--ux-transition-duration-fast` | `getCssVar('transition', 'duration-fast')` |
| `--ux-transition-fade` | `getCssVar('transition', 'fade')` |
| `--ux-transition-fade-linear` | `getCssVar('transition', 'fade-linear')` |
| `--ux-transition-function-ease-in-out-bezier` | `getCssVar('transition', 'function-ease-in-out-bezier')` |
| `--ux-transition-function-fast-bezier` | `getCssVar('transition', 'function-fast-bezier')` |
| `--ux-transition-md-fade` | `getCssVar('transition', 'md-fade')` |

