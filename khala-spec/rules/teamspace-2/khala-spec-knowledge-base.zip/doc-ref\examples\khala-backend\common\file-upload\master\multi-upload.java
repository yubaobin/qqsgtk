package com.example.fileupload;

import com.eshore.khala.common.core.result.CommonResult;
import com.eshore.khala.starter.file.core.service.FileService;
import com.eshore.khala.starter.file.core.vo.FileInfoVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 多文件上传示例
 */
@Tag(name = "文件上传管理")
@RestController
@RequestMapping("/api/upload")
public class MultiUploadController {

    @Autowired
    private FileService fileService;

    @Operation(summary = "多文件上传", description = "批量上传多个文件")
    @PostMapping("/multi")
    public CommonResult<List<FileInfoVO>> uploadMulti(@RequestParam("files") List<MultipartFile> files) {
        List<FileInfoVO> fileInfos = fileService.uploadBatch(files);
        return CommonResult.success(fileInfos);
    }
}
