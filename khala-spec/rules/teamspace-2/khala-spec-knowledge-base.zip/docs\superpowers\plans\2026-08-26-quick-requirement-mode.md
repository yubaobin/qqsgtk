# quick-requirement 执行模式拆分 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把 `quick-requirement` 当前 5 步流程定义为 `normal` 模式，新增 `quick` 模式作为默认；quick 模式跳过需求规格生成（T3）与用户审批（T4），直接生成高保真原型；todo 与 output 极致精简。

**Architecture:** 在 `commands/quick-requirement.md` 与 `skills/quick-requirement/SKILL.md` 双侧同步改造；新增「步骤 0A 执行模式识别」段（仿 `khala-spec-require` 步骤 0A）；Todo 表与 Output 示例拆成 Normal/Quick 两套；`download-refs.sh` 不动；新增模式识别提示与边界处理。

**Tech Stack:** Markdown / YAML 知识库资产（无编译/测试步骤）。

**Spec:** `docs/superpowers/specs/2026-08-26-quick-requirement-mode-design.md`

---

## File Structure

| 文件 | 操作 | 责任 |
|------|------|------|
| `commands/quick-requirement.md` | 修改 | 命令包装：模式说明、待办概览拆分 |
| `skills/quick-requirement/SKILL.md` | 修改 | Skill 实现：frontmatter + 步骤 0A + Parameters + 双 Todo 表 + 双 Output + Common Mistakes |
| `skills/quick-requirement/scripts/references.example.yaml` | 修改 | 顶部注释追加模式说明 |
| `skills/quick-requirement/scripts/download-refs.sh` | **不动** | 两种模式都跑它 |

---

## Task 1：更新 `commands/quick-requirement.md`

**Files:**
- Modify: `commands/quick-requirement.md`

**前置知识：**
- 该文件原结构：frontmatter → `<!-- managed-by: khala-spec -->` → 「执行角色」→ 「执行粒度」→ 「前置条件」→ 「核心目标」→ 「执行待办概览」
- frontmatter 第 4 行 `description:` 是 Claude Code 列表里展示的描述

- [ ] **Step 1：更新 frontmatter `description`**

把第 3-4 行：

```yaml
description: 快速打单工作流 — 产品/需求人员触发。AI Agent 解析关键词与编号化参考素材，调用 download-refs.sh 下载到 references/，再依次执行 /yx:require 与 /yx:prototype 一键产出需求规格 + 高保真原型。
```

替换为：

```yaml
description: 快速打单工作流 — 产品/需求人员触发。AI Agent 解析关键词与编号化参考素材，调用 download-refs.sh 下载到 references/。**默认 quick 模式**：跳过需求规格与审批，直接生成高保真原型；**`--normal` 模式**：依次执行 /yx:require 与 /yx:prototype 一键产出需求规格 + 高保真原型。
```

- [ ] **Step 2：在「核心目标」之后插入「执行模式」段落**

在 `## 执行待办概览` 之前插入以下内容（保留两个原段落不动）：

````markdown
## 执行模式

`/quick-requirement` 支持两种执行模式，flag 必须在关键词之前：

| 模式 | 触发方式 | 行为 |
|------|---------|------|
| `quick`（默认） | `/yx:quick-requirement关键词 [#id]...` 或 `--quick 关键词` | 跳过需求规格生成（T3）与用户审批（T4），直接生成高保真原型 |
| `normal` | `--normal 关键词` | 完整跑 5 步：拉素材 → 需求规格 → 用户审批 → 高保真原型 |

边界处理：flag 写在关键词之后视为位置错误，提示并忽略；`--quick` 与 `--normal` 同时出现按 normal 处理。

> 详细规约（模式锁定逻辑、披露规约、双 Output 示例）见 `quick-requirement` skill 的「步骤 0A 执行模式识别」章节。
````

- [ ] **Step 3：拆分「执行待办概览」为 Normal / Quick 两张表**

把当前文件里：

````markdown
## 执行待办概览

本指令的执行被切分为 5 个待办项，AI Agent 在执行开始时会按此清单逐项披露状态：

| # | 待办名称 | 类型 | 关键产出 |
|---|---------|------|---------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | `keyword`、`ids[]` |
| T2 | 拉取并解压参考素材（如有 `#id`） | 自动 / 可能阻塞 | `khala-spec/rd/references/<关键词>/` |
| T3 | 调用 `/yx:require` 生成需求规格 | AI 子指令 | 需求规格 Markdown |
| T4 | 等用户在 `/yx:require` 步骤 8 审批通过 | 用户介入 | 审批结论：通过 |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | 高保真原型 `index.html` |

> 详细规约（状态机、AI 披露规约、失败回退）见 `quick-requirement` skill 的
> `Execution Todo` 与 `AI Agent 编排规约` 章节。
````

替换为：

````markdown
## 执行待办概览

### Normal 模式（5 项）

| # | 待办名称 | 类型 | 关键产出 |
|---|---------|------|---------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | `keyword`、`ids[]` |
| T2 | 拉取并解压参考素材（如有 `#id`） | 自动 / 可能阻塞 | `khala-spec/rd/references/<关键词>/` |
| T3 | 调用 `/yx:require` 生成需求规格 | AI 子指令 | 需求规格 Markdown |
| T4 | 等用户在 `/yx:require` 步骤 8 审批通过 | 用户介入 | 审批结论：通过 |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | 高保真原型 `index.html` |

### Quick 模式（3 项）

| # | 待办名称 | 类型 | 关键产出 |
|---|---------|------|---------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | `keyword`、`ids[]` |
| T2 | 拉取并解压参考素材（如有 `#id`） | 自动 / 可能阻塞 | `khala-spec/rd/references/<关键词>/` |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | 高保真原型 `index.html` |

> T3、T4 在 quick 模式下被刻意跳过。详细规约（状态机、AI 披露规约、失败回退）见 `quick-requirement` skill 的 `Execution Todo` 与 `AI Agent 编排规约` 章节。
````

- [ ] **Step 4：Read 全文核对**

读 `commands/quick-requirement.md` 全文，确认：
- frontmatter description 已更新
- 「执行模式」段落已插入
- 「执行待办概览」已拆成两张表
- 文末的 `Use Skill tool to invoke khala-spec-quick-requirement.` 仍在
- 无残留旧 5 项单表

- [ ] **Step 5：暂存（不 commit）**

```bash
git add commands/quick-requirement.md
```

> 代码/资产类文件按仓库 CLAUDE.md §「Git 操作约束」第 2 条：只 `add` 不 `commit`，由用户提交。

---

## Task 2：更新 `skills/quick-requirement/SKILL.md` — frontmatter + 步骤 0A + Parameters

**Files:**
- Modify: `skills/quick-requirement/SKILL.md`

- [ ] **Step 1：更新 frontmatter `description`**

把 SKILL.md 第 3-9 行（frontmatter `description` 段）：

```yaml
description: Use when triggering `/quick-requirement <关键词> [#id]...` to
  batch download reference materials from a configured HTTP service and
  coordinate with `/yx:require` (khala-spec-require) + `/yx:prototype`
  (khala-spec-prototype) to generate requirements specification and
  high-fidelity prototype in one shot. AI Agent orchestrates the flow;
  download-refs.sh handles the HTTP fetch; `/yx:*` commands are AI Agent
  slash commands (not shell binaries).
```

替换为：

```yaml
description: Use when triggering `/quick-requirement [--quick|--normal] <关键词> [#id]...`
  to batch download reference materials from a configured HTTP service and generate
  a high-fidelity prototype in one shot. Default `quick` mode skips requirement spec
  generation and user approval, going straight from references to prototype; `--normal`
  mode additionally coordinates with `/yx:require` (khala-spec-require) for full
  requirement specification before prototype. AI Agent orchestrates the flow;
  download-refs.sh handles the HTTP fetch; `/yx:*` commands are AI Agent slash commands
  (not shell binaries).
```

- [ ] **Step 2：在 `## When to Use` 之前插入「步骤 0A 执行模式识别」段**

在 `## When to Use` 上方插入（`## Overview` 段保持不动）：

````markdown
## 步骤 0A：执行模式识别

`mode` 取值：`quick`（默认） | `normal`。`mode` 在**本次执行的第一次输入**时按以下顺序判断并锁定，整个执行周期不再重判（即使后续用户继续输入追问/补充信息，也不重置 `mode`）。

判断顺序（命中即停止）：

1. 含 `--normal` → `mode = normal`
2. 含 `--quick` → `mode = quick`
3. 两者都不含 → `mode = quick`（默认）

锁定后向用户输出一行触发提示（**仅首次**）：

| mode | 触发提示 |
|------|---------|
| `quick` | `[quick-requirement] mode = quick — 跳过需求确认环节，直接生成高保真原型。` |
| `normal` | `[quick-requirement] mode = normal — 依次执行需求规格生成、用户审批、高保真原型。` |

边界处理：

- flag 出现在关键词之后 → 视为「位置错误」，提示用户把 flag 移到关键词前；如未修正则忽略该 flag，按剩余输入判定 mode
- 同时含 `--quick` 和 `--normal` → 以 `normal` 为准（更严格的流程优先），提示：`--quick` 与 `--normal` 同时出现，按 normal 处理。`

---

````

- [ ] **Step 3：更新 `## Parameters` 表**

把当前文件里：

````markdown
## Parameters

| 参数 | 必填 | 说明 |
|------|------|------|
| `<关键词>` | 是 | 中文；用作需求描述、references 目录名、prototype 系统名派生源 |
| `[#id]` | 否 | 用户调用时通过 `#N` 指定的案例编号；可多次，全部解压到同一目录 |

合法示例：
- `/quick-requirement 算力集市小程序`（无参考）
- `/quick-requirement 算力集市小程序 #1`
- `/quick-requirement 算力集市小程序 #1 #3`
````

替换为：

````markdown
## Parameters

| 参数 | 必填 | 说明 |
|------|------|------|
| `<关键词>` | 是 | 中文；用作需求描述、references 目录名、prototype 系统名派生源 |
| `[#id]` | 否 | 用户调用时通过 `#N` 指定的案例编号；可多次，全部解压到同一目录 |
| `--quick` | 否 | 显式 quick 模式（默认即 quick，可省略） |
| `--normal` | 否 | 显式 normal 模式（保留旧 5 步流程） |

**flag 必须在关键词之前**。

合法示例：
- `/quick-requirement 算力集市小程序`（默认 quick）
- `/quick-requirement --quick 算力集市小程序`（显式 quick）
- `/quick-requirement --quick 算力集市小程序 #1`（quick + 单参考）
- `/quick-requirement --normal 算力集市小程序 #1 #3`（normal + 多参考）
````

- [ ] **Step 4：Read 核对**

读 `skills/quick-requirement/SKILL.md` 前 100 行确认：
- frontmatter description 已更新
- 「步骤 0A 执行模式识别」段已插入到 `## When to Use` 之前
- 「步骤 0A」与 `## Overview`、`## When to Use` 之间有 `---` 分隔
- `## Parameters` 表新增 `--quick` / `--normal` 两行

- [ ] **Step 5：暂存（不 commit）**

```bash
git add skills/quick-requirement/SKILL.md
```

---

## Task 3：更新 `SKILL.md` — 双 Todo 表 + 双 Output 示例

**Files:**
- Modify: `skills/quick-requirement/SKILL.md`

- [ ] **Step 1：替换「Execution Todo」段**

把当前文件里（从 `## Execution Todo (执行待办清单)` 开始到 `## references.yaml Schema` 之前结束）的整段：

````markdown
## Execution Todo (执行待办清单)

quick-requirement 的执行被切分为 5 个待办项（Todo）。AI Agent 必须按顺序逐项推进，
每完成一项立刻更新状态（✅ 完成 / ⏳ 进行中 / ⚪ 未开始 / ⛔ 阻塞），并在阻塞时主动
告知用户原因与回退建议。

| # | 待办名称 | 类型 | 入口 | 产出 | 下一步 |
|---|---------|------|------|------|--------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | 用户调用 `/quick-requirement <关键词> [#id]...` | 内存中的 `keyword`、`ids[]` | T2 |
| T2 | 拉取并解压参考素材（如有 `#id`） | 自动 / 可能阻塞 | shell：`bash scripts/download-refs.sh <关键词> <id>...` | `khala-spec/rd/references/<关键词>/` | T3（脚本退出码非 0 → ⛔ 阻塞并报告） |
| T3 | 调用 `/yx:require` 生成需求规格 | AI 子指令 | 派发 `khala-spec-require` skill | `khala-spec/rd/requirements/changes/vX.X.X/vX.X.X-<domain>.md` | T4 |
| T4 | 等用户在 `/yx:require` 步骤 8 审批通过 | 用户介入 | `khala-spec-require` 步骤 8 → 交互提问 → 用户选择「确认通过」 | 审批结论：通过 | T5（用户拒绝 → ⛔ 阻塞，回到 T3 修订） |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | 派发 `khala-spec-prototype` skill | `khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html` | 完成提示 |

### AI Agent 编排规约（待办披露）

- **执行前**：AI Agent 必须先把上表按用户可读格式打印给用户（推荐每行带状态 emoji，
  如「⏳ T1 解析关键词…」），让用户明确「接下来要做的事」与「需要用户介入的环节」。
- **执行中**：每完成一项立刻更新对应行的状态；同一时刻仅 1 项为 ⏳ 进行中，其余
  要么 ✅ 要么 ⚪。
- **阻塞时**：状态置为 ⛔，并向用户说明原因（脚本退出码、用户审批拒绝等）与建议
  的下一步动作。
- **完成后**：在「Output」章节的完成提示中再补一段「待办清单终态」，列出每项最终状态。
````

替换为：

````markdown
## Execution Todo (执行待办清单)

quick-requirement 按 `mode` 拆分待办。AI Agent 在锁定 `mode` 后，只按本模式对应的清单逐项推进。

### Normal Todo（5 项）

AI Agent 必须按顺序逐项推进，每完成一项立刻更新状态（✅ 完成 / ⏳ 进行中 / ⚪ 未开始 / ⛔ 阻塞），并在阻塞时主动告知用户原因与回退建议。

| # | 待办名称 | 类型 | 入口 | 产出 | 下一步 |
|---|---------|------|------|------|--------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | 用户调用 `/quick-requirement --normal <关键词> [#id]...` | 内存中的 `keyword`、`ids[]` | T2 |
| T2 | 拉取并解压参考素材（如有 `#id`） | 自动 / 可能阻塞 | shell：`bash scripts/download-refs.sh <关键词> <id>...` | `khala-spec/rd/references/<关键词>/` | T3（脚本退出码非 0 → ⛔ 阻塞并报告） |
| T3 | 调用 `/yx:require` 生成需求规格 | AI 子指令 | 派发 `khala-spec-require` skill | `khala-spec/rd/requirements/changes/vX.X.X/vX.X.X-<domain>.md` | T4 |
| T4 | 等用户在 `/yx:require` 步骤 8 审批通过 | 用户介入 | `khala-spec-require` 步骤 8 → 交互提问 → 用户选择「确认通过」 | 审批结论：通过 | T5（用户拒绝 → ⛔ 阻塞，回到 T3 修订） |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | 派发 `khala-spec-prototype` skill | `khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html` | 完成提示 |

#### Normal 披露规约

- **执行前**：AI Agent 必须先把上表按用户可读格式打印给用户（推荐每行带状态 emoji，如「⏳ T1 解析关键词…」），让用户明确「接下来要做的事」与「需要用户介入的环节」。
- **执行中**：每完成一项立刻更新对应行的状态；同一时刻仅 1 项为 ⏳ 进行中，其余要么 ✅ 要么 ⚪。
- **阻塞时**：状态置为 ⛔，并向用户说明原因（脚本退出码、用户审批拒绝等）与建议的下一步动作。
- **完成后**：在「Normal Output」章节的完成提示中再补一段「待办清单终态」，列出每项最终状态。

### Quick Todo（3 项，跳过 T3/T4）

| # | 待办名称 | 类型 | 入口 | 产出 | 下一步 |
|---|---------|------|------|------|--------|
| T1 | 解析关键词与 `#id` 列表 | 自动 | 用户调用 `/quick-requirement <关键词> [#id]...` | 内存中的 `keyword`、`ids[]` | T2 |
| T2 | 拉取并解压参考素材（如有 `#id`） | 自动 / 可能阻塞 | shell：`bash scripts/download-refs.sh <关键词> <id>...` | `khala-spec/rd/references/<关键词>/` | T5（脚本退出码非 0 → ⛔ 阻塞并报告） |
| T5 | 调用 `/yx:prototype` 生成高保真原型 | AI 子指令 | 派发 `khala-spec-prototype` skill | `khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html` | 完成提示 |

#### Quick 披露规约（极致精简）

- **执行前**：仅打印一行触发提示（见「步骤 0A」），不再打印 todo 表格
- **执行中**：**不**逐项刷新状态、不打印中间日志
- **阻塞时**：状态置为 ⛔ 并向用户说明原因（仅 T2 可能阻塞）
- **完成后**：仅在「Quick Output」章节输出一行汇总，不打 todo 终态表
````

- [ ] **Step 2：替换「Output (Success)」段为 Normal + Quick 双套**

把当前文件里的：

````markdown
## Output (Success)

```
[quick-requirement] done
- reference materials: khala-spec/rd/references/<关键词>/
- requirements spec:   khala-spec/rd/requirements/changes/vX.X.X/vX.X.X-<domain>.md
- high-fi prototype:   khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html

待办清单终态：
- ✅ T1 解析关键词与 #id 列表
- ✅ T2 拉取并解压参考素材（<N> 个案例）
- ✅ T3 调用 /yx:require 生成需求规格
- ✅ T4 用户在 yx:require 步骤 8 审批通过
- ✅ T5 调用 /yx:prototype 生成高保真原型
```
````

替换为：

````markdown
## Output (Success)

### Normal Output

```
[quick-requirement] done (normal mode)
- reference materials: khala-spec/rd/references/<关键词>/
- requirements spec:   khala-spec/rd/requirements/changes/vX.X.X/vX.X.X-<domain>.md
- high-fi prototype:   khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html

待办清单终态：
- ✅ T1 解析关键词与 #id 列表
- ✅ T2 拉取并解压参考素材（<N> 个案例）
- ✅ T3 调用 /yx:require 生成需求规格
- ✅ T4 用户在 yx:require 步骤 8 审批通过
- ✅ T5 调用 /yx:prototype 生成高保真原型
```

### Quick Output（极致精简，仅 3 行）

```
[quick-requirement] done (quick mode)
- references:  khala-spec/rd/references/<关键词>/ (<N> 个案例)
- prototype:   khala-spec/rd/prototype/high-fidelity/<system_name>-prototype/index.html
```

Quick 模式不打印中间状态变更、不打印 todo 终态表、不打印需求规格相关路径（因为没产出）。
````

- [ ] **Step 3：Read 核对**

读 `skills/quick-requirement/SKILL.md` 的 Execution Todo 与 Output 段确认：
- 出现两个 `### Normal Todo` / `### Quick Todo` 小节
- 出现两个 `### Normal Output` / `### Quick Output` 小节
- Quick Output 仅有 3 行（done + references + prototype）
- 原 5 项单 Todo 表与单 Output 块已彻底替换

- [ ] **Step 4：暂存（不 commit）**

```bash
git add skills/quick-requirement/SKILL.md
```

---

## Task 4：更新 `SKILL.md` — Common Mistakes 增补

**Files:**
- Modify: `skills/quick-requirement/SKILL.md`

- [ ] **Step 1：追加 3 行到 Common Mistakes 表**

找到当前文件里的 `## Common Mistakes` 段（位于 Container Runtime 段之后、Common Confusion 段之前），在表格末尾追加 3 行（保留原有行不动）：

把现有的：

````markdown
## Common Mistakes

| 现象 | 原因 |
|------|------|
| 报错 `references.yaml 未配置` | 未从 `references.example.yaml` 复制为 `references.yaml` |
| curl 返回 4xx/5xx | `#id` 在服务端不存在；脚本退出码 2 |
| 中文关键词乱码 | 容器 `LANG` 非 UTF-8 |
| curl 报证书错误 | 内网自签证书未设置 `QUICK_REQ_INSECURE=1` |
| `yx: require` / `yx: prototype` 报错 | AI Agent 未正确加载 `khala-spec-require` / `khala-spec-prototype` skill |
| 关键词含 `#` 字面量 | 不支持，提示用户转义或换名 |
| 目标目录已存在 | `download-refs.sh` 自动备份为 `.bak-yyyyMMdd-HHmmss/` 后覆盖 |
````

替换为：

````markdown
## Common Mistakes

| 现象 | 原因 |
|------|------|
| 报错 `references.yaml 未配置` | 未从 `references.example.yaml` 复制为 `references.yaml` |
| curl 返回 4xx/5xx | `#id` 在服务端不存在；脚本退出码 2 |
| 中文关键词乱码 | 容器 `LANG` 非 UTF-8 |
| curl 报证书错误 | 内网自签证书未设置 `QUICK_REQ_INSECURE=1` |
| `yx: require` / `yx: prototype` 报错 | AI Agent 未正确加载 `khala-spec-require` / `khala-spec-prototype` skill |
| 关键词含 `#` 字面量 | 不支持，提示用户转义或换名 |
| 目标目录已存在 | `download-refs.sh` 自动备份为 `.bak-yyyyMMdd-HHmmss/` 后覆盖 |
| 默认看不到 `/yx:require` 步骤 8 的用户审批交互 | 当前为 quick 模式（默认）；需要审批交互请显式传 `--normal` |
| 期望产出需求规格文档但 quick 模式下没有 | quick 模式刻意跳过；改用 `--normal` 或直接调用 `/yx:require` |
| flag 写在关键词之后被忽略 | `--quick` / `--normal` 必须在关键词之前；位置错误则提示并忽略该 flag |
````

- [ ] **Step 2：Read 核对**

读 `skills/quick-requirement/SKILL.md` 的 Common Mistakes 段确认：
- 原有 7 行保留
- 新增 3 行（默认无审批 / 缺需求规格 / flag 位置错误）就位
- 表格格式未乱

- [ ] **Step 3：暂存（不 commit）**

```bash
git add skills/quick-requirement/SKILL.md
```

---

## Task 5：更新 `references.example.yaml` 顶部注释

**Files:**
- Modify: `skills/quick-requirement/scripts/references.example.yaml`

- [ ] **Step 1：Read 当前文件确认原始内容**

读 `skills/quick-requirement/scripts/references.example.yaml` 全文。当前文件前 12 行是详细 yaml 注释，最后一行是 `base_url: http://...`。

- [ ] **Step 2：在「重要：」段之后、`base_url:` 行之前插入两行模式说明注释**

把当前文件的第 7-12 行：

```yaml
# 重要：
#   - 脚本将拼接 url 为 ${base_url}?caseId=${id}
#   - 无需登记任何 id 列表，id 由调用时通过 #N 直接指定
#   - 服务端负责根据 caseId 返回对应案例
#   - 服务端返回 4xx/5xx 时脚本会报错退出

base_url: http://192.168.1.100:8080/cases/download
```

替换为：

```yaml
# 重要：
#   - 脚本将拼接 url 为 ${base_url}?caseId=${id}
#   - 无需登记任何 id 列表，id 由调用时通过 #N 直接指定
#   - 服务端负责根据 caseId 返回对应案例
#   - 服务端返回 4xx/5xx 时脚本会报错退出
#
# 注意：
#   - 本命令支持 `--normal` / `--quick` 两种执行模式（默认 quick），详见 SKILL.md 步骤 0A
#   - 本文件仅控制参考素材下载地址，不影响模式选择

base_url: http://192.168.1.100:8080/cases/download
```

> 仅追加 2 行注释 + 一个空行，保留原有 4 行「重要」段与 yaml body 不变。

- [ ] **Step 3：Read 核对**

读 `skills/quick-requirement/scripts/references.example.yaml` 全文确认：
- 顶部 5 行「使用方法」段保持原样
- 中段「重要：」4 行保持原样
- 追加 2 行「注意：」段（模式说明 + 不影响模式选择）
- yaml body `base_url: ...` 保持原样

- [ ] **Step 4：暂存（不 commit）**

```bash
git add skills/quick-requirement/scripts/references.example.yaml
```

---

## Task 6：最终自检

**Files:**
- 不修改任何文件，仅做验证

- [ ] **Step 1：执行最终自检清单**

按 spec「验收」节逐项核对（人工/AI 对照阅读即可）：

```bash
# 列出本次计划涉及的所有文件改动是否就位
git diff --cached --stat
```

期望输出（行数会因 frontmatter/注释略有差异）：

```
commands/quick-requirement.md                                |  +30 -5
skills/quick-requirement/SKILL.md                           | +120 -20
skills/quick-requirement/scripts/references.example.yaml    |   +3 -0
```

对照 spec 验收清单：

- [ ] `/yx:quick-requirement关键词` 默认进入 quick 模式，跳过 T3/T4，仅产出参考素材与原型
- [ ] `/yx:quick-requirement --normal 关键词` 进入 normal 模式，完整跑 5 步
- [ ] `/yx:quick-requirement --quick 关键词` 显式 quick，行为与默认 quick 一致
- [ ] flag 在关键词之后被识别为位置错误并提示
- [ ] `--quick` + `--normal` 同时出现时按 normal 处理
- [ ] normal 模式 Output 含 todo 终态表；quick 模式 Output 仅 3 行
- [ ] quick 模式执行中不打印 todo 状态变更
- [ ] `download-refs.sh` 未被改动

- [ ] **Step 2：报告用户 review**

告诉用户：
- 暂存文件清单（`git diff --cached --stat`）
- 验收清单对照结果
- 由用户亲自 `git commit` 与发布

> 按仓库 CLAUDE.md §「Git 操作约束」：代码/资产类文件只 `add` 不 `commit`，提交动作由用户完成。

---

## 不在本次范围内

- 不修改 `download-refs.sh`
- 不修改 `/yx:require` 与 `/yx:prototype` skill
- 不修改 `references.yaml` schema（仅在示例文件顶部加注释）
- 不新增 `--dry-run` 等其他 flag
- 不调整 `bootstrap-app` 编排器对 `quick-requirement` 的引用