import vueBus from '@/vue-bus'
// 发送事件（通知其他组件用户信息已更新）
function updateUserInfo() {
  const userInfo = {
    id: 1,
    name: '张三',
    avatar: 'xxx.jpg'
  }
  vueBus.$emit('user-info-updated', userInfo)
}
