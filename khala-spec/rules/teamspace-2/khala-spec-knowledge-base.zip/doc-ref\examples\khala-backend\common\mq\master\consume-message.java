package com.example.mq;

import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Service;

/**
 * 消费消息示例
 */
@Service
@RocketMQMessageListener(
        topic = "test-topic",
        consumerGroup = "test-consumer-group"
)
public class ConsumeMessageListener implements RocketMQListener<String> {

    @Override
    public void onMessage(String message) {
        System.out.println("收到消息: " + message);
        // 处理业务逻辑
    }
}

/**
 * 消费对象消息示例
 */
@Service
@RocketMQMessageListener(
        topic = "user-topic",
        consumerGroup = "user-consumer-group"
)
class UserMessageListener implements RocketMQListener<SendMessageController.UserMessageReqVO> {

    @Override
    public void onMessage(SendMessageController.UserMessageReqVO message) {
        System.out.println("收到用户消息: " + message.getUsername());
        // 处理业务逻辑
    }
}
