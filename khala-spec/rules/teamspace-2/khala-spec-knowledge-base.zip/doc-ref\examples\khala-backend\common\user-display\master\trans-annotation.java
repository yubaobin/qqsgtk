package com.example.userdisplay;

import com.eshore.dromara.trans.annotation.Trans;
import com.eshore.dromara.trans.type.TransType;
import lombok.Data;

/**
 * 实体翻译注解示例
 *
 * <p>说明：在 VO / DTO 的 ID 字段上使用 @Trans 注解，dromara-trans 会自动拦截并翻译，</p>
 * <ul>
 *   <li>1. type = TransType.AUTO_TRANS：自动翻译模式</li>
 *   <li>2. key = "user"：对应翻译服务的 namespace</li>
 *   <li>3. target = SysUserModel.class：翻译目标实体类型</li>
 *   <li>4. fields = "realName"：要取回的字段</li>
 *   <li>5. ref = "createByName"：翻译结果填充到哪个字段</li>
 * </ul>
 */
@Data
public class OrderVO {

    private Long id;
    private String orderNo;

    /**
     * 创建人 ID（会被自动翻译为 createByName）
     */
    @Trans(
            type = TransType.AUTO_TRANS,
            key = "user",
            target = SysUserModel.class,
            fields = "realName",
            ref = "createByName"
    )
    private Long createBy;

    /**
     * 翻译后填充的字段
     */
    private String createByName;

    /**
     * 更新人 ID
     */
    @Trans(
            type = TransType.AUTO_TRANS,
            key = "user",
            target = SysUserModel.class,
            fields = "realName",
            ref = "updateByName"
    )
    private Long updateBy;

    private String updateByName;

    /**
     * 租户 ID（翻译为租户名称）
     */
    @Trans(
            type = TransType.AUTO_TRANS,
            key = "tenant",
            target = SysTenantModel.class,
            fields = "tenantName",
            ref = "tenantName"
    )
    private Long tenantId;

    private String tenantName;
}

/**
 * 用户模型（翻译目标）
 */
@Data
class SysUserModel {
    private Long id;
    private String realName;
}

/**
 * 租户模型（翻译目标）
 */
@Data
class SysTenantModel {
    private Long id;
    private String tenantName;
}
