package com.example.auth;

import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 方法级权限控制示例
 */
@Tag(name = "权限控制示例")
@RestController
@RequestMapping("/api/demo")
public class PermissionCheckController {

    /**
     * 允许匿名访问
     */
    @Operation(summary = "公开接口", description = "允许匿名访问")
    @PermitAll
    @GetMapping("/public")
    public CommonResult<String> publicApi() {
        return CommonResult.success("任何人都可以访问");
    }

    /**
     * 需要登录
     */
    @Operation(summary = "登录接口", description = "需要登录后才能访问")
    @GetMapping("/login-only")
    public CommonResult<String> loginOnly() {
        return CommonResult.success("登录后即可访问");
    }

    /**
     * 需要特定角色
     */
    @Operation(summary = "管理员接口", description = "需要 ADMIN 角色")
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin-only")
    public CommonResult<String> adminOnly() {
        return CommonResult.success("仅管理员可访问");
    }

    /**
     * 需要特定权限
     */
    @Operation(summary = "添加用户权限接口", description = "需要 sys:user:add 权限")
    @PreAuthorize("hasAuthority('sys:user:add')")
    @GetMapping("/add-user")
    public CommonResult<String> addUser() {
        return CommonResult.success("有添加用户权限者可访问");
    }

    /**
     * 组合权限判断
     */
    @Operation(summary = "查看用户权限接口", description = "需要 ADMIN 角色或 sys:user:view 权限")
    @PreAuthorize("hasRole('ADMIN') or hasAuthority('sys:user:view')")
    @GetMapping("/view-user")
    public CommonResult<String> viewUser() {
        return CommonResult.success("管理员或有查看权限者可访问");
    }
}
