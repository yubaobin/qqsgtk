import { defineStore } from 'pinia'
import { store } from '../index'
import dictApi from '@/api/modules/dict'

export const useDictStore = defineStore('dict', {
    state: () => {
        return {
            dictCache: {}
        }
    },
    actions: {
        setCache ({ code, list, map } = {}) {
            this.dictCache[code] = { list, map }
        },
        delCache (code) {
            this.dictCache[code] = null
        },
        refreshCache (code) {
            if (this.dictCache[code]) {
                this.getDictListMapNoCache(code)
            }
        },
        getDictListMap (code) {
            if (this.dictCache[code]) {
                return Promise.resolve(this.dictCache[code])
            }
            return this.getDictListMapNoCache(code)
        },
        async getDictListMapNoCache (code) {
            const data = await dictApi.getDictItemByDictCode({ dictCode: code })
            const map = new Map()
            for (const item of data) {
                item.value = item.code
                item.label = item.text
                map.set(item.code, item.text)
            }
            this.dictCache[code] = {
                list: data,
                map
            }
            return { list: data, map: map }
        }
    }
})

/**
 * 在没有注册store的地方, 使用store
 * @returns
 */
export function useDictStoreHook () {
    return useDictStore(store)
}
