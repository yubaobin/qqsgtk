package com.example.listdelete;

import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 批量删除示例
 */
@Tag(name = "用户管理")
@RestController
@RequestMapping("/api/user")
public class BatchDeleteController {

    /**
     * 批量删除用户
     */
    @Operation(summary = "批量删除用户", description = "根据 ID 列表批量删除用户")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "删除成功"),
            @ApiResponse(responseCode = "400", description = "参数校验失败")
    })
    @PostMapping("/delete-batch")
    public CommonResult<Boolean> deleteBatch(@RequestBody UserBatchDeleteReqVO reqVO) {
        // 调用 Service 批量删除
        boolean success = removeByIds(reqVO.getIds());
        return CommonResult.success(success);
    }

    private boolean removeByIds(List<Long> ids) {
        // 实际调用 Service 层
        return true;
    }
}

/**
 * 批量删除用户请求参数示例
 */
class UserBatchDeleteReqVO {

    private List<Long> ids;

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }
}
