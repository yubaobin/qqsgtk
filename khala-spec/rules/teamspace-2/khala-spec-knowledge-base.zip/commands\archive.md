---
name: yx:archive
description: 归档已完成的变更，将其从活跃列表移至归档目录
tags: [workflow, archive, experimental]
---

Use Skill tool to invoke khala-spec-archive.
