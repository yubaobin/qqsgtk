package com.eshore.khala.example.lock;

import com.eshore.khala.starter.klock.Klock;
import com.eshore.khala.starter.klock.KlockKey;
import org.springframework.stereotype.Service;

/**
 * @Klock 注解分布式锁示例
 *
 * <p>相比 @Lock，@Klock 支持通过 @KlockKey 标注参数来自定义业务 Key</p>
 * <p>适用于需要基于方法参数组合生成锁 Key 的场景</p>
 */
@Service
public class KlockAnnotationService {

    /**
     * 基本用法：指定锁名称和业务 Key
     *
     * <p>name: 锁的名称前缀</p>
     * <p>keys: SpEL 表达式，用于提取参数值组合为锁 Key</p>
     */
    @Klock(name = "orderLock", keys = {"#orderId"})
    public void createOrder(Long orderId) {
        // 业务逻辑
    }

    /**
     * 多 Key 组合：基于多个参数构建锁 Key
     *
     * <p>最终锁 Key = name + 参数值组合</p>
     */
    @Klock(name = "transferLock", keys = {"#fromAccount", "#toAccount"}, waitTime = 10, leaseTime = 30)
    public void transfer(String fromAccount, String toAccount, Long amount) {
        // 转账逻辑
    }

    /**
     * 使用 @KlockKey 标注参数
     *
     * <p>通过 @KlockKey 在参数上标注，自动提取该参数作为锁 Key 的一部分</p>
     */
    @Klock(name = "paymentLock")
    public void payOrder(@KlockKey Long orderId, Long amount) {
        // 支付逻辑
    }

    /**
     * 公平锁：保证获取锁的顺序与请求顺序一致
     */
    @Klock(name = "fairLock", keys = {"#id"}, isFair = true)
    public void fairLockProcess(Long id) {
        // 业务逻辑
    }
}
