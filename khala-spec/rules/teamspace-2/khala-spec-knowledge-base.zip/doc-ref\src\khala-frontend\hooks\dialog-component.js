import { cloneDeep } from 'lodash-es'
import { UxMessage } from 'ux-up'
import { computed, ref, watch } from 'vue'

/**
 * @typedef {object} DialogComponentOption
 * @property {import('vue').Ref<import('ux-up').FormInstance>} formRef 表单实例
 * @property {Record<string, any>} form 提交表单数据
 */

export const dialogComponentEmit = ['close', 'update:visible']

export const dialogComponentProps = {
    visible: Boolean,
    curRow: {
        type: Object,
        default: () => ({})
    }
}

/**
 * @param {typeof dialogComponentProps } props
 * @param {(event: 'close' | 'update:visible', ...args: any[]) => void} emit
 * @param {DialogComponentOption} state
 */
export function useDialogComponentHook (props, emit, state = {}) {
    const getDetailApi = state.getDetailApi ? state.getDetailApi : null // 获取详情api
    const bindVisible = ref(false)
    const defaultForm = state.form ? state.form : {}

    const form = ref(cloneDeep(defaultForm))
    const submitting = ref(false)
    const loadingDetail = ref(false)

    const isAdd = computed(() => !props.curRow.id)

    function onAdd () {
        form.value = cloneDeep(defaultForm)
        resetFields()
    }
    function onEdit () {
        if (getDetailApi.value instanceof Function) {
            loadingDetail.value = true
            getDetailApi({ id: props.curRow.id }).then(data => {
                form.value = data
            }).finally(() => {
                loadingDetail.value = false
            })
        } else {
            form.value = cloneDeep(props.curRow)
        }
    }
    function beforeShow () {
        if (isAdd.value) {
            onAdd()
        } else {
            onEdit()
        }
    }
    function validate (apiMethod) {
        if (!state.formRef?.value) return
        state.formRef.value.validate().then(() => {
            submitting.value = true
            const re = apiMethod(form.value)
            if (re instanceof Promise) {
                re.then(() => {
                    UxMessage.success('成功')
                    bindVisible.value = false
                    emit('close')
                }).finally(() => {
                    submitting.value = false
                })
            }
        }, () => {
            UxMessage.warning('请检查输入')
        })
    }
    function resetFields () {
        if (state.formRef?.value) {
            state.formRef.value.resetFields()
        }
    }

    watch(() => props.visible, (val) => {
        if (bindVisible.value !== val) {
            bindVisible.value = val
            if (val) {
                beforeShow()
            }
        }
    }, {
        immediate: true
    })

    watch(() => bindVisible.value, (val) => {
        if (props.visible !== val) {
            emit('update:visible', val)
        }
    })

    return {
        bindVisible,
        form,
        submitting,
        loadingDetail,
        isAdd,
        onAdd,
        onEdit,
        validate,
        resetFields
    }
}
