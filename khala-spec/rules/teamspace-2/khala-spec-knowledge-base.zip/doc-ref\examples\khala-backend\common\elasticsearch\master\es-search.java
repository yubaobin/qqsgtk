package com.eshore.khala.example.es;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.HighlightQuery;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Elasticsearch 搜索查询示例
 *
 * <p>使用 ElasticsearchOperations 进行复杂搜索、聚合、高亮等操作</p>
 */
@Service
@RequiredArgsConstructor
public class EsSearchService {

    private final ElasticsearchOperations elasticsearchOperations;

    /**
     * 全文搜索
     *
     * <p>使用 match 查询对指定字段进行全文检索</p>
     */
    public List<Object> fullTextSearch(String keyword) {
        NativeQuery query = NativeQuery.builder()
                .withQuery(q -> q.match(m -> m.field("content").query(keyword)))
                .build();
        SearchHits<Object> hits = elasticsearchOperations.search(query, Object.class);
        return hits.getSearchHits().stream()
                .map(SearchHit::getContent)
                .collect(Collectors.toList());
    }

    /**
     * 多字段全文搜索
     */
    public List<Object> multiFieldSearch(String keyword) {
        NativeQuery query = NativeQuery.builder()
                .withQuery(q -> q.multiMatch(m -> m
                        .fields("title", "content")
                        .query(keyword)))
                .build();
        SearchHits<Object> hits = elasticsearchOperations.search(query, Object.class);
        return hits.getSearchHits().stream()
                .map(SearchHit::getContent)
                .collect(Collectors.toList());
    }

    /**
     * 布尔组合查询
     *
     * <p>must: 必须匹配；should: 可选匹配；mustNot: 必须不匹配</p>
     */
    public List<Object> boolSearch(String title, String author) {
        NativeQuery query = NativeQuery.builder()
                .withQuery(q -> q.bool(b -> b
                        .must(m -> m.match(mt -> mt.field("title").query(title)))
                        .must(m -> m.match(mt -> mt.field("author").query(author)))))
                .build();
        SearchHits<Object> hits = elasticsearchOperations.search(query, Object.class);
        return hits.getSearchHits().stream()
                .map(SearchHit::getContent)
                .collect(Collectors.toList());
    }

    /**
     * 分页查询
     */
    public Page<Object> pageSearch(String keyword, int pageNum, int pageSize) {
        NativeQuery query = NativeQuery.builder()
                .withQuery(q -> q.match(m -> m.field("content").query(keyword)))
                .withPageable(PageRequest.of(pageNum, pageSize))
                .build();
        SearchHits<Object> hits = elasticsearchOperations.search(query, Object.class);
        // 返回分页结果
        return hits.map(SearchHit::getContent);
    }

    /**
     * 高亮搜索
     *
     * <p>搜索结果中高亮显示匹配的关键词</p>
     */
    public List<Object> highlightSearch(String keyword) {
        HighlightBuilder highlightBuilder = new HighlightBuilder()
                .field("title")
                .field("content")
                .preTags("<em>")
                .postTags("</em>");

        NativeQuery query = NativeQuery.builder()
                .withQuery(q -> q.match(m -> m.field("content").query(keyword)))
                .withHighlightQuery(new HighlightQuery(highlightBuilder, Object.class))
                .build();
        SearchHits<Object> hits = elasticsearchOperations.search(query, Object.class);
        return hits.getSearchHits().stream()
                .map(SearchHit::getContent)
                .collect(Collectors.toList());
    }
}
