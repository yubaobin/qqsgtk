package com.example.auth;

import com.eshore.khala.starter.captcha.core.annotation.Captcha;
import com.eshore.khala.starter.captcha.core.CaptchaServiceFactory;
import com.eshore.khala.starter.captcha.core.code.provider.CodeCaptchaManager;
import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 验证码使用示例
 */
@Tag(name = "验证码管理")
@RestController
@RequestMapping("/api/captcha")
public class CaptchaController {

    @Autowired
    private CaptchaServiceFactory captchaServiceFactory;

    @Autowired
    private CodeCaptchaManager codeCaptchaManager;

    /**
     * 方式一：使用 @Captcha 注解自动校验（推荐）
     *
     * 方法执行前会自动校验验证码
     */
    @Operation(summary = "登录（带验证码校验）", description = "使用 @Captcha 注解自动校验验证码")
    @Captcha
    @PostMapping("/login")
    public CommonResult<String> loginWithAnnotation(@RequestBody LoginReqVO reqVO) {
        // 验证码校验通过后才会执行到这里
        return CommonResult.success("登录成功");
    }

    /**
     * 方式二：手动校验验证码
     */
    @Operation(summary = "手动校验验证码", description = "根据参数自动路由到对应的验证码服务进行校验")
    @PostMapping("/verify")
    public CommonResult<Boolean> verifyCaptcha(@RequestBody Map<String, String> params) {
        // 根据参数自动路由到对应的验证码服务进行校验
        boolean success = captchaServiceFactory.verify(params);
        return CommonResult.success(success);
    }

    /**
     * 发送短信验证码
     */
    @Operation(summary = "发送短信验证码", description = "发送短信验证码，默认使用 LOGIN 模板")
    @PostMapping("/send-sms")
    public CommonResult<?> sendSmsCode(@RequestParam String mobile) {
        // 发送短信验证码，默认使用 LOGIN 模板
        return codeCaptchaManager.send("sms", "khala", "login", mobile);
    }

    /**
     * 发送邮箱验证码
     */
    @Operation(summary = "发送邮箱验证码", description = "发送邮箱验证码")
    @PostMapping("/send-email")
    public CommonResult<?> sendEmailCode(@RequestParam String email) {
        return codeCaptchaManager.send("email", "khala", "login", email);
    }

    // 登录参数
    public static class LoginReqVO {
        private String username;
        private String password;
        private String captchaCode;
        private String captchaKey;
        // getters / setters
    }
}
