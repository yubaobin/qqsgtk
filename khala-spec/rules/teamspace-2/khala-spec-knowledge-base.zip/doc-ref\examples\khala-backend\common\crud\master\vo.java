package com.example.crud;

import com.eshore.khala.starter.sensitive.desensitization.annocation.DesensitizationEmail;
import com.eshore.khala.starter.sensitive.desensitization.annocation.DesensitizationMobile;
import com.eshore.khala.starter.sensitive.desensitization.annocation.DesensitizationName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 用户响应数据 VO 示例
 */
@Schema(description = "用户响应数据")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SysUserRespVO {

    @Schema(description = "用户编号", requiredMode = Schema.RequiredMode.REQUIRED, example = "1")
    private Long id;

    @Schema(description = "用户账号", requiredMode = Schema.RequiredMode.REQUIRED, example = "admin")
    private String username;

    @Schema(description = "用户名称", requiredMode = Schema.RequiredMode.REQUIRED, example = "管理员")
    @DesensitizationName
    private String realName;

    @Schema(description = "用户昵称", example = "管理员")
    private String nickname;

    @Schema(description = "用户邮箱", example = "admin@example.com")
    @DesensitizationEmail
    private String email;

    @Schema(description = "手机号码", requiredMode = Schema.RequiredMode.REQUIRED, example = "13800138000")
    @DesensitizationMobile
    private String mobile;

    @Schema(description = "状态：0-禁用，1-启用", example = "1")
    private Integer status;

    @Schema(description = "创建时间", example = "2024-01-01 12:00:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @Schema(description = "更新时间", example = "2024-01-01 12:00:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
}
