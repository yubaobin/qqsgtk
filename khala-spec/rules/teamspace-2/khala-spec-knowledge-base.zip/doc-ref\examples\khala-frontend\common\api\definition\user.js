import { get, post, upload, download } from '@/utils/fetch.js'

export default {
    /**
     * 获取用户详情
     * @param { object } params
     * @param { number } params.id 用户ID
     * @returns
     */
    getUserDetail: (params) => get('/api-admin', '/user/get', params),

    /**
     * 新增用户
     * @param { object } data
     * @param { string } data.username 用户名
     * @param { string } data.name 用户姓名
     * @returns
     */
    addUser: (params) => post('/api-admin', '/user/create', params),

    /**
     * 上传用户头像
     * @param { FormData } formData
     * @returns
     */
    uploadAvatar: params => upload('/api-file', '/file/upload', params, { encryption: false }),

    /**
     * 导出用户列表
     * @param { object } params
     * @returns
     */
    exportUserList: params => {
        return download('/api-file', '/file/download', params)
    }
}