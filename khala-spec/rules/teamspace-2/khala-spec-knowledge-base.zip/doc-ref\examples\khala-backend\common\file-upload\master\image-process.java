package com.example.fileupload;

import cn.hutool.core.img.ImgUtil;
import cn.hutool.core.io.FileUtil;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * 图片处理示例
 */
@RestController
@RequestMapping("/image")
public class ImageProcessController {

    /**
     * 图片压缩
     */
    @PostMapping("/compress")
    public String compress(@RequestParam("file") MultipartFile file,
                           @RequestParam(defaultValue = "0.8") float quality) throws IOException {
        File tempFile = File.createTempFile("img", ".jpg");
        file.transferTo(tempFile);

        // 压缩图片
        ImgUtil.compress(tempFile, tempFile, quality);

        return "压缩完成";
    }

    /**
     * 添加水印
     */
    @PostMapping("/watermark")
    public String addWatermark(@RequestParam("file") MultipartFile file) throws IOException {
        BufferedImage image = ImageIO.read(file.getInputStream());

        // 创建水印
        BufferedImage watermarkImage = ImgUtil.pressText(
                image,
                "Khala",
                Color.RED,
                new Font("黑体", Font.BOLD, 40),
                0,
                0,
                0.5f
        );

        File output = new File("watermarked.jpg");
        ImageIO.write(watermarkImage, "jpg", output);

        return "水印添加完成";
    }
}
