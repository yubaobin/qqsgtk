package com.example.mq;

import com.eshore.khala.common.core.result.CommonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.rocketmq.spring.annotation.RocketMQTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionState;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 事务消息示例
 */
@Tag(name = "消息队列管理")
@RestController
@RequestMapping("/api/mq")
public class TransactionMessageController {

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    /**
     * 发送事务消息
     */
    @Operation(summary = "发送事务消息", description = "发送事务消息到指定 topic")
    @PostMapping("/send-transaction")
    public CommonResult<String> sendTransaction(@RequestParam String message) {
        rocketMQTemplate.sendMessageInTransaction("transaction-producer-group",
                "transaction-topic", message, null);
        return CommonResult.success("事务消息发送成功");
    }
}

/**
 * 事务消息监听器
 */
@RocketMQTransactionListener(rocketMQTemplateBeanName = "rocketMQTemplate")
class TransactionListenerImpl implements RocketMQLocalTransactionListener {

    /**
     * 执行本地事务
     */
    @Override
    public RocketMQLocalTransactionState executeLocalTransaction(Message msg, Object arg) {
        try {
            // 执行本地业务逻辑
            // 例如：更新数据库状态
            System.out.println("执行本地事务: " + new String((byte[]) msg.getPayload()));
            return RocketMQLocalTransactionState.COMMIT;
        } catch (Exception e) {
            return RocketMQLocalTransactionState.ROLLBACK;
        }
    }

    /**
     * 回查本地事务状态
     */
    @Override
    public RocketMQLocalTransactionState checkLocalTransaction(Message msg) {
        // 查询本地事务状态
        System.out.println("回查本地事务状态: " + new String((byte[]) msg.getPayload()));
        return RocketMQLocalTransactionState.COMMIT;
    }
}
