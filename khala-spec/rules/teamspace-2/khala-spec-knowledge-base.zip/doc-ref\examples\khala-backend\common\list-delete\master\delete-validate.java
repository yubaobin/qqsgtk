package com.example.listdelete;

import com.eshore.khala.common.core.result.CommonResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 删除校验示例
 */
@RestController
@RequestMapping("/users")
public class DeleteValidateController {

    /**
     * 删除前校验关联数据
     */
    @DeleteMapping("/{id}")
    public CommonResult<Boolean> deleteWithValidate(@PathVariable Long id) {
        // 校验是否存在关联数据
        if (hasRelatedData(id)) {
            return CommonResult.error("该用户存在关联数据，无法删除");
        }

        boolean success = removeById(id);
        return CommonResult.success(success);
    }

    private boolean hasRelatedData(Long id) {
        // 查询关联数据
        return false;
    }

    private boolean removeById(Long id) {
        // 实际调用 Service 层
        return true;
    }
}
