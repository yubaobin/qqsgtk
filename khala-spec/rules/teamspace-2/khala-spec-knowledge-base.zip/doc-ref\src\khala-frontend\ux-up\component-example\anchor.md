# Anchor 锚点
通过锚点，可以很快找到当前页面上信息内容的位置。

## Anchor的基础用法
简单的用法。

```vue
<template>
    <ux-anchor :offset="70">
        <ux-anchor-link :href="`#${locale['basic-usage']}`">
            {{ locale['Basic Usage'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['horizontal-mode']}`">
            {{ locale['Horizontal Mode'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['scroll-container']}`">
            {{ locale['Scroll Container'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['anchor-api']}`">
            {{ locale['Anchor API'] }}
            <template #sub-link>
                <ux-anchor-link :href="`#${locale['anchor-attributes']}`">
                    {{ locale['Anchor Attributes'] }}
                </ux-anchor-link>
                <ux-anchor-link :href="`#${locale['anchor-events']}`">
                    {{ locale['Anchor Events'] }}
                </ux-anchor-link>
            </template>
        </ux-anchor-link>
    </ux-anchor>
</template>

<script setup>
import { computed } from 'vue'
import anchorLocale from '../../.vitepress/i18n/component/anchor.json'
import { useLang } from '~/composables/lang'

const lang = useLang()
const locale = computed(() => anchorLocale[lang.value])
</script>

```

## Anchor的水平模式
水平排列的锚点。

:::info warning

水平模式不支持 `sub-link` 槽位。

:::

```vue
<template>
    <ux-anchor :offset="70" direction="horizontal">
        <ux-anchor-link :href="`#${locale['basic-usage']}`">
            {{ locale['Basic Usage'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['horizontal-mode']}`">
            {{ locale['Horizontal Mode'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['scroll-container']}`">
            {{ locale['Scroll Container'] }}
        </ux-anchor-link>
    </ux-anchor>
</template>

<script setup>
import { computed } from 'vue'
import anchorLocale from '../../.vitepress/i18n/component/anchor.json'
import { useLang } from '~/composables/lang'

const lang = useLang()
const locale = computed(() => anchorLocale[lang.value])
</script>

```

## Anchor的滚动的容器
自定义滚动区域，使用 `offset` props 可以设置锚点滚动偏移。 监听 `link-click` 事件并阻止浏览器的默认行为，然后它不会改变历史。

```vue
<template>
    <div>
        <ux-row>
            <ux-col :span="18">
                <div
                    style="
                        height: 30px;
                        line-height: 30px;
                        padding: 0 12px;
                        width: 70%;
                        background: #ffd7d9;
                        position: absolute;
                        top: 0;
                        left: 0;
                        color: #fff;
                    ">
                    头部导航
                </div>
                <div ref="containerRef">
                    <div id="part1" style="height: 300px; background: rgba(255, 0, 0, 0.02); margin-top: 30px">
                        区域1
                    </div>
                    <div id="part2" style="height: 300px; background: rgba(0, 255, 0, 0.02); margin-top: 30px">
                        区域2
                    </div>
                    <div id="part3" style="height: 300px; background: rgba(0, 0, 255, 0.02); margin-top: 30px">
                        区域3
                    </div>
                </div>
            </ux-col>
            <ux-col :span="6">
                <div>
                    <ux-anchor
                        :container="containerRef"
                        direction="vertical"
                        type="default"
                        :offset="30"
                        @click="handleClick">
                        <ux-anchor-link href="#part1" title="区域1" />
                        <ux-anchor-link href="#part2" title="区域2" />
                        <ux-anchor-link href="#part3" title="区域3" />
                    </ux-anchor>
                </div>
            </ux-col>
        </ux-row>
    </div>
</template>

<script setup>
import { ref } from 'vue'

const containerRef = ref(null)

const handleClick = (e) => {
    e.preventDefault()
}
</script>

```

## Anchor的锚点链接变化
监听锚点链接变化。

```vue
<template>
    <ux-anchor :offset="70" @change="handleChange">
        <ux-anchor-link :href="`#${locale['basic-usage']}`">
            {{ locale['Basic Usage'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['horizontal-mode']}`">
            {{ locale['Horizontal Mode'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['scroll-container']}`">
            {{ locale['Scroll Container'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['anchor-api']}`">
            {{ locale['Anchor API'] }}
            <template #sub-link>
                <ux-anchor-link :href="`#${locale['anchor-attributes']}`">
                    {{ locale['Anchor Attributes'] }}
                </ux-anchor-link>
                <ux-anchor-link :href="`#${locale['anchor-events']}`">
                    {{ locale['Anchor Events'] }}
                </ux-anchor-link>
            </template>
        </ux-anchor-link>
    </ux-anchor>
</template>

<script setup>
import { computed } from 'vue'
import anchorLocale from '../../.vitepress/i18n/component/anchor.json'
import { useLang } from '~/composables/lang'

const lang = useLang()
const locale = computed(() => anchorLocale[lang.value])

const handleChange = (href) => {
    console.log(`anchor change: ${href}`)
}
</script>

```

## Anchor的下划线类型
设置`type` 为 `underline` 更改为下划线类型。

```vue
<template>
    <ux-anchor type="underline" :offset="70">
        <ux-anchor-link :href="`#${locale['basic-usage']}`">
            {{ locale['Basic Usage'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['horizontal-mode']}`">
            {{ locale['Horizontal Mode'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['scroll-container']}`">
            {{ locale['Scroll Container'] }}
        </ux-anchor-link>
        <ux-anchor-link :href="`#${locale['anchor-api']}`">
            {{ locale['Anchor API'] }}
            <template #sub-link>
                <ux-anchor-link :href="`#${locale['anchor-attributes']}`">
                    {{ locale['Anchor Attributes'] }}
                </ux-anchor-link>
                <ux-anchor-link :href="`#${locale['anchor-events']}`">
                    {{ locale['Anchor Events'] }}
                </ux-anchor-link>
            </template>
        </ux-anchor-link>
    </ux-anchor>
</template>

<script setup>
import { computed } from 'vue'
import anchorLocale from '../../.vitepress/i18n/component/anchor.json'
import { useLang } from '~/composables/lang'

const lang = useLang()
const locale = computed(() => anchorLocale[lang.value])
</script>

```

## Anchor的固定模式
使用 `ux-affix` 组件来固定住页面中的锚点。

```vue
<template>
    <ux-affix :offset="60">
        <ux-anchor :offset="70">
            <ux-anchor-link :href="`#${locale['basic-usage']}`">
                {{ locale['Basic Usage'] }}
            </ux-anchor-link>
            <ux-anchor-link :href="`#${locale['horizontal-mode']}`">
                {{ locale['Horizontal Mode'] }}
            </ux-anchor-link>
            <ux-anchor-link :href="`#${locale['scroll-container']}`">
                {{ locale['Scroll Container'] }}
            </ux-anchor-link>
            <ux-anchor-link :href="`#${locale['anchor-api']}`">
                {{ locale['Anchor API'] }}
                <template #sub-link>
                    <ux-anchor-link :href="`#${locale['anchor-attributes']}`">
                        {{ locale['Anchor Attributes'] }}
                    </ux-anchor-link>
                    <ux-anchor-link :href="`#${locale['anchor-events']}`">
                        {{ locale['Anchor Events'] }}
                    </ux-anchor-link>
                </template>
            </ux-anchor-link>
        </ux-anchor>
    </ux-affix>
</template>

<script setup>
import { computed } from 'vue'
import anchorLocale from '../../.vitepress/i18n/component/anchor.json'
import { useLang } from '~/composables/lang.mjs'

const lang = useLang()
const locale = computed(() => anchorLocale[lang.value])
</script>

```

