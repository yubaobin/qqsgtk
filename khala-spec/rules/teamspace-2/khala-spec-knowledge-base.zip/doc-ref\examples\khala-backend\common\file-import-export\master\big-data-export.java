package com.example.fileimportexport;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

/**
 * 大数据量导出示例
 */
@RestController
@RequestMapping("/excel")
public class BigDataExportController {

    /**
     * 分页导出大数据量
     */
    @GetMapping("/export-big")
    public void exportBigData(HttpServletResponse response) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("大数据导出", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream(), UserExportVO.class).build();
        WriteSheet writeSheet = EasyExcel.writerSheet("数据").build();

        int pageSize = 1000;
        int pageNum = 1;
        while (true) {
            List<UserExportVO> data = queryUserPage(pageNum, pageSize);
            if (data.isEmpty()) {
                break;
            }
            excelWriter.write(data, writeSheet);
            pageNum++;
        }
        excelWriter.finish();
    }

    private List<UserExportVO> queryUserPage(int pageNum, int pageSize) {
        // 模拟分页查询
        return List.of();
    }
}
